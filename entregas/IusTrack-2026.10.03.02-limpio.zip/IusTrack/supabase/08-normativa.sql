-- ════════════════════════════════════════════════════════════════════════
-- LexTrack — 08: Normativa vigente (seguimiento de modificaciones)
-- Se puede correr más de una vez sin problema.
--
-- · Guarda, para cada norma que sigue el apartado "Normativa", las normas que
--   la modifican o complementan según InfoLEG (nacionales) y el Sistema de
--   Información Normativa de la Provincia de Buenos Aires.
-- · Es información pública y común a todos los estudios: la leen todos los
--   usuarios con sesión iniciada.
-- · Sólo la escribe la función "normativa-actualizar" (con la clave del
--   servidor); desde la app nadie puede modificarla.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.normas_revision (
  norma            text primary key,         -- 'infoleg:25552' · 'gba:/ar-b/ley/2018/15057/2423'
  primera_revision timestamptz not null default now(),
  ultima_revision  timestamptz not null default now(),
  cantidad         int not null default 0,   -- cuántas normas la modifican o complementan
  error            text                      -- último error al consultar la fuente (si hubo)
);

create table if not exists public.normas_vinculos (
  norma        text not null references public.normas_revision(norma) on delete cascade,
  vinculo      text not null,                -- id de InfoLEG o ruta de la norma bonaerense que la modifica
  titulo       text not null default '',     -- 'Ley 27802' · 'Decreto 407/2026'
  organismo    text not null default '',
  descripcion  text not null default '',
  publicada    date,                         -- fecha de publicación en el Boletín Oficial (InfoLEG)
  anio         int,                          -- año (normas bonaerenses)
  detectado_en timestamptz not null default now(),
  primary key (norma, vinculo)
);
create index if not exists ix_normas_vinculos_detectado on public.normas_vinculos(detectado_en desc);

alter table public.normas_revision enable row level security;
alter table public.normas_vinculos enable row level security;
drop policy if exists nrm_rev_ver on public.normas_revision;
drop policy if exists nrm_vin_ver on public.normas_vinculos;
create policy nrm_rev_ver on public.normas_revision for select to authenticated using (true);
create policy nrm_vin_ver on public.normas_vinculos for select to authenticated using (true);
-- (sin reglas de alta, cambio ni baja: sólo escribe la función del servidor)

revoke all on public.normas_revision, public.normas_vinculos from anon;
