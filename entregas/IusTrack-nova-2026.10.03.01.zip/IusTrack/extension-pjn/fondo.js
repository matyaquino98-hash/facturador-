/* LexTrack — MEV: volver al expediente después de iniciar sesión
   Si se abre un expediente de la MEV (procesales.asp / nidCausa) sin sesión, la MEV manda
   a la pantalla de ingreso. Acá se recuerda a qué expediente se iba (por pestaña) y, apenas
   se ingresa, se lleva a esa pestaña directo al expediente. No toca usuario ni contraseña. */
importScripts('lector.js', 'seguimiento.js');   // lectura de la MEV + movimientos automáticos + descargas

const VIGENCIA = 10 * 60 * 1000;   // 10 minutos para iniciar sesión
const MAX_INTENTOS = 2;            // evita dar vueltas si la MEV vuelve a pedir el ingreso
const REINGRESO = 8000;            // si tras llegar al expediente la MEV pide ingresar enseguida, se sigue esperando
const FILTRO = { url: [{ hostEquals: 'mev.scba.gov.ar' }] };

const esExpediente = u => /procesales\.asp|nidcausa=/i.test(u);
// Sólo la pantalla de ingreso (loguin.asp); "POSLoguin.asp" ya es después de ingresar
const esIngreso = u => { try { return /\/(loguin|login)\.asp$/i.test(new URL(u).pathname) || new URL(u).pathname === '/'; } catch (e) { return false; } };
async function leer() { return (await chrome.storage.local.get('mevPend')).mevPend || {}; }
async function escribir(p) { await chrome.storage.local.set({ mevPend: p }); }

// Se pide un expediente: se anota para esa pestaña
chrome.webNavigation.onBeforeNavigate.addListener(async d => {
  if (d.frameId !== 0 || !esExpediente(d.url)) return;
  const p = await leer(), prev = p[d.tabId];
  p[d.tabId] = { url: d.url, t: Date.now(), intentos: prev && prev.url === d.url ? prev.intentos : 0, llego: 0 };
  await escribir(p);
}, FILTRO);

// Cada página de la MEV que termina de cargar
chrome.webNavigation.onCompleted.addListener(async d => {
  if (d.frameId !== 0) return;
  const p = await leer(), x = p[d.tabId];
  if (!x) return;
  const ahora = Date.now();
  if (ahora - x.t > VIGENCIA) { delete p[d.tabId]; return escribir(p); }
  if (esExpediente(d.url)) { x.llego = ahora; return escribir(p); }            // llegó (por ahora)
  if (esIngreso(d.url)) {
    if (x.llego && ahora - x.llego > REINGRESO) { delete p[d.tabId]; return escribir(p); }   // es otra cosa
    x.llego = 0; return escribir(p);                                            // hay que ingresar: se espera
  }
  // Ya se ingresó (cualquier otra página de la MEV)
  if (x.llego || x.intentos >= MAX_INTENTOS) { delete p[d.tabId]; return escribir(p); }
  x.intentos++;
  await escribir(p);
  chrome.tabs.update(d.tabId, { url: x.url });
}, FILTRO);

chrome.tabs.onRemoved.addListener(async id => { const p = await leer(); if (p[id]) { delete p[id]; await escribir(p); } });

// La pantalla de ingreso pregunta si hay un expediente esperando (para mostrar el aviso)
chrome.runtime.onMessage.addListener((m, sender, responder) => {
  if (!m || m.q !== 'mevPendiente' || !sender.tab) return;
  leer().then(p => { const x = p[sender.tab.id]; responder({ pendiente: !!(x && Date.now() - x.t < VIGENCIA && !x.llego) }); });
  return true;
});
