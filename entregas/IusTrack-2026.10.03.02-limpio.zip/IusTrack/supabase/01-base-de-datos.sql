-- ════════════════════════════════════════════════════════════════════════
-- LexTrack multi-estudio — Etapa 1: base de datos y reglas de seguridad
-- Pegar completo en Supabase → SQL Editor → Run. Se puede volver a correr.
--
-- Reglas:
--  · Cada estudio sólo ve sus propios datos (lo impone la base de datos).
--  · Roles dentro del estudio: admin (todo), abogado (carga y edita),
--    lectura (sólo mira).
--  · Cada expediente es "de todo el estudio" o "restringido": en ese caso
--    sólo lo ven los admins y los usuarios habilitados en ese expediente.
--  · El dueño del sistema (superadmin) da de alta estudios, licencias y
--    administradores, pero NO ve los expedientes de los estudios.
--  · Con la licencia vencida el estudio puede ver sus datos pero no cargar.
-- ════════════════════════════════════════════════════════════════════════

create extension if not exists pgcrypto;

-- ── Tablas ───────────────────────────────────────────────────────────────

create table if not exists public.estudios (
  id              uuid primary key default gen_random_uuid(),
  nombre          text not null,
  cuit            text,
  licencia_hasta  date not null default (current_date + 30),
  activo          boolean not null default true,
  creado_en       timestamptz not null default now()
);

create table if not exists public.perfiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  nombre          text not null default '',
  email           text,
  es_superadmin   boolean not null default false,
  creado_en       timestamptz not null default now()
);

create table if not exists public.miembros (
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  usuario_id      uuid not null references public.perfiles(id) on delete cascade,
  rol             text not null default 'abogado' check (rol in ('admin','abogado','lectura')),
  activo          boolean not null default true,
  creado_en       timestamptz not null default now(),
  primary key (estudio_id, usuario_id)
);

create table if not exists public.expedientes (
  id              text primary key default gen_random_uuid()::text,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  caratula        text not null,
  numero          text not null default '',
  estado          text not null default 'activo',
  juzgado         text not null default '',
  actora          text not null default '',
  demandada       text not null default '',
  abogado         text not null default '',
  objeto          text not null default '',
  monto           text not null default '',
  notas           text not null default '',
  link            text not null default '',
  visibilidad     text not null default 'estudio' check (visibilidad in ('estudio','restringido')),
  fecha_alta      date not null default current_date,
  creado_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  actualizado_en  timestamptz not null default now(),
  actualizado_por uuid default auth.uid() references public.perfiles(id) on delete set null,
  extra           jsonb not null default '{}'::jsonb   -- campos que agregue LexTrack a futuro
);

create table if not exists public.expediente_accesos (
  expediente_id   text not null references public.expedientes(id) on delete cascade,
  usuario_id      uuid not null references public.perfiles(id) on delete cascade,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  puede_editar    boolean not null default true,
  primary key (expediente_id, usuario_id)
);

create table if not exists public.movimientos (
  id              text primary key default gen_random_uuid()::text,
  expediente_id   text not null references public.expedientes(id) on delete cascade,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  tipo            text not null,
  fecha           date not null default current_date,
  vencimiento     date,
  responsable     text not null default '',
  descripcion     text not null default '',
  creado_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  creado_en       timestamptz not null default now(),
  editado_por     uuid references public.perfiles(id) on delete set null,
  editado_en      timestamptz
);

create table if not exists public.adjuntos (
  id              text primary key default gen_random_uuid()::text,
  movimiento_id   text not null references public.movimientos(id) on delete cascade,
  expediente_id   text not null references public.expedientes(id) on delete cascade,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  nombre          text not null,
  tamanio         bigint not null default 0,
  tipo_mime       text not null default '',
  ruta            text not null,   -- ruta en Storage: estudio/expediente/archivo
  subido_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  subido_en       timestamptz not null default now()
);

create table if not exists public.agenda (
  id              text primary key default gen_random_uuid()::text,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  expediente_id   text references public.expedientes(id) on delete cascade,
  tipo            text not null default 'audiencia',
  titulo          text not null,
  fecha           date not null,
  hora            text not null default '',
  descripcion     text not null default '',
  creado_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  actualizado_en  timestamptz not null default now()
);

-- Control de Pruebas
create table if not exists public.juicios_prueba (
  id              text primary key default gen_random_uuid()::text,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  expediente_id   text references public.expedientes(id) on delete set null,
  caratula        text not null,
  exp             text not null default '',
  juzgado         text not null default '',
  obs             text not null default '',
  actualizado_en  timestamptz not null default now()
);

create table if not exists public.pruebas (
  id              text primary key default gen_random_uuid()::text,
  juicio_id       text not null references public.juicios_prueba(id) on delete cascade,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  tipo            text not null default 'Informativa',
  dest            text not null,
  objeto          text not null default '',
  f_librado       date,
  f_diligenciado  date,
  via             text not null default '',
  f_reit_pedido   date,
  f_reit_enviado  date,
  f_contestado    date,
  f_vence         date,
  estado          text not null default 'pendiente',
  estado_manual   boolean not null default false,
  obs             text not null default '',
  actualizado_en  timestamptz not null default now()
);

create table if not exists public.notificaciones (
  id              uuid primary key default gen_random_uuid(),
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  para_usuario    uuid not null references public.perfiles(id) on delete cascade,
  de_usuario      uuid default auth.uid() references public.perfiles(id) on delete set null,
  texto           text not null,
  expediente_id   text references public.expedientes(id) on delete cascade,
  movimiento_id   text references public.movimientos(id) on delete cascade,
  leida           boolean not null default false,
  creada_en       timestamptz not null default now()
);

-- Índices para que las búsquedas por estudio y expediente sean rápidas
create index if not exists ix_miembros_usuario     on public.miembros(usuario_id);
create index if not exists ix_expedientes_estudio  on public.expedientes(estudio_id);
create index if not exists ix_accesos_usuario      on public.expediente_accesos(usuario_id);
create index if not exists ix_movimientos_exp      on public.movimientos(expediente_id);
create index if not exists ix_adjuntos_mov         on public.adjuntos(movimiento_id);
create index if not exists ix_agenda_estudio_fecha on public.agenda(estudio_id, fecha);
create index if not exists ix_pruebas_juicio       on public.pruebas(juicio_id);
create index if not exists ix_notif_usuario        on public.notificaciones(para_usuario, leida);

-- ── Funciones de permisos ────────────────────────────────────────────────
-- "security definer": leen las tablas sin pasar por las reglas, para no
-- entrar en un círculo (una regla que consulta otra regla).

create or replace function public.es_superadmin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select es_superadmin from perfiles where id = auth.uid()), false);
$$;

create or replace function public.rol_en(p_estudio uuid) returns text
language sql stable security definer set search_path = public as $$
  select m.rol from miembros m
  join estudios e on e.id = m.estudio_id
  where m.estudio_id = p_estudio and m.usuario_id = auth.uid()
    and m.activo and e.activo;
$$;

create or replace function public.es_miembro(p_estudio uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.rol_en(p_estudio) is not null;
$$;

create or replace function public.estudio_vigente(p_estudio uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from estudios where id = p_estudio and activo and licencia_hasta >= current_date);
$$;

create or replace function public.puede_ver_expediente(p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from expedientes e
    where e.id = p_exp
      and public.es_miembro(e.estudio_id)
      and ( public.rol_en(e.estudio_id) = 'admin'
            or e.visibilidad = 'estudio'
            or exists (select 1 from expediente_accesos a
                       where a.expediente_id = e.id and a.usuario_id = auth.uid()) )
  );
$$;

create or replace function public.puede_editar_expediente(p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from expedientes e
    where e.id = p_exp
      and public.estudio_vigente(e.estudio_id)
      and ( public.rol_en(e.estudio_id) = 'admin'
            or ( public.rol_en(e.estudio_id) = 'abogado'
                 and ( e.visibilidad = 'estudio'
                       or exists (select 1 from expediente_accesos a
                                  where a.expediente_id = e.id and a.usuario_id = auth.uid()
                                    and a.puede_editar) ) ) )
  );
$$;

create or replace function public.puede_cargar(p_estudio uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.estudio_vigente(p_estudio) and public.rol_en(p_estudio) in ('admin','abogado');
$$;

-- Registros con expediente opcional (agenda, juicios de prueba)
create or replace function public.puede_ver_opcional(p_estudio uuid, p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select case when p_exp is null then public.es_miembro(p_estudio)
              else public.puede_ver_expediente(p_exp) end;
$$;

create or replace function public.puede_editar_opcional(p_estudio uuid, p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select case when p_exp is null then public.puede_cargar(p_estudio)
              else public.puede_editar_expediente(p_exp) end;
$$;

create or replace function public.puede_ver_juicio(p_juicio text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from juicios_prueba j where j.id = p_juicio
                 and public.puede_ver_opcional(j.estudio_id, j.expediente_id));
$$;

create or replace function public.puede_editar_juicio(p_juicio text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from juicios_prueba j where j.id = p_juicio
                 and public.puede_editar_opcional(j.estudio_id, j.expediente_id));
$$;

-- ── Automatismos (triggers) ──────────────────────────────────────────────

-- Al crearse un usuario en Supabase Auth se crea su perfil
create or replace function public.tg_nuevo_usuario() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into perfiles (id, email, nombre)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'nombre', ''))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists tg_nuevo_usuario on auth.users;
create trigger tg_nuevo_usuario after insert on auth.users
  for each row execute function public.tg_nuevo_usuario();

-- El estudio de cada registro hijo sale siempre del expediente o juicio padre
-- (lo que mande la app se ignora: no se puede "colar" un dato en otro estudio)
create or replace function public.tg_estudio_desde_expediente() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select estudio_id into new.estudio_id from expedientes where id = new.expediente_id;
  if new.estudio_id is null then raise exception 'Expediente inexistente'; end if;
  return new;
end $$;

create or replace function public.tg_adjunto_desde_movimiento() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select expediente_id, estudio_id into new.expediente_id, new.estudio_id
  from movimientos where id = new.movimiento_id;
  if new.expediente_id is null then raise exception 'Movimiento inexistente'; end if;
  return new;
end $$;

create or replace function public.tg_estudio_desde_juicio() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select estudio_id into new.estudio_id from juicios_prueba where id = new.juicio_id;
  if new.estudio_id is null then raise exception 'Juicio inexistente'; end if;
  new.actualizado_en := now();
  return new;
end $$;

-- Si tiene expediente, tiene que ser del mismo estudio
create or replace function public.tg_expediente_mismo_estudio() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.expediente_id is not null and not exists
     (select 1 from expedientes where id = new.expediente_id and estudio_id = new.estudio_id) then
    raise exception 'El expediente no pertenece a este estudio';
  end if;
  new.actualizado_en := now();
  return new;
end $$;

-- Un expediente no se puede pasar a otro estudio; se registra quién lo tocó
create or replace function public.tg_expediente_actualizado() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' and new.estudio_id <> old.estudio_id then
    raise exception 'No se puede mover un expediente a otro estudio';
  end if;
  new.actualizado_en := now();
  new.actualizado_por := coalesce(auth.uid(), new.actualizado_por);
  return new;
end $$;

-- Sólo se habilita a usuarios que sean miembros del mismo estudio
create or replace function public.tg_acceso_valido() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select estudio_id into new.estudio_id from expedientes where id = new.expediente_id;
  if not exists (select 1 from miembros where estudio_id = new.estudio_id and usuario_id = new.usuario_id) then
    raise exception 'El usuario no pertenece al estudio del expediente';
  end if;
  return new;
end $$;

-- Las notificaciones sólo van a miembros del mismo estudio
create or replace function public.tg_notificacion_valida() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from miembros where estudio_id = new.estudio_id and usuario_id = new.para_usuario) then
    raise exception 'El destinatario no pertenece al estudio';
  end if;
  return new;
end $$;

drop trigger if exists tg_mov_estudio on public.movimientos;
create trigger tg_mov_estudio before insert or update on public.movimientos
  for each row execute function public.tg_estudio_desde_expediente();
drop trigger if exists tg_adj_estudio on public.adjuntos;
create trigger tg_adj_estudio before insert or update on public.adjuntos
  for each row execute function public.tg_adjunto_desde_movimiento();
drop trigger if exists tg_prueba_estudio on public.pruebas;
create trigger tg_prueba_estudio before insert or update on public.pruebas
  for each row execute function public.tg_estudio_desde_juicio();
drop trigger if exists tg_agenda_exp on public.agenda;
create trigger tg_agenda_exp before insert or update on public.agenda
  for each row execute function public.tg_expediente_mismo_estudio();
drop trigger if exists tg_juicio_exp on public.juicios_prueba;
create trigger tg_juicio_exp before insert or update on public.juicios_prueba
  for each row execute function public.tg_expediente_mismo_estudio();
drop trigger if exists tg_exp_upd on public.expedientes;
create trigger tg_exp_upd before insert or update on public.expedientes
  for each row execute function public.tg_expediente_actualizado();
drop trigger if exists tg_acceso on public.expediente_accesos;
create trigger tg_acceso before insert or update on public.expediente_accesos
  for each row execute function public.tg_acceso_valido();
drop trigger if exists tg_notif on public.notificaciones;
create trigger tg_notif before insert on public.notificaciones
  for each row execute function public.tg_notificacion_valida();

-- ── Reglas de seguridad por fila (RLS) ───────────────────────────────────

alter table public.estudios           enable row level security;
alter table public.perfiles           enable row level security;
alter table public.miembros           enable row level security;
alter table public.expedientes        enable row level security;
alter table public.expediente_accesos enable row level security;
alter table public.movimientos        enable row level security;
alter table public.adjuntos           enable row level security;
alter table public.agenda             enable row level security;
alter table public.juicios_prueba     enable row level security;
alter table public.pruebas            enable row level security;
alter table public.notificaciones     enable row level security;

-- Borra las reglas anteriores para poder volver a correr el script
do $$ declare r record; begin
  -- sólo las tablas de este script: no toca las de los scripts siguientes (modelos, adjuntos de pruebas, días inhábiles, mensajes)
  for r in select policyname, tablename from pg_policies where schemaname = 'public'
           and tablename in ('estudios','perfiles','miembros','expedientes','expediente_accesos','movimientos',
                             'adjuntos','agenda','juicios_prueba','pruebas','notificaciones') loop
    execute format('drop policy %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

-- Estudios: cada uno ve el suyo; sólo el superadmin los crea y modifica
create policy est_ver   on public.estudios for select using (public.es_superadmin() or public.es_miembro(id));
create policy est_crear on public.estudios for insert with check (public.es_superadmin());
create policy est_mod   on public.estudios for update using (public.es_superadmin()) with check (public.es_superadmin());
create policy est_borrar on public.estudios for delete using (public.es_superadmin());

-- Perfiles: el propio, los compañeros de estudio y el superadmin
create policy per_ver on public.perfiles for select using (
  id = auth.uid() or public.es_superadmin()
  or exists (select 1 from public.miembros m1 join public.miembros m2 on m1.estudio_id = m2.estudio_id
             where m1.usuario_id = auth.uid() and m2.usuario_id = perfiles.id));
create policy per_mod on public.perfiles for update using (id = auth.uid()) with check (id = auth.uid());
-- Nadie puede darse a sí mismo el permiso de superadmin: sólo se edita el nombre
revoke update on public.perfiles from authenticated, anon;
grant  update (nombre) on public.perfiles to authenticated;

-- Miembros: los ve el estudio; los administra el admin del estudio o el superadmin
create policy mie_ver    on public.miembros for select using (public.es_superadmin() or public.es_miembro(estudio_id));
create policy mie_crear  on public.miembros for insert with check (public.es_superadmin() or public.rol_en(estudio_id) = 'admin');
create policy mie_mod    on public.miembros for update using (public.es_superadmin() or public.rol_en(estudio_id) = 'admin')
                                              with check (public.es_superadmin() or public.rol_en(estudio_id) = 'admin');
create policy mie_borrar on public.miembros for delete using (public.es_superadmin() or public.rol_en(estudio_id) = 'admin');

-- Expedientes
-- La regla de lectura mira los datos del propio registro (no lo busca en la tabla):
-- así también vale para un expediente nuevo que se guarda con "insertar o actualizar".
create or replace function public.tiene_acceso(p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from expediente_accesos a where a.expediente_id = p_exp and a.usuario_id = auth.uid());
$$;
create or replace function public.puede_ver_fila_expediente(p_estudio uuid, p_visibilidad text, p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select public.es_miembro(p_estudio)
     and ( public.rol_en(p_estudio) = 'admin' or p_visibilidad = 'estudio' or public.tiene_acceso(p_exp) );
$$;
create policy exp_ver    on public.expedientes for select using (public.puede_ver_fila_expediente(estudio_id, visibilidad, id));
create policy exp_crear  on public.expedientes for insert with check (public.puede_cargar(estudio_id));
create policy exp_mod    on public.expedientes for update using (public.puede_editar_expediente(id))
                                                 with check (public.puede_cargar(estudio_id));
create policy exp_borrar on public.expedientes for delete using (public.rol_en(estudio_id) = 'admin');

-- Quién ve cada expediente restringido: lo decide el admin del estudio
create policy acc_ver on public.expediente_accesos for select using (public.rol_en(estudio_id) = 'admin' or usuario_id = auth.uid());
create policy acc_crear  on public.expediente_accesos for insert with check (public.rol_en(estudio_id) = 'admin');
create policy acc_mod    on public.expediente_accesos for update using (public.rol_en(estudio_id) = 'admin') with check (public.rol_en(estudio_id) = 'admin');
create policy acc_borrar on public.expediente_accesos for delete using (public.rol_en(estudio_id) = 'admin');

-- Movimientos y adjuntos: siguen los permisos de su expediente
create policy mov_ver    on public.movimientos for select using (public.puede_ver_expediente(expediente_id));
create policy mov_crear  on public.movimientos for insert with check (public.puede_editar_expediente(expediente_id));
create policy mov_mod    on public.movimientos for update using (public.puede_editar_expediente(expediente_id)) with check (public.puede_editar_expediente(expediente_id));
create policy mov_borrar on public.movimientos for delete using (public.puede_editar_expediente(expediente_id));

create policy adj_ver    on public.adjuntos for select using (public.puede_ver_expediente(expediente_id));
create policy adj_crear  on public.adjuntos for insert with check (public.puede_editar_expediente(expediente_id));
create policy adj_borrar on public.adjuntos for delete using (public.puede_editar_expediente(expediente_id));

-- Agenda y Control de Pruebas: si están atados a un expediente, siguen sus permisos
create policy age_ver    on public.agenda for select using (public.puede_ver_opcional(estudio_id, expediente_id));
create policy age_crear  on public.agenda for insert with check (public.puede_editar_opcional(estudio_id, expediente_id));
create policy age_mod    on public.agenda for update using (public.puede_editar_opcional(estudio_id, expediente_id)) with check (public.puede_editar_opcional(estudio_id, expediente_id));
create policy age_borrar on public.agenda for delete using (public.puede_editar_opcional(estudio_id, expediente_id));

create policy jui_ver    on public.juicios_prueba for select using (public.puede_ver_opcional(estudio_id, expediente_id));
create policy jui_crear  on public.juicios_prueba for insert with check (public.puede_editar_opcional(estudio_id, expediente_id));
create policy jui_mod    on public.juicios_prueba for update using (public.puede_editar_opcional(estudio_id, expediente_id)) with check (public.puede_editar_opcional(estudio_id, expediente_id));
create policy jui_borrar on public.juicios_prueba for delete using (public.puede_editar_opcional(estudio_id, expediente_id));

create policy pru_ver    on public.pruebas for select using (public.puede_ver_juicio(juicio_id));
create policy pru_crear  on public.pruebas for insert with check (public.puede_editar_juicio(juicio_id));
create policy pru_mod    on public.pruebas for update using (public.puede_editar_juicio(juicio_id)) with check (public.puede_editar_juicio(juicio_id));
create policy pru_borrar on public.pruebas for delete using (public.puede_editar_juicio(juicio_id));

-- Notificaciones: cada uno ve y marca las suyas
create policy not_ver    on public.notificaciones for select using (para_usuario = auth.uid());
create policy not_crear  on public.notificaciones for insert with check (public.es_miembro(estudio_id));
create policy not_mod    on public.notificaciones for update using (para_usuario = auth.uid()) with check (para_usuario = auth.uid());
create policy not_borrar on public.notificaciones for delete using (para_usuario = auth.uid());

-- ── Archivos adjuntos (Storage) ──────────────────────────────────────────
-- Carpeta privada "adjuntos". Ruta de cada archivo: <estudio>/<expediente>/<archivo>

insert into storage.buckets (id, name, public, file_size_limit)
values ('adjuntos', 'adjuntos', false, 26214400)   -- 25 MB por archivo
on conflict (id) do nothing;

create or replace function public.ruta_adjunto_valida(p_ruta text, p_editar boolean) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from expedientes e
    where e.id = split_part(p_ruta, '/', 2)
      and e.estudio_id::text = split_part(p_ruta, '/', 1)
      and case when p_editar then public.puede_editar_expediente(e.id)
               else public.puede_ver_expediente(e.id) end
  );
$$;

drop policy if exists adjuntos_ver    on storage.objects;
drop policy if exists adjuntos_subir  on storage.objects;
drop policy if exists adjuntos_borrar on storage.objects;
create policy adjuntos_ver    on storage.objects for select to authenticated
  using (bucket_id = 'adjuntos' and public.ruta_adjunto_valida(name, false));
create policy adjuntos_subir  on storage.objects for insert to authenticated
  with check (bucket_id = 'adjuntos' and public.ruta_adjunto_valida(name, true));
create policy adjuntos_borrar on storage.objects for delete to authenticated
  using (bucket_id = 'adjuntos' and public.ruta_adjunto_valida(name, true));

-- ── Usuarios anónimos: sin acceso a nada ─────────────────────────────────
revoke all on all tables in schema public from anon;
