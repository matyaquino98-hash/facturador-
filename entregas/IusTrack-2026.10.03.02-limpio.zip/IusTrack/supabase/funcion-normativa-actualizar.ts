// LexTrack — función "normativa-actualizar" (Supabase Edge Function)
// Consulta en InfoLEG (nacionales) y en el Sistema de Información Normativa de la
// Provincia de Buenos Aires qué normas modifican o complementan a las que sigue el
// apartado "Normativa", y guarda las nuevas en la tabla normas_vinculos.
// La usa cualquier usuario con sesión iniciada; los datos son públicos y comunes a todos.
import { createClient } from 'npm:@supabase/supabase-js@2';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const resp = (cuerpo: unknown, status = 200) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

const RE_INFOLEG = /^infoleg:(\d{1,7})$/;
const RE_GBA = /^gba:(\/ar-b\/[a-z-]+\/\d{4}\/\d{1,6}\/\d{1,7})$/;
// Las fuentes oficiales bloquean (403) si se las consulta muy seguido: una norma por vez, con pausa,
// y cada norma como mucho dos veces por día (los datos son comunes a todos los estudios)
const ESPERA_MIN = 12 * 60;
const PAUSA_MS = 1500;
const espera = (ms: number) => new Promise(r => setTimeout(r, ms));
class Bloqueo extends Error {}
const MESES: Record<string, string> = { ene: '01', feb: '02', mar: '03', abr: '04', may: '05', jun: '06', jul: '07', ago: '08', sep: '09', oct: '10', nov: '11', dic: '12' };

function limpiar(html: string) {
  return html.replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&aacute;/g, 'á').replace(/&eacute;/g, 'é').replace(/&iacute;/g, 'í')
    .replace(/&oacute;/g, 'ó').replace(/&uacute;/g, 'ú').replace(/&ntilde;/g, 'ñ').replace(/&uuml;/g, 'ü').replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();
}
async function bajar(url: string, latin = false) {
  const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 20000);
  try {
    const r = await fetch(url, { signal: ctrl.signal, headers: { 'User-Agent': 'LexTrack (seguimiento de normativa)' } });
    if (r.status === 403 || r.status === 429) throw new Bloqueo('La fuente bloqueó temporalmente las consultas (' + r.status + ')');
    if (!r.ok) throw new Error('La fuente respondió ' + r.status);
    const b = await r.arrayBuffer();
    return new TextDecoder(latin ? 'iso-8859-1' : 'utf-8').decode(b);
  } finally { clearTimeout(t); }
}

type Vinculo = { vinculo: string; titulo: string; organismo: string; descripcion: string; publicada: string | null; anio: number | null };

// InfoLEG: "Esta norma es complementada o modificada por…"
async function vinculosInfoleg(id: string): Promise<Vinculo[]> {
  const html = await bajar(`https://servicios.infoleg.gob.ar/infolegInternet/verVinculos.do?modo=2&id=${id}`, true);
  const out: Vinculo[] = [];
  for (const fila of html.split(/<tr[\s>]/i).slice(1)) {
    const m = fila.match(/verNorma\.do\?id=(\d+)"[^>]*>([\s\S]*?)<\/a>([\s\S]*?)<\/td>/i);
    if (!m) continue;
    const celdas = fila.split(/<td[\s>]/i).slice(1).map(c => limpiar(c.split(/<\/td>/i)[0].replace(/^[^>]*>/, '')));
    const f = (celdas[1] || '').match(/(\d{2})-([a-z]{3})-(\d{4})/i);
    out.push({
      vinculo: m[1], titulo: limpiar(m[2]), organismo: limpiar(m[3]),
      descripcion: (celdas[2] || '').slice(0, 500),
      publicada: f && MESES[f[2].toLowerCase()] ? `${f[3]}-${MESES[f[2].toLowerCase()]}-${f[1]}` : null,
      anio: f ? +f[3] : null,
    });
  }
  return out;
}
// Provincia: "Normas relacionadas con…"
async function vinculosGba(ruta: string): Promise<Vinculo[]> {
  const html = await bajar('https://normas.gba.gob.ar' + ruta);
  const i = html.indexOf('Normas relacionadas');
  if (i < 0) return [];
  const tabla = html.slice(i, html.indexOf('</table>', i));
  const out: Vinculo[] = [];
  for (const fila of tabla.split(/<tr[\s>]/i).slice(1)) {
    const m = fila.match(/href="(\/ar-b\/[a-z-]+\/(\d{4})\/\d+\/\d+)"[^>]*>([\s\S]*?)<\/a>/i);
    if (!m) continue;
    const celdas = fila.split(/<td[\s>]/i).slice(1).map(c => limpiar(c.split(/<\/td>/i)[0].replace(/^[^>]*>/, '')));
    out.push({ vinculo: m[1], titulo: limpiar(m[3]), organismo: '', descripcion: (celdas[1] || '').slice(0, 500), publicada: null, anio: +m[2] });
  }
  return out;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const clave = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || Deno.env.get('SUPABASE_SECRET_KEY');
    if (!clave) return resp({ error: 'La función no tiene acceso a la clave del servidor.' }, 500);
    const admin = createClient(url, clave, { auth: { persistSession: false } });

    // Sólo usuarios con sesión iniciada
    const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    const { data: quien } = await admin.auth.getUser(token);
    if (!quien?.user) return resp({ error: 'Sesión inválida. Volvé a ingresar.' }, 401);

    const body = await req.json().catch(() => ({}));
    const pedidas: string[] = Array.isArray(body.normas) ? body.normas.map(String) : [];
    const normas = [...new Set(pedidas.filter(n => RE_INFOLEG.test(n) || RE_GBA.test(n)))].slice(0, 120);
    if (!normas.length) return resp({ error: 'No se indicaron normas válidas.' }, 400);

    const { data: prev } = await admin.from('normas_revision').select('norma, ultima_revision').in('norma', normas);
    const ultima = new Map((prev || []).map(r => [r.norma, new Date(r.ultima_revision).getTime()]));
    const ahora = Date.now();
    const tocan = normas.filter(n => !ultima.has(n) || ahora - (ultima.get(n) as number) > ESPERA_MIN * 60000)
      .sort((a, b) => (ultima.get(a) || 0) - (ultima.get(b) || 0));   // primero las nunca revisadas o más atrasadas

    const resultado: Record<string, { nuevas: number; total: number; error?: string }> = {};
    let bloqueada = '', pendientes = 0;
    const inicio = Date.now();
    // Una norma por vez, con pausa; si la fuente bloquea, se corta y se sigue en la próxima consulta
    for (let i = 0; i < tocan.length; i++) {
      const norma = tocan[i];
      if (bloqueada || Date.now() - inicio > 110000) { pendientes = tocan.length - i; break; }
      if (i) await espera(PAUSA_MS);
      {
        try {
          const mi = norma.match(RE_INFOLEG), mg = norma.match(RE_GBA);
          const lista = mi ? await vinculosInfoleg(mi[1]) : await vinculosGba(mg![1]);
          const esNueva = !ultima.has(norma);
          await admin.from('normas_revision').upsert({ norma, ultima_revision: new Date().toISOString(), cantidad: lista.length, error: null,
            ...(esNueva ? { primera_revision: new Date().toISOString() } : {}) });
          const unicos = [...new Map(lista.map(v => [v.vinculo, v])).values()];
          let nuevas = 0;
          for (let j = 0; j < unicos.length; j += 200) {
            const { data, error } = await admin.from('normas_vinculos')
              .upsert(unicos.slice(j, j + 200).map(v => ({ norma, ...v })), { onConflict: 'norma,vinculo', ignoreDuplicates: true })
              .select('vinculo');
            if (error) throw new Error(error.message);
            nuevas += (data || []).length;
          }
          resultado[norma] = { nuevas: esNueva ? 0 : nuevas, total: lista.length };
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          if (e instanceof Bloqueo) { bloqueada = msg; pendientes = tocan.length - i; break; }   // no se marca como revisada: se reintenta
          await admin.from('normas_revision').upsert({ norma, ultima_revision: new Date().toISOString(), error: msg.slice(0, 300) });
          resultado[norma] = { nuevas: 0, total: 0, error: msg };
        }
      }
    }
    return resp({ ok: true, revisadas: Object.keys(resultado).length, omitidas: normas.length - tocan.length, pendientes, bloqueada, resultado });
  } catch (e) {
    return resp({ error: 'Error inesperado: ' + (e instanceof Error ? e.message : String(e)) }, 500);
  }
});
