-- ════════════════════════════════════════════════════════════════════════
-- LexTrack — Modelos de escritos
--  · Modelos propios de cada estudio (sólo los ve y usa ese estudio).
--  · Datos profesionales de cada usuario (matrícula, domicilios, CUIT) para
--    completar solos los escritos.
-- Se puede volver a correr.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.modelos (
  id              text primary key default gen_random_uuid()::text,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  nombre          text not null,
  categoria       text not null default 'Modelos del estudio',
  cuerpo          text not null default '',
  creado_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  actualizado_en  timestamptz not null default now()
);
create index if not exists ix_modelos_estudio on public.modelos(estudio_id);

create or replace function public.tg_modelo_actualizado() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' and new.estudio_id <> old.estudio_id then
    raise exception 'No se puede mover un modelo a otro estudio';
  end if;
  new.actualizado_en := now();
  return new;
end $$;
drop trigger if exists tg_modelo on public.modelos;
create trigger tg_modelo before insert or update on public.modelos
  for each row execute function public.tg_modelo_actualizado();

alter table public.modelos enable row level security;
drop policy if exists mod_ver    on public.modelos;
drop policy if exists mod_crear  on public.modelos;
drop policy if exists mod_mod    on public.modelos;
drop policy if exists mod_borrar on public.modelos;
create policy mod_ver    on public.modelos for select using (public.es_miembro(estudio_id));
create policy mod_crear  on public.modelos for insert with check (public.puede_cargar(estudio_id));
create policy mod_mod    on public.modelos for update using (public.puede_cargar(estudio_id)) with check (public.puede_cargar(estudio_id));
create policy mod_borrar on public.modelos for delete using (public.puede_cargar(estudio_id));
revoke all on public.modelos from anon;

-- Datos profesionales: cada uno edita sólo los suyos (y su nombre); nada más
alter table public.perfiles add column if not exists datos_prof jsonb not null default '{}'::jsonb;
revoke update on public.perfiles from authenticated, anon;
grant  update (nombre, datos_prof) on public.perfiles to authenticated;
