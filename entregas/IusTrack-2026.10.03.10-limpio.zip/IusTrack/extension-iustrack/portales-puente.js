/* IusTrack — puente de "Importar causas" entre la extensión y IusTrack abierto en Chrome.
   · MEV/SCBA Notificaciones y PJN: atiende "importar" e "importar-consultar" de IusTrack
     (Importar expedientes) y le devuelve la lista como "importar-situacion".
   · SRT y EJE: atiende "leer" y "consultar" de las tarjetas SRT y EJE.
   · Cuando IusTrack pregunta "¿estás?", contesta (aunque IusTrack haya tardado en arrancar).
   Sólo intercambia mensajes con la página: no lee ni toca la sesión ni los datos de IusTrack. */
(() => {
  if (!/IusTrack|LexTrack/i.test(document.title)) return;
  const EXT = 'iustrack-ext', APP = 'iustrack-app', PEXT = 'iustrack-portales-ext', PAPP = 'iustrack-portales-app';
  const enviar = (fuente, tipo, datos) => window.postMessage(Object.assign({ fuente, tipo }, datos || {}), '*');
  const pedir = m => new Promise(r => { try { chrome.runtime.sendMessage(m, x => r(chrome.runtime.lastError ? null : x)); } catch (e) { r(null); } });
  const version = chrome.runtime.getManifest().version;
  const IMPORTA = ['SCBA', 'PJN'], PORTALES = ['SRT', 'EJE'];
  const soloDe = (o, ks) => { const r = {}; ks.forEach(k => { if (o && o[k]) r[k] = o[k]; }); return r; };

  // Lo que IusTrack espera de MEV/SCBA y PJN (como "Mis Causas" y "Relacionados")
  function paraImportar(f, l) {
    const items = (l.items || []).map(x => {
      if (f === 'PJN') return { numero: x.numero, caratula: x.caratula, juzgado: x.juzgado, situacion: x.estado || '', ultAct: x.ultAct || x.inicio || '' };
      const it = { numero: x.numero, caratula: x.caratula, juzgado: x.juzgado, link: x.link || '' };
      const c = (x.link || '').match(/id_?c(?:ausa)?=(\d+)/i), o = (x.link || '').match(/id_?o(?:rganismo)?=(\d+)/i);
      if (c) it.idC = c[1]; if (o) it.idO = o[1];
      return it;
    });
    return { fuente: f, t: l.t, items, error: l.error || '', silencioso: !!l.silencioso };
  }
  async function situacion(f) {
    const [listas, est] = await Promise.all([pedir({ it: 'p-listas' }), pedir({ it: 'p-estado' })]);
    const l = listas && listas[f], e = est && est[f];
    const estado = e && e.msg ? { fuente: f, msg: e.msg === 'login' ? 'login' : e.msg, silencioso: !!e.silencioso } : null;
    enviar(EXT, 'importar-situacion', { estado, resultado: l && l.t && !l.parcial ? paraImportar(f, l) : null });
  }
  const hola = () => { enviar(EXT, 'hola', { version }); enviar(PEXT, 'hola', { version }); };

  window.addEventListener('message', ev => {
    const d = ev.data;
    if (ev.source !== window || !d) return;
    if (d.tipo === 'hola?' && (d.fuente === APP || d.fuente === PAPP)) return hola();
    if (d.fuente === APP) {
      if (d.tipo === 'importar' && IMPORTA.includes(d.origen)) {
        const c = d.credenciales || {};
        pedir({ it: 'p-leer', origen: d.origen, abrir: !d.silencioso, url: '', cuit: String(c.usuario || '').trim().slice(0, 120), clave: String(c.clave || '').slice(0, 200) });
      }
      if (d.tipo === 'importar-consultar') IMPORTA.forEach(situacion);
      return;
    }
    if (d.fuente !== PAPP) return;
    if (d.tipo === 'consultar') {             // (sin saludar acá: IusTrack consulta justamente al recibir el saludo)
      pedir({ it: 'p-listas' }).then(r => enviar(PEXT, 'listas', { listas: soloDe(r, PORTALES) }));
      pedir({ it: 'p-estado' }).then(r => enviar(PEXT, 'estado', { estado: soloDe(r, PORTALES) }));
    }
    if (d.tipo === 'log' && /^(SCBA|PJN|SRT|EJE)$/.test(d.origen || '')) pedir({ it: 'p-logs', origen: d.origen }).then(l => enviar(PEXT, 'log', { origen: d.origen, log: l || [] }));
    if (d.tipo === 'leer' && PORTALES.includes(d.origen || ''))
      pedir({ it: 'p-leer', origen: d.origen, url: String(d.url || ''), abrir: !!d.abrir, cuit: String(d.cuit || '').trim().slice(0, 80), clave: String(d.clave || '').slice(0, 200) });
  });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    if (c.portalListas) {
      const nv = c.portalListas.newValue || {}, ov = c.portalListas.oldValue || {};
      enviar(PEXT, 'listas', { listas: soloDe(nv, PORTALES) });
      IMPORTA.forEach(f => { if (nv[f] && (!ov[f] || ov[f].t !== nv[f].t) && !nv[f].parcial) situacion(f); });
    }
    if (c.portalEstado) {
      enviar(PEXT, 'estado', { estado: soloDe(c.portalEstado.newValue, PORTALES) });
      IMPORTA.forEach(f => { const nv = (c.portalEstado.newValue || {})[f], ov = (c.portalEstado.oldValue || {})[f]; if (nv && (!ov || ov.t !== nv.t)) situacion(f); });
    }
  });
  // Saludo: al cargar y unas veces más (por si IusTrack todavía está arrancando)
  [0, 1500, 3000, 6000, 10000, 20000].forEach(ms => setTimeout(hola, ms));
})();
