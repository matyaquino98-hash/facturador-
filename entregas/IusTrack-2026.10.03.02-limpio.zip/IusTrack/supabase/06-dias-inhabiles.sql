-- ════════════════════════════════════════════════════════════════════════
-- LexTrack — 06: días inhábiles propios del estudio (módulo "Plazos y feriados")
-- Feriados locales, asuetos, suspensiones de plazos por acordada, o
-- correcciones de los feriados que trae la app de fábrica.
-- Se puede correr más de una vez sin problema.
--
-- · Todos los miembros del estudio los ven (se usan para calcular vencimientos).
-- · Cargan, corrigen y borran: administrador y abogados, con licencia vigente.
-- · Cada estudio sólo ve los suyos.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.dias_inhabiles (
  id          text primary key default gen_random_uuid()::text,
  estudio_id  uuid not null references public.estudios(id) on delete cascade,
  desde       date not null,
  hasta       date,                                  -- vacío = un solo día
  motivo      text not null default '',
  ambito      text not null default 'todos' check (ambito in ('todos','nac','pba')),
  tipo        text not null default 'feriado',       -- feriado · no_laborable · feria · asueto · suspension
  cuenta      boolean not null default true,         -- false = no suspende plazos
  reemplaza   text,                                  -- id del día de fábrica que corrige
  baja        boolean not null default false,        -- true = anula el día de fábrica que reemplaza
  creado_por  uuid default auth.uid() references public.perfiles(id) on delete set null,
  creado_en   timestamptz not null default now(),
  check (hasta is null or hasta >= desde)
);
-- Por si la tabla ya existía con una versión anterior
alter table public.dias_inhabiles add column if not exists reemplaza text;
alter table public.dias_inhabiles add column if not exists baja boolean not null default false;
create index if not exists ix_dias_inhabiles_estudio on public.dias_inhabiles(estudio_id, desde);

-- No se puede pasar un día a otro estudio; se anota quién lo cargó
create or replace function public.tg_dia_inhabil() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' then
    if new.estudio_id <> old.estudio_id then raise exception 'No se puede mover a otro estudio'; end if;
    new.creado_por := old.creado_por; new.creado_en := old.creado_en;
  else
    new.creado_por := coalesce(auth.uid(), new.creado_por);
  end if;
  return new;
end $$;
drop trigger if exists tg_dia_inhabil on public.dias_inhabiles;
create trigger tg_dia_inhabil before insert or update on public.dias_inhabiles
  for each row execute function public.tg_dia_inhabil();

alter table public.dias_inhabiles enable row level security;
drop policy if exists dinh_ver       on public.dias_inhabiles;
drop policy if exists dinh_crear     on public.dias_inhabiles;
drop policy if exists dinh_modificar on public.dias_inhabiles;
drop policy if exists dinh_borrar    on public.dias_inhabiles;
create policy dinh_ver       on public.dias_inhabiles for select using (public.es_miembro(estudio_id));
create policy dinh_crear     on public.dias_inhabiles for insert with check (public.puede_cargar(estudio_id));
create policy dinh_modificar on public.dias_inhabiles for update using (public.puede_cargar(estudio_id)) with check (public.puede_cargar(estudio_id));
create policy dinh_borrar    on public.dias_inhabiles for delete using (public.puede_cargar(estudio_id));

revoke all on public.dias_inhabiles from anon;
