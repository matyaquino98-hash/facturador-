-- ════════════════════════════════════════════════════════════════════════
-- LexTrack multi-estudio — Etapa 1b: dueño del sistema y primer estudio
--
-- ANTES de correr esto:
--   Authentication → Users → "Add user" → "Create new user"
--   con TU email y una contraseña, y tildá "Auto Confirm User".
--
-- Si usaste otro email en ese paso, cambialo en la línea de abajo.
-- ════════════════════════════════════════════════════════════════════════

do $$
declare
  v_email   text := 'cristmanu@gmail.com';          -- ← tu email de ingreso
  v_usuario uuid;
  v_estudio uuid;
begin
  select id into v_usuario from auth.users where lower(email) = lower(v_email);
  if v_usuario is null then
    raise exception 'No existe el usuario %. Crealo primero en Authentication → Users.', v_email;
  end if;

  -- Por si el usuario se creó antes de correr el script 01
  insert into public.perfiles (id, email, nombre)
  values (v_usuario, v_email, 'Cristian Manuel Gonçalves')
  on conflict (id) do update set nombre = excluded.nombre;

  -- 1) Dueño del sistema: da de alta estudios y licencias (no ve sus expedientes)
  update public.perfiles set es_superadmin = true where id = v_usuario;

  -- 2) Su propio estudio, con usted como administrador
  select id into v_estudio from public.estudios where nombre = 'CG Gestoría & Consultoría';
  if v_estudio is null then
    insert into public.estudios (nombre, licencia_hasta)
    values ('CG Gestoría & Consultoría', current_date + interval '10 years')
    returning id into v_estudio;
  end if;

  insert into public.miembros (estudio_id, usuario_id, rol)
  values (v_estudio, v_usuario, 'admin')
  on conflict (estudio_id, usuario_id) do update set rol = 'admin', activo = true;

  raise notice 'Listo. Estudio % creado con % como administrador.', v_estudio, v_email;
end $$;

-- Verificación: tiene que mostrar una fila con su estudio y rol "admin"
select e.nombre as estudio, e.licencia_hasta, p.email, m.rol, p.es_superadmin
from public.miembros m
join public.estudios e on e.id = m.estudio_id
join public.perfiles p on p.id = m.usuario_id;
