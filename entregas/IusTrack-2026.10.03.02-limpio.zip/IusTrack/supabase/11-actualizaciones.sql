-- ════════════════════════════════════════════════════════════════════════
-- IusTrack — 11. Actualizaciones desde la nube
-- Cada cambio de IusTrack se entrega como un archivo "IusTrack-actualizacion-<versión>.iustrack".
-- El dueño del sistema lo sube con el botón "🔄 Actualizar" y queda guardado acá: al abrir
-- IusTrack, cada usuario de cada estudio recibe la versión nueva sin reemplazar archivos.
--   version  AAAA.MM.DD.N (se ordena como texto: la mayor es la más nueva)
--   codigo   el bloque de IusTrack completo (no un parche: reemplaza al anterior)
--   huella   SHA-256 del código, para detectar un archivo dañado
-- Leen todos los usuarios con sesión; sólo el dueño del sistema sube o borra.
-- Se puede correr más de una vez sin problema.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.actualizaciones (
  id          uuid primary key default gen_random_uuid(),
  version     text not null unique check (version ~ '^\d{4}\.\d{2}\.\d{2}\.\d{2}$'),
  notas       text not null default '',
  codigo      text not null,
  huella      text not null,
  subido_por  uuid default auth.uid() references public.perfiles(id) on delete set null,
  subido_en   timestamptz not null default now()
);

alter table public.actualizaciones enable row level security;

drop policy if exists act_ver    on public.actualizaciones;
drop policy if exists act_crear  on public.actualizaciones;
drop policy if exists act_borrar on public.actualizaciones;
create policy act_ver    on public.actualizaciones for select using (auth.uid() is not null);
create policy act_crear  on public.actualizaciones for insert with check (public.es_superadmin());
create policy act_borrar on public.actualizaciones for delete using (public.es_superadmin());
-- Sin política de modificación: una versión subida no se cambia (se sube otra más nueva)

notify pgrst, 'reload schema';
