-- ════════════════════════════════════════════════════════════════════════
-- LexTrack — Arreglo: guardar expedientes nuevos
-- La app guarda con "insertar o actualizar" (upsert). En ese caso Postgres
-- también exige que el registro NUEVO pase la regla de lectura, y la regla
-- anterior buscaba el expediente en la tabla (donde todavía no está).
-- Ahora la regla mira los datos del propio registro. Mismo nivel de seguridad.
-- ════════════════════════════════════════════════════════════════════════

create or replace function public.tiene_acceso(p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from expediente_accesos a where a.expediente_id = p_exp and a.usuario_id = auth.uid());
$$;

create or replace function public.puede_ver_fila_expediente(p_estudio uuid, p_visibilidad text, p_exp text) returns boolean
language sql stable security definer set search_path = public as $$
  select public.es_miembro(p_estudio)
     and ( public.rol_en(p_estudio) = 'admin' or p_visibilidad = 'estudio' or public.tiene_acceso(p_exp) );
$$;

drop policy if exists exp_ver on public.expedientes;
create policy exp_ver on public.expedientes for select
  using (public.puede_ver_fila_expediente(estudio_id, visibilidad, id));
