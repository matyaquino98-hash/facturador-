﻿param([Parameter(Mandatory = $true)][string]$Notas, [string]$Raiz = "E:\trabajo\IUSTRAK ON LINE")
# IusTrack — arma una actualización (lo mismo que herramientas\armar-actualizacion.js, para cuando no está Node)
#  1. Toma el bloque (bloque-movimientos-automaticos.html) y le pone versión AAAA.MM.DD.NN
#  2. Guarda actualizaciones\IusTrack-actualizacion-<versión>.iustrack (se sube con "🔄 Actualizar")
#  3. Rearma IusTrack-nube 01-10-26.html, iustrack-app.zip y la carpeta publicar\ desde las bases (…antes-movimientos)
$ErrorActionPreference = 'Stop'
$enc = New-Object System.Text.UTF8Encoding($false)
function Leer($p) { [IO.File]::ReadAllText($p, $enc) }
function Escribir($p, $t) { [IO.File]::WriteAllText($p, $t, $enc) }
$r = { param($p) Join-Path $Raiz $p }

# 1) Código del bloque
$html = Leer (& $r 'bloque-movimientos-automaticos.html')
$ini = $html.IndexOf('<script>'); $fin = $html.LastIndexOf('</script>')
if ($ini -lt 0 -or $fin -lt 0) { throw 'no encontré <script> en el bloque' }
$codigo = $html.Substring($ini + 8, $fin - $ini - 8) -replace '^\n', ''
if ($codigo -match '(?i)</script' -or $codigo.Contains('<!--')) { throw 'el bloque tiene "</script" o "<!--"' }
$cargador = Leer (& $r 'herramientas\cargador.js')

# 2) Versión
$dirAct = & $r 'actualizaciones'
New-Item -ItemType Directory -Force $dirAct | Out-Null
$hoy = Get-Date; $dia = $hoy.ToString('yyyy.MM.dd')
$previas = @(Get-ChildItem $dirAct -Filter '*.iustrack' | ForEach-Object { if ($_.Name -match '(\d{4}\.\d{2}\.\d{2}\.\d{2})\.iustrack$') { $Matches[1] } } | Sort-Object)
$delDia = @($previas | Where-Object { $_.StartsWith($dia) } | ForEach-Object { [int]$_.Substring($_.Length - 2) })
$n = [int]$(if ($delDia.Count) { ($delDia | Measure-Object -Maximum).Maximum + 1 } else { 1 })
$version = '{0}.{1:D2}' -f $dia, $n
if ($previas.Count -and ([string]$previas[-1]).CompareTo($version) -ge 0) { throw "ya hay una versión más nueva: $($previas[-1])" }
$sha = [Security.Cryptography.SHA256]::Create()
$huella = ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($codigo)) | ForEach-Object { $_.ToString('x2') }) -join ''
$archivo = Join-Path $dirAct "IusTrack-actualizacion-$version.iustrack"
$obj = [ordered]@{ formato = 'iustrack-actualizacion'; version = $version; fecha = $hoy.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ'); notas = $Notas; huella = $huella; codigo = $codigo }
Escribir $archivo ($obj | ConvertTo-Json -Compress)
$prueba = (Leer $archivo) | ConvertFrom-Json
if ($prueba.codigo -ne $codigo) { throw 'el .iustrack no se leyó igual' }

# 3) Archivos completos
$escAttr = { param($s) $s.Replace('&', '&amp;').Replace('"', '&quot;').Replace('<', '&lt;') }
$url = ''; try { $url = ((Leer (& $r 'herramientas\config.json')) | ConvertFrom-Json).url } catch {}
$insertar = {
  param($base)
  if ($url -and -not $base.Contains('name="iustrack-url"')) {
    $k = $base.IndexOf('<head>'); $base = $base.Substring(0, $k + 6) + "`n<meta name=`"iustrack-url`" content=`"$(& $escAttr $url)`">" + $base.Substring($k + 6)
  }
  $i = $base.LastIndexOf('</body>'); if ($i -lt 0) { throw 'la base no tiene </body>' }
  $base.Substring(0, $i) +
    "<script id=`"it-bloque`" type=`"text/plain`" data-version=`"$version`" data-notas=`"$(& $escAttr $Notas)`">`n$codigo</script>`n" +
    "<script>`n$cargador</script>`n" + $base.Substring($i)
}
Escribir (& $r 'IusTrack-nube 01-10-26.html') (& $insertar (Leer (& $r 'IusTrack-nube 01-10-26.antes-movimientos.html')))

$tmp = Join-Path $env:TEMP ('iustrack-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
Expand-Archive -LiteralPath (& $r 'iustrack-app.antes-movimientos.zip') -DestinationPath $tmp -Force
# Logo e íconos nuevos (marca\app, se generan con herramientas\generar-marca.js)
$marca = & $r 'marca\app'
if (Test-Path $marca) { Copy-Item "$marca\*" $tmp -Force }
$index = & $insertar (Leer "$tmp\index.html")
$index = [regex]::Replace($index, '<link rel="icon" type="image/png" sizes="64x64" href="data:[^"]*">', '<link rel="icon" type="image/svg+xml" href="favicon.svg"><link rel="icon" type="image/png" sizes="64x64" href="favicon-64.png">')
$index = $index.Replace("'Instalá IusTrack en tu celular'", "(/Android|iPhone|iPad|Mobi/i.test(navigator.userAgent) ? 'Instalá IusTrack en tu celular' : 'Instalá IusTrack en esta computadora')")
Escribir "$tmp\index.html" $index
Escribir "$tmp\sw.js" ([regex]::Replace((Leer "$tmp\sw.js"), "const CACHE = '[^']*'", "const CACHE = 'iustrack-$version'"))
$m = (Leer "$tmp\manifest.webmanifest") | ConvertFrom-Json
$extra = [ordered]@{ orientation = 'any'; background_color = '#FDF7F0'; theme_color = '#FDF7F0'; display_override = @('standalone', 'minimal-ui');
  launch_handler = @{ client_mode = 'focus-existing' }; categories = @('business', 'productivity'); lang = 'es-AR'; dir = 'ltr' }
foreach ($k in $extra.Keys) { $m | Add-Member -NotePropertyName $k -NotePropertyValue $extra[$k] -Force }
Escribir "$tmp\manifest.webmanifest" ($m | ConvertTo-Json -Depth 6)
$zipTmp = Join-Path $env:TEMP "iustrack-app-$version.zip"
if (Test-Path $zipTmp) { Remove-Item $zipTmp -Force }
Compress-Archive -Path "$tmp\*" -DestinationPath $zipTmp -Force
Copy-Item $zipTmp (& $r 'iustrack-app.zip') -Force

# 4) Carpeta publicar
$pub = & $r 'publicar'
if (Test-Path $pub) { Remove-Item $pub -Recurse -Force }
New-Item -ItemType Directory $pub | Out-Null
Copy-Item "$tmp\*" $pub
$h = (@('/', '/index.html', '/sw.js', '/manifest.webmanifest') | ForEach-Object { "$_`n  Cache-Control: no-cache" }) -join "`n"
Escribir "$pub\_headers" ($h + "`n/manifest.webmanifest`n  Content-Type: application/manifest+json`n/*`n  X-Content-Type-Options: nosniff`n  Referrer-Policy: strict-origin-when-cross-origin`n")
Escribir "$pub\version.txt" ($version + "`n")
Remove-Item $tmp -Recurse -Force; Remove-Item $zipTmp -Force

"Versión $version"
"  Actualización: actualizaciones\IusTrack-actualizacion-$version.iustrack ($([math]::Round((Get-Item $archivo).Length / 1KB)) KB)"
"  IusTrack:      IusTrack-nube 01-10-26.html e iustrack-app.zip"
"  Para publicar: carpeta publicar\ (arrastrarla a Netlify)$(if ($url) { ' → ' + $url })"
