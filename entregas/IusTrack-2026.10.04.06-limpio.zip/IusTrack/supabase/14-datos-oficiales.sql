-- ════════════════════════════════════════════════════════════════════════
-- IusTrack — 14: datos oficiales del estudio (pantalla "Datos oficiales")
-- Los índices y tasas que usan las calculadoras: RIPTE, IPC INDEC, IPC de la
-- Ciudad (IDECBA), UMA Ley 27.423 y tasa activa del Banco Nación.
-- IusTrack ya trae las series de fábrica; acá se guardan los meses nuevos que
-- se actualizan desde internet o se pegan desde las webs oficiales, así los
-- usa todo el estudio.
-- Se puede correr más de una vez sin problema.
--
-- · Todos los miembros del estudio los ven.
-- · Cargan, corrigen y borran: administrador y abogados, con licencia vigente.
-- · Cada estudio sólo ve los suyos.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.datos_oficiales (
  id           text primary key,                  -- <estudio>:<serie>:<periodo>
  estudio_id   uuid not null references public.estudios(id) on delete cascade,
  serie        text not null,                     -- ripte · ipc · ipcgba · uma · bna
  periodo      text not null,                     -- 'AAAA-MM' (mensual) o 'AAAA-MM-DD' (tasa vigente desde)
  valor        numeric not null,
  fuente       text not null default '',
  cargado_por  uuid default auth.uid() references public.perfiles(id) on delete set null,
  cargado_en   timestamptz not null default now(),
  unique (estudio_id, serie, periodo)
);
create index if not exists ix_datos_oficiales_estudio on public.datos_oficiales(estudio_id, serie, periodo);

-- No se puede pasar un dato a otro estudio; se anota quién lo cargó y cuándo
create or replace function public.tg_dato_oficial() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' and new.estudio_id <> old.estudio_id then raise exception 'No se puede mover a otro estudio'; end if;
  new.cargado_por := coalesce(auth.uid(), new.cargado_por);
  new.cargado_en := now();
  return new;
end $$;
drop trigger if exists tg_dato_oficial on public.datos_oficiales;
create trigger tg_dato_oficial before insert or update on public.datos_oficiales
  for each row execute function public.tg_dato_oficial();

alter table public.datos_oficiales enable row level security;
drop policy if exists dof_ver       on public.datos_oficiales;
drop policy if exists dof_crear     on public.datos_oficiales;
drop policy if exists dof_modificar on public.datos_oficiales;
drop policy if exists dof_borrar    on public.datos_oficiales;
create policy dof_ver       on public.datos_oficiales for select using (public.es_miembro(estudio_id));
create policy dof_crear     on public.datos_oficiales for insert with check (public.puede_cargar(estudio_id));
create policy dof_modificar on public.datos_oficiales for update using (public.puede_cargar(estudio_id)) with check (public.puede_cargar(estudio_id));
create policy dof_borrar    on public.datos_oficiales for delete using (public.puede_cargar(estudio_id));

revoke all on public.datos_oficiales from anon;
grant select, insert, update, delete on public.datos_oficiales to authenticated;
