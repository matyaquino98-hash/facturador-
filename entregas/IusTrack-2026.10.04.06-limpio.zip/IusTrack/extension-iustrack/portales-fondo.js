/* IusTrack — importar causas de los 4 portales (MEV/SCBA Notificaciones, PJN, SRT y EJE).
   Corre dentro del segundo plano de la extensión (fondo.js lo carga con importScripts).
   · "Importar causas" (desde IusTrack): abre el portal en una pestaña en segundo plano, entra
     con el usuario guardado en IusTrack, llega solo al listado, lo recorre página por página
     y devuelve las causas. Si no puede, IusTrack pide abrirlo una vez a la vista.
   · Usuario y clave: sólo en la memoria de la sesión de Chrome mientras dura la lectura y
     sólo para la pestaña que abrió la extensión. Las listas quedan en esta computadora. */
(() => {
  const INICIO = {
    SCBA: 'https://notificaciones.scba.gov.ar/InterfazBootstrap/Login.aspx',
    PJN: 'https://scw.pjn.gov.ar/scw/consultaListaRelacionados.seam',
    SRT: 'https://auth.afip.gob.ar/contribuyente_/login.xhtml',
    EJE: 'https://eje.juscaba.gob.ar/'
  };
  const PERMITIDA = /^https:\/\/(([a-z0-9-]+\.)*srt\.gob\.ar|eje\.juscaba\.gob\.ar|eje\.jus\.gov\.ar|notificaciones\.scba\.gov\.ar|scw\.pjn\.gov\.ar)\//i;
  const ESPERA_MIN = 5, MAX_PAGINAS = 80;
  const MENSAJES = new Set(['p-listas', 'p-estado', 'p-leer', 'p-pendiente', 'p-lista', 'p-salto', 'p-login', 'p-log', 'p-logs', 'p-reiniciar', 'p-traer']);
  // Registro de la última lectura de cada portal ("Ver qué pasó" en IusTrack): sólo páginas
  // visitadas y pasos dados, nunca usuarios ni claves.
  async function anotar(origen, paso, donde) {
    const l = (await leer('portalLog')) || {};
    const v = (l[origen] || []).concat({ t: Date.now(), paso: String(paso).slice(0, 200), donde: String(donde || '').slice(0, 160) }).slice(-60);
    l[origen] = v; await poner({ portalLog: l });
  }
  const sinDatos = u => { try { const x = new URL(u); return x.host + x.pathname; } catch (e) { return ''; } };
  const leer = k => new Promise(r => chrome.storage.local.get(k, o => r(o[k])));
  const poner = o => new Promise(r => chrome.storage.local.set(o, r));
  const claveCausa = x => String(x.numero || '').toUpperCase().replace(/\s+/g, '');
  const sesion = chrome.storage.session || chrome.storage.local;
  const claves = {
    leer: o => new Promise(r => sesion.get('portalClaves', x => r((x && x.portalClaves || {})[o] || null))),
    poner: (o, v) => new Promise(r => sesion.get('portalClaves', x => { const c = (x && x.portalClaves) || {}; if (v) c[o] = v; else delete c[o]; sesion.set({ portalClaves: c }, r); }))
  };
  const tabsDe = p => p.tabs || [p.tabId];

  async function estado(origen, msg, extra) {
    const e = (await leer('portalEstado')) || {};
    e[origen] = Object.assign({ msg, t: Date.now() }, extra || {});
    await poner({ portalEstado: e });
  }
  async function guardarLista(origen, cambios) {
    const l = (await leer('portalListas')) || {};
    l[origen] = Object.assign({ items: [] }, l[origen] || {}, cambios, { t: Date.now() });
    await poner({ portalListas: l });
    return l[origen];
  }
  async function terminar(origen, cerrarTab) {
    const pend = (await leer('portalPend')) || {}, p = pend[origen];
    delete pend[origen];
    await poner({ portalPend: pend });
    chrome.alarms.clear('vence-' + origen);
    await claves.poner(origen, null);
    if (p && cerrarTab && !p.abrir) tabsDe(p).forEach(id => id && chrome.tabs.remove(id).catch(() => {}));
    await estado(origen, '');
  }

  async function manejar(m, snd) {
    const origen = m.origen;
    if (m.it === 'p-listas') return (await leer('portalListas')) || {};
    if (m.it === 'p-estado') return (await leer('portalEstado')) || {};
    if (m.it === 'p-leer') {
      if (!INICIO[origen]) return { error: 'origen' };
      // La SRT rechaza ("Error de validación") que se entre directo a una dirección guardada:
      // siempre se entra por la Clave Fiscal de AFIP
      const url = origen !== 'SRT' && PERMITIDA.test(m.url || '') ? m.url : INICIO[origen];
      const lg = (await leer('portalLog')) || {}; lg[origen] = []; await poner({ portalLog: lg });
      await anotar(origen, m.abrir ? 'Empieza (a la vista)' : 'Empieza (en segundo plano)', sinDatos(url));
      const pend = (await leer('portalPend')) || {};
      if (pend[origen]) tabsDe(pend[origen]).forEach(id => id && chrome.tabs.remove(id).catch(() => {}));
      const tab = await chrome.tabs.create({ url, active: !!m.abrir });
      pend[origen] = { t: Date.now(), tabId: tab.id, tabs: [tab.id], saltos: 0, paginas: 0, reinicios: 0, nueva: true, abrir: !!m.abrir, cuit: m.cuit || '' };
      await poner({ portalPend: pend });
      // Si recién falló el ingreso con esa clave, no se vuelve a probar (se completa sólo el usuario)
      const ant = ((await leer('portalListas')) || {})[origen];
      const clave = ant && ant.error === 'login' && Date.now() - (ant.t || 0) < 3 * 60 * 1000 ? '' : (m.clave || '');
      await claves.poner(origen, m.cuit ? { usuario: m.cuit, clave } : null);
      chrome.alarms.create('vence-' + origen, { delayInMinutes: ESPERA_MIN });
      await estado(origen, m.abrir ? 'abierto' : 'leyendo', { silencioso: !m.abrir });
      return { ok: true };
    }
    if (m.it === 'p-pendiente') {
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      if (!p || Date.now() - p.t > 30 * 60 * 1000) return null;
      const esta = !!(snd.tab && tabsDe(p).includes(snd.tab.id)), r = { cuit: p.cuit, abrir: p.abrir, esta, vuelta: (p.t || 0) + '-' + (p.reinicios || 0) };
      if (esta) { const c = await claves.leer(origen); if (c) { r.usuario = c.usuario; r.clave = c.clave; } }
      return r;
    }
    if (m.it === 'p-lista') {
      if (!INICIO[origen] || !Array.isArray(m.items)) return { error: 'datos' };
      const items = m.items.filter(x => x && x.numero).slice(0, 3000).map(x => ({
        numero: String(x.numero).slice(0, 80), caratula: String(x.caratula || '').slice(0, 400), motivo: String(x.motivo || '').slice(0, 200),
        damnificado: String(x.damnificado || '').slice(0, 200), juzgado: String(x.juzgado || '').slice(0, 200), inicio: String(x.inicio || '').slice(0, 30),
        estado: String(x.estado || '').slice(0, 120), ultAct: String(x.ultAct || '').slice(0, 30),
        link: /^https:\/\//i.test(x.link || '') ? String(x.link).slice(0, 600) : '' }));
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      const ant = ((await leer('portalListas')) || {})[origen];
      // Una lectura nueva reemplaza la lista; sus páginas siguientes se van sumando
      const base = p && p.nueva ? [] : ((ant && ant.items) || []);
      const mapa = new Map(base.map(x => [claveCausa(x), x]));
      items.forEach(x => mapa.set(claveCausa(x), Object.assign({}, mapa.get(claveCausa(x)) || {}, x)));
      const esLectura = !!(p && snd.tab && tabsDe(p).includes(snd.tab.id));
      if (p) { p.nueva = false; p.paginas = (p.paginas || 0) + 1; await poner({ portalPend: pend }); }
      const sigue = !!(m.parcial && p && p.paginas < MAX_PAGINAS);
      await anotar(origen, `Leyó ${items.length} causa(s) en esta página` + (m.parcial ? ' (sigue a la página siguiente)' : ''), sinDatos(m.url));
      if (sigue) { await guardarLista(origen, { items: [...mapa.values()], parcial: true }); return { ok: true, sigue: true, total: mapa.size }; }
      const r = await guardarLista(origen, { items: [...mapa.values()], url: PERMITIDA.test(m.url || '') ? m.url : (ant && ant.url) || '', error: '', parcial: false, silencioso: p ? !p.abrir : false });
      await terminar(origen, esLectura);
      return { ok: true, total: r.items.length };
    }
    if (m.it === 'p-log') { await anotar(origen, m.paso, m.donde); return { ok: true }; }
    if (m.it === 'p-logs') return ((await leer('portalLog')) || {})[origen] || [];
    // El portal respondió con un error (por ejemplo "Error de validación" de la SRT):
    // se vuelve a empezar desde el ingreso una sola vez
    if (m.it === 'p-reiniciar') {
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      if (!p || !snd.tab || !tabsDe(p).includes(snd.tab.id)) return { ok: false };
      if ((p.reinicios || 0) < 1) {
        p.reinicios = (p.reinicios || 0) + 1; p.saltos = 0; await poner({ portalPend: pend });
        await anotar(origen, 'El portal respondió "' + String(m.motivo || 'error').slice(0, 80) + '": vuelve a empezar desde el ingreso', sinDatos(m.url));
        chrome.tabs.update(snd.tab.id, { url: INICIO[origen] }).catch(() => {});
        return { ok: true };
      }
      await anotar(origen, 'El portal volvió a responder "' + String(m.motivo || 'error').slice(0, 80) + '"', sinDatos(m.url));
      await guardarLista(origen, { error: `${origen === 'SRT' ? 'La SRT' : 'El portal'} respondió "${String(m.motivo || 'error').slice(0, 80)}". Probá de nuevo en un rato.`, silencioso: !p.abrir });
      if (!p.abrir) await terminar(origen, true);
      return { ok: false };
    }
    // Un paso de la navegación automática hasta el listado (como mucho 8 por lectura)
    if (m.it === 'p-salto') {
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      if (!p || !snd.tab || !tabsDe(p).includes(snd.tab.id)) return { ok: false };
      p.saltos = (p.saltos || 0) + 1; await poner({ portalPend: pend });
      return { ok: p.saltos <= 8 };
    }
    if (m.it === 'p-login') {
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      if (!p) return null;
      await anotar(origen, 'El portal no aceptó el ingreso (o pide entrar a mano)', '');
      await guardarLista(origen, { error: 'login', silencioso: !p.abrir });
      if (!p.abrir) { await terminar(origen, true); return { ok: true }; }
      await estado(origen, 'login', { silencioso: false });
      return { ok: true };
    }
    return null;
  }
  // Datos oficiales: IusTrack pide una página de un organismo (las webs no dejan leerse desde la app).
  // Sólo estas webs, sólo lectura (GET sin cookies) y como mucho 4 MB de texto.
  const OFICIALES = /^https:\/\/(www\.)?(bna\.com\.ar|argentina\.gob\.ar|indec\.gob\.ar|estadisticaciudad\.gob\.ar|consejo\.org\.ar|cpacf\.org\.ar|csjn\.gov\.ar|boletinoficial\.gob\.ar|srt\.gob\.ar|scba\.gov\.ar|datos\.gob\.ar|apis\.datos\.gob\.ar)\//i;
  async function traer(url) {
    if (!OFICIALES.test(url || '')) return { ok: false, error: 'esa web no está entre las oficiales permitidas' };
    try {
      const r = await fetch(url, { credentials: 'omit', cache: 'no-store', redirect: 'follow' });
      if (!r.ok) return { ok: false, error: 'la web respondió ' + r.status };
      const t = await r.text();
      return { ok: true, texto: t.slice(0, 4e6), url: r.url };
    } catch (e) { return { ok: false, error: String(e && e.message || e) }; }
  }
  chrome.runtime.onMessage.addListener((m, snd, responder) => {
    if (m && m.it === 'p-traer') { traer(m.url).then(responder); return true; }
    if (!m || !MENSAJES.has(m.it)) return;                // los demás mensajes son de la procuración y las descargas
    manejar(m, snd || {}).then(responder, e => responder({ error: String(e && e.message || e) }));
    return true;
  });
  // Si el portal abre el servicio en otra pestaña (AFIP → SRT), esa pestaña pasa a ser parte de la lectura
  chrome.tabs.onCreated.addListener(async tab => {
    if (!tab.openerTabId) return;
    const pend = (await leer('portalPend')) || {}; let cambio = false;
    Object.values(pend).forEach(p => { if (tabsDe(p).includes(tab.openerTabId)) { p.tabs = tabsDe(p).concat(tab.id); p.tabId = tab.id; cambio = true; } });
    if (cambio) await poner({ portalPend: pend });
  });
  // Si se cierra la pestaña del portal que estaba a la vista, la lectura se da por terminada
  chrome.tabs.onRemoved.addListener(async id => {
    const pend = (await leer('portalPend')) || {};
    for (const [origen, p] of Object.entries(pend)) {
      if (!tabsDe(p).includes(id)) continue;
      p.tabs = tabsDe(p).filter(x => x !== id);
      if (p.tabs.length) { p.tabId = p.tabs[p.tabs.length - 1]; await poner({ portalPend: pend }); continue; }
      await guardarLista(origen, { error: 'Se cerró la pestaña del portal antes de leer el listado. Tocá "Importar causas" de nuevo.', silencioso: !p.abrir });
      await terminar(origen, false);
    }
  });
  chrome.alarms.onAlarm.addListener(async a => {
    const m = /^vence-(SCBA|PJN|SRT|EJE)$/.exec(a.name); if (!m) return;
    const origen = m[1], pend = (await leer('portalPend')) || {}, p = pend[origen];
    if (!p) return;
    if (p.abrir) { await estado(origen, 'esperando', { silencioso: false }); return; }
    await anotar(origen, 'Pasaron ' + ESPERA_MIN + ' minutos sin encontrar el listado', '');
    await guardarLista(origen, { error: 'No se encontró tu listado de causas en segundo plano. Tocá "Ver qué pasó".', silencioso: true });
    await terminar(origen, true);
  });
})();
