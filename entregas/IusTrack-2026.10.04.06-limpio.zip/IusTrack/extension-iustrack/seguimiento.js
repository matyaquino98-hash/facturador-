/* IusTrack — movimientos automáticos desde la MEV y el PJN
   Nivel 1: al abrir un expediente en la MEV o el PJN, se leen sus movimientos.
   Nivel 2: cada tanto, con Chrome abierto y la sesión iniciada, se revisan solos los
            expedientes que IusTrack le pasó a la extensión (MEV por pedido directo,
            PJN en una ventana minimizada que recorre tus Favoritos).
   Lo nuevo queda en una "bandeja" y IusTrack lo carga en cuanto está abierto
   (puente.js). La extensión nunca ve ni guarda usuarios, contraseñas ni la sesión
   de IusTrack: la carga la hace la app con tu propio ingreso. */

const IT = {
  DIAS_PRIMERA_VEZ: 15,      // la primera vez que se lee un expediente, se traen los últimos 15 días
  MAX_PROVEIDOS: 6,          // textos de proveídos de la MEV que se piden por expediente y por lectura
  PAUSA_MEV: 2500,           // entre pedidos a la MEV (corta si se le pide rápido)
  PAUSAS_MEV: [90e3, 150e3, 240e3, 300e3, 300e3],   // esperas cuando la MEV corta, antes de reintentar
  CADA_MIN: 180,             // revisión automática cada 3 horas
  PJN_ESPERA_MIN: 1.5,       // tiempo máximo por expediente del PJN en la revisión
  BANDEJA_MAX: 300,
  BANDEJA_DIAS: 30
};
const PJN_FAVORITOS = 'https://scw.pjn.gov.ar/scw/consultaListaFavoritos.seam';

// Espera larga sin que Chrome duerma la extensión (la duerme tras 30 s sin actividad)
async function dormirVivo(ms) {
  const fin = Date.now() + ms;
  while (Date.now() < fin) {
    await dormir(Math.min(20000, fin - Date.now()));
    try { await chrome.runtime.getPlatformInfo(); } catch (e) {}
  }
}
const sget = async k => (await chrome.storage.local.get(k))[k];
const sset = (k, v) => chrome.storage.local.set({ [k]: v });

// Las lecturas y escrituras del almacenamiento se hacen de a una, para que dos
// capturas al mismo tiempo no se pisen.
let cola = Promise.resolve();
function enCola(fn) { const p = cola.then(fn, fn); cola = p.catch(() => {}); return p; }

// Lectura de la MEV y utilidades de texto: lector.js (se carga antes, en fondo.js)

async function mevCompletarTextos(movs) {
  // Primero los más recientes; el resto queda con el rótulo de la grilla
  const orden = movs.slice().sort((a, b) => (b.fecha || '').localeCompare(a.fecha || '')).slice(0, IT.MAX_PROVEIDOS);
  for (const mv of orden) {
    try {
      await dormirVivo(IT.PAUSA_MEV);     // mismo ritmo que la grilla: la MEV corta si se le pide rápido
      const { html } = await traerTexto(mv.url);
      if (mevCorto(html)) break;          // la MEV pidió pausa: queda sólo el rótulo
      mv.texto = mevTextoProveido(html);
    } catch (e) { break; }
  }
}

// ── Captura común (MEV y PJN) ────────────────────────────────────────────
function claveCausa(c) { return c.fuente === 'MEV' ? `MEV:${c.nidCausa}_${c.pidJuzgado}` : `PJN:${c.cam}-${c.num}-${c.anio}`; }
function nombreCausa(c) { return c.fuente === 'MEV' ? (c.caratula || c.numero || 'Expediente de la MEV') : `${c.cam} ${c.num}/${c.anio}`; }

// Devuelve { nuevos, primera }. "nuevos" son los que quedan en la bandeja.
async function procesarCaptura(causa, movs, origen) {
  const clave = claveCausa(causa);
  // 1) Cuáles son nuevos (sin escribir todavía, para no trabar la cola mientras se piden textos)
  const vistosAntes = (await sget('itVistos') || {})[clave];
  const primera = !vistosAntes;
  const conocidos = new Set(vistosAntes || []);
  let aEnviar = movs.filter(m => !conocidos.has(m.clave));
  if (primera) { const desde = hoyMenos(IT.DIAS_PRIMERA_VEZ); aEnviar = aEnviar.filter(m => (m.fecha || '9999') >= desde); }

  if (causa.fuente === 'MEV' && aEnviar.length) await mevCompletarTextos(aEnviar);

  // 2) Se anotan como vistos y se dejan en la bandeja
  await enCola(async () => {
    const vistos = await sget('itVistos') || {};
    const set = new Set(vistos[clave] || []);
    movs.forEach(m => set.add(m.clave));
    vistos[clave] = [...set].slice(-3000);
    await sset('itVistos', vistos);
    if (!aEnviar.length) return;
    const limite = Date.now() - IT.BANDEJA_DIAS * 864e5;
    const bandeja = (await sget('itBandeja') || []).filter(x => x.t > limite);
    bandeja.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7), t: Date.now(), origen, primera, causa,
      movs: aEnviar.map(m => ({ clave: m.clave, fecha: m.fecha, tipo: m.tipo, texto: m.texto || '' })) });
    await sset('itBandeja', bandeja.slice(-IT.BANDEJA_MAX));
  });

  if (origen === 'revision') {
    await registrar({ fuente: causa.fuente, nombre: nombreCausa(causa), causa, primera,
      nuevos: aEnviar.map(m => ({ fecha: m.fecha, tipo: m.tipo })) });
  }
  if (origen === 'revision' && !primera && aEnviar.length) {
    chrome.notifications.create('it-' + Date.now(), {
      type: 'basic', iconUrl: 'icono.png', priority: 2,
      title: `IusTrack: ${aEnviar.length === 1 ? 'un movimiento nuevo' : aEnviar.length + ' movimientos nuevos'}`,
      message: `${nombreCausa(causa)}\n${aEnviar.map(m => m.tipo).slice(0, 3).join(' · ')}`
    });
  }
  return { nuevos: aEnviar.length, primera };
}

async function appAbierta() { return Date.now() - (await sget('itAppVista') || 0) < 90 * 1000; }
async function anotarEstado(cambios) {
  await enCola(async () => sset('itEstado', Object.assign(await sget('itEstado') || {}, cambios)));
}

// ── Informe de la procuración ────────────────────────────────────────────
// Cada revisión es una "corrida": se anota qué se revisó, qué se encontró y qué
// no se pudo revisar. Al terminar se guarda como informe (los últimos 10).
async function registrar(entrada) {
  await enCola(async () => {
    const c = await sget('itCorrida');
    if (!c || c.fin) return;
    c.items.push(entrada);
    await sset('itCorrida', c);
  });
}
async function corridaCambiar(cambios) {
  await enCola(async () => { const c = await sget('itCorrida'); if (c) await sset('itCorrida', Object.assign(c, cambios)); });
}
// La MEV avisa { mevListo: true } y el PJN { pjnPend: false }: se cierra cuando terminaron los dos
async function cerrarCorrida(cambios) {
  let c;
  await enCola(async () => {
    c = await sget('itCorrida');
    if (!c) return;
    Object.assign(c, cambios || {});
    if (!c.mevListo || c.pjnPend) { await sset('itCorrida', c); c = null; return; }
    c.fin = Date.now();
    const informes = [c].concat(await sget('itInformes') || []).slice(0, 10);
    await sset('itInformes', informes);
    await chrome.storage.local.remove('itCorrida');
  });
  if (!c) return;
  const conNov = c.items.filter(x => x.nuevos.length && !x.primera);
  const total = conNov.reduce((n, x) => n + x.nuevos.length, 0);
  chrome.notifications.create('it-informe-' + Date.now(), {
    type: 'basic', iconUrl: 'icono.png', priority: 1,
    title: 'IusTrack: procuración terminada',
    message: total ? `${total} movimiento(s) nuevo(s) en ${conNov.length} expediente(s). El informe está en IusTrack → ⚖ Procuración.`
                   : `Sin novedades en ${c.items.filter(x => !x.error).length} expediente(s) revisados.`
  });
}

// ── Nivel 2: revisión periódica ──────────────────────────────────────────
let revisando = false;
async function revisar(manual) {
  if (revisando) return;
  const cfg = await sget('itConfig') || { auto: true };
  if (!manual && cfg.auto === false) return;
  const seg = await sget('itSeguimiento');
  if (!seg || !seg.lista || !seg.lista.length) {
    await anotarEstado({ ultima: Date.now(), aviso: 'Abrí IusTrack una vez con la extensión instalada: así sabe qué expedientes revisar.' });
    return;
  }
  const enCurso = await sget('itRevPjn');
  if (enCurso && Date.now() - enCurso.t < 30 * 60 * 1000) return;   // todavía está recorriendo el PJN
  if (enCurso) await chrome.storage.local.remove('itRevPjn');       // quedó colgada (p. ej. se cerró Chrome)
  revisando = true;
  const listaPjn = seg.lista.filter(x => x.f === 'PJN');
  await sset('itCorrida', { id: Date.now().toString(36), inicio: Date.now(), manual: !!manual, total: seg.lista.length,
    items: [], mev: '', pjn: listaPjn.length ? 'Revisando…' : '' });
  // El PJN va en paralelo, en su ventana minimizada; el informe se cierra cuando terminan los dos
  const pjnEnCurso = listaPjn.length ? await pjnEmpezar(listaPjn) : false;
  await corridaCambiar({ pjnPend: pjnEnCurso });
  let nuevos = 0, leidos = 0, mev = '';
  try {
    await anotarEstado({ aviso: '', mev: 'Revisando…' });
    // MEV: un pedido por expediente, con pausa. Se arranca donde quedó la vez
    // anterior, así una revisión cortada no deja siempre afuera a los mismos.
    const listaMev = seg.lista.filter(x => x.f === 'MEV');
    const desde = (await sget('itMevCursor') || 0) % (listaMev.length || 1);
    const orden = listaMev.slice(desde).concat(listaMev.slice(0, desde));
    let i = 0, pausas = 0;
    for (; i < orden.length; i++) {
      const it = orden[i];
      const url = /procesales\.asp/i.test(it.url || '') ? it.url
        : `${MEV}procesales.asp?nidCausa=${encodeURIComponent(it.nidCausa)}&pidJuzgado=${encodeURIComponent(it.pidJuzgado || '')}`;
      let r;
      try { r = await traerTexto(url); } catch (e) { mev = 'No hubo conexión con la MEV.'; break; }
      if (mevPideIngreso(r.html, r.url)) { mev = 'Se venció la sesión de la MEV: iniciá sesión para que se revisen tus expedientes.'; break; }
      if (mevCorto(r.html)) {
        // La MEV frena cuando se le pide mucho seguido: se espera y se reintenta el mismo
        if (pausas >= IT.PAUSAS_MEV.length) { mev = 'La MEV siguió pidiendo pausa: se continúa en la próxima revisión.'; break; }
        await corridaCambiar({ mev: `La MEV pidió una pausa: se reanuda en ${Math.round(IT.PAUSAS_MEV[pausas] / 60000)} min…` });
        await dormirVivo(IT.PAUSAS_MEV[pausas++]);
        await corridaCambiar({ mev: 'Revisando…' });
        i--; continue;
      }
      const { causa, movs } = mevLeerGrilla(r.html, url);
      if (!causa.caratula) causa.caratula = it.nombre || '';
      nuevos += (await procesarCaptura(causa, movs, 'revision')).nuevos; leidos++;
      await dormirVivo(IT.PAUSA_MEV);
    }
    // Los que no se llegaron a revisar quedan en el informe, y la próxima arranca por ellos
    const faltan = orden.slice(i);
    await sset('itMevCursor', faltan.length ? (desde + i) % listaMev.length : 0);
    for (const it of faltan)
      await registrar({ fuente: 'MEV', nombre: it.nombre, causa: { fuente: 'MEV', nidCausa: it.nidCausa, pidJuzgado: it.pidJuzgado, caratula: it.nombre },
        nuevos: [], error: 'No se llegó a revisar: ' + mev.charAt(0).toLowerCase() + mev.slice(1) });
    mev = (mev ? mev + ' ' : '') + `${leidos} de ${listaMev.length} expediente(s) revisados · ${nuevos} movimiento(s) nuevo(s).`;
    await anotarEstado({ ultima: Date.now(), mev });
    await corridaCambiar({ mev });
  } catch (e) {
    await corridaCambiar({ mev: 'Error al revisar la MEV: ' + e.message });
  } finally { revisando = false; }
  await cerrarCorrida({ mevListo: true });
}

// PJN: no tiene links fijos. Se abre una ventana minimizada con tus Favoritos y,
// expediente por expediente, contenido.js lo busca y toca el ojo; pjn-capturar.js
// lee la grilla y avisa; se pasa al siguiente. El estado vive en el almacenamiento
// porque Chrome puede dormir este proceso entre paso y paso.
const pjnUrl = it => `${PJN_FAVORITOS}#lextrack=${it.cam}-${it.num}-${it.anio}`;
async function pjnEmpezar(lista) {
  const actual = await sget('itRevPjn');
  if (actual && Date.now() - actual.t < 30 * 60 * 1000) return false;   // ya hay una en curso
  if (!lista.length) return false;
  let win;
  try {
    try { win = await chrome.windows.create({ url: pjnUrl(lista[0]), state: 'minimized' }); }
    catch (e) { win = await chrome.windows.create({ url: pjnUrl(lista[0]), focused: false }); }
  } catch (e) { await corridaCambiar({ pjn: 'No se pudo abrir la ventana del PJN.' }); return false; }
  await sset('itRevPjn', { t: Date.now(), windowId: win.id, tabId: win.tabs[0].id, cola: lista.slice(1), actual: lista[0], leidos: 0, nuevos: 0 });
  await anotarEstado({ pjn: 'Revisando…' });
  chrome.alarms.create('it-pjn-espera', { delayInMinutes: IT.PJN_ESPERA_MIN });
  return true;
}
// "error": por qué no se pudo leer el expediente actual (queda en el informe)
async function pjnSiguiente(rev, nuevos, leido, error) {
  rev.nuevos += nuevos || 0; if (leido) rev.leidos++;
  if (error && rev.actual) {
    const a = rev.actual;
    await registrar({ fuente: 'PJN', nombre: `${a.cam} ${a.num}/${a.anio}`, causa: { fuente: 'PJN', cam: a.cam, num: a.num, anio: a.anio, caratula: a.nombre }, nuevos: [], error });
  }
  const sig = rev.cola.shift();
  if (!sig) return pjnTerminar(rev, '');
  rev.actual = sig; rev.t = Date.now();
  await sset('itRevPjn', rev);
  chrome.alarms.create('it-pjn-espera', { delayInMinutes: IT.PJN_ESPERA_MIN });
  try { await chrome.tabs.update(rev.tabId, { url: pjnUrl(sig) }); }
  catch (e) { pjnTerminar(rev, 'Se cerró la ventana de la revisión del PJN.'); }
}
async function pjnTerminar(rev, motivo) {
  chrome.alarms.clear('it-pjn-espera');
  await chrome.storage.local.remove('itRevPjn');
  try { await chrome.windows.remove(rev.windowId); } catch (e) {}
  const faltan = motivo ? rev.cola.length + 1 : 0;
  const pjn = (motivo ? motivo + (faltan ? ` Quedaron ${faltan} expediente(s) sin revisar.` : '') : '') ||
    `${rev.leidos} expediente(s) revisados · ${rev.nuevos} movimiento(s) nuevo(s).`;
  await anotarEstado({ pjn, ultimaPjn: Date.now() });
  await cerrarCorrida({ pjn, pjnPend: false });
}

chrome.alarms.onAlarm.addListener(async a => {
  if (a.name === 'it-revisar') revisar(false);
  if (a.name === 'it-pjn-espera') {          // no apareció la grilla a tiempo: se sigue con el próximo
    const rev = await sget('itRevPjn');
    if (rev) pjnSiguiente(rev, 0, false, 'No se pudo abrir: el PJN no respondió a tiempo o el expediente no está en tus Favoritos.');
  }
});
// Si el PJN manda a iniciar sesión, la revisión se corta y se avisa
chrome.webNavigation.onCompleted.addListener(async d => {
  if (d.frameId !== 0) return;
  const rev = await sget('itRevPjn');
  if (rev && d.tabId === rev.tabId) pjnTerminar(rev, 'Iniciá sesión en el PJN para que se revisen tus expedientes.');
  // Descarga: la pestaña del PJN se muestra para que se pueda iniciar sesión; después sigue sola
  const desc = await sget('itPjnDescarga');
  if (desc && d.tabId === desc.tabId) try { await chrome.tabs.update(d.tabId, { active: true }); } catch (e) {}
}, { url: [{ hostPrefix: 'sso.pjn' }] });
chrome.windows.onRemoved.addListener(async id => {
  const rev = await sget('itRevPjn');
  if (rev && rev.windowId === id) {              // se cerró a mano la ventana de la revisión
    chrome.alarms.clear('it-pjn-espera');
    await chrome.storage.local.remove('itRevPjn');
    await cerrarCorrida({ pjn: `Se cerró la ventana de la revisión del PJN. Quedaron ${rev.cola.length + 1} expediente(s) sin revisar.`, pjnPend: false });
  }
});

async function programar() {
  const cfg = await sget('itConfig') || { auto: true, cadaMin: IT.CADA_MIN };
  await chrome.alarms.clear('it-revisar');
  if (cfg.auto !== false) chrome.alarms.create('it-revisar', { delayInMinutes: 5, periodInMinutes: cfg.cadaMin || IT.CADA_MIN });
}
chrome.runtime.onInstalled.addListener(programar);
chrome.runtime.onStartup.addListener(programar);

// ── Descargas de expedientes completos ───────────────────────────────────
// IusTrack manda una lista de expedientes elegidos; quedan en una cola (itDescCola) y
// descarga.html —una sola pestaña— los baja de a uno. Para el PJN, descarga.html pide
// abrir el expediente en una pestaña aparte: pjn-capturar.js recorre todas las páginas,
// pide los documentos firmados y se los manda. El PDF listo queda en itArchivos hasta
// que IusTrack lo adjunta al expediente.
const DESC_PAGINA = 'descarga.html';
async function descargaAsegurarPestana() {
  const id = await sget('itDescTab');
  if (id) try { await chrome.tabs.get(id); return; } catch (e) {}
  const tab = await chrome.tabs.create({ url: chrome.runtime.getURL(DESC_PAGINA), active: true });
  await sset('itDescTab', tab.id);
}
async function descargaAbrirPjn(id) {
  const cola = await sget('itDescCola') || [], j = cola.find(x => x.id === id); if (!j) return;
  const t = j.trabajo;
  const tab = await chrome.tabs.create({ url: `${PJN_FAVORITOS}#lextrack=${t.cam}-${t.num}-${t.anio}`, active: false });
  await sset('itPjnDescarga', { id, cam: t.cam, num: String(+t.num), anio: t.anio, docs: !!j.docs, tabId: tab.id, t: Date.now() });
}
async function descargaPjnTerminar(tabId) {
  await chrome.storage.local.remove('itPjnDescarga');
  if (tabId) try { await chrome.tabs.remove(tabId); } catch (e) {}
}

// ── Mensajes de las páginas ──────────────────────────────────────────────
const MENSAJES = new Set(['mev-pagina', 'pjn-pagina', 'pjn-no-encontrado', 'bandeja', 'confirmar', 'seguimiento', 'estado', 'config', 'revisar',
  'descargar', 'desc-estado', 'desc-quitar', 'desc-actualizar', 'pjn-descarga-abrir', 'pjn-otro', 'pjn-listo', 'pjn-fallo', 'archivo-listo', 'archivos', 'archivos-confirmar']);
chrome.runtime.onMessage.addListener((m, sender, responder) => {
  if (!m || !MENSAJES.has(m.it)) return;   // los demás son para descarga.html (avance y documentos del PJN)
  (async () => {
    switch (m.it) {
      case 'mev-pagina': {                 // nivel 1: se abrió un expediente de la MEV
        const { causa, movs } = mevLeerGrilla(m.html, m.url);
        if (!causa.nidCausa || !movs.length) return responder({ nuevos: 0 });
        const r = await procesarCaptura(causa, movs, 'pagina');
        return responder(Object.assign(r, { app: await appAbierta() }));
      }
      case 'pjn-pagina': {                 // la grilla de un expediente del PJN
        const causa = Object.assign({ fuente: 'PJN' }, m.causa);
        // "k": el texto tal como lo muestra el PJN (con rótulos), para que la clave no cambie
        const movs = m.movs.map(x => ({ clave: `PJN:${x.fecha}|${huella(x.k ? x.k.split('|').map(plano).join('|') : plano(x.tipo) + '|' + plano(x.detalle))}`,
          fecha: x.fecha, tipo: x.tipo, texto: x.detalle }));
        const rev = await sget('itRevPjn');
        const enRevision = !!(rev && sender.tab && sender.tab.id === rev.tabId);
        // ¿Se abrió el expediente que se pidió? (si no, se avisa y en la revisión queda en el informe)
        const pedido = await sget('itPjnPedido');
        await chrome.storage.local.remove('itPjnPedido');
        const igual = x => x && x.cam === causa.cam && String(+x.num) === String(+causa.num) && x.anio === causa.anio;
        const esperado = enRevision ? rev.actual : (pedido && Date.now() - pedido.t < 3 * 60 * 1000 ? pedido : null);
        if (esperado && !igual(esperado)) {
          const otro = `${esperado.cam} ${esperado.num}/${esperado.anio}`;
          responder({ nuevos: 0, otro, abierto: `${causa.cam} ${causa.num}/${causa.anio}`, silencio: enRevision });
          if (enRevision) pjnSiguiente(rev, 0, false, `Se abrió otro expediente (${causa.cam} ${causa.num}/${causa.anio}) en lugar de este: no se cargó nada.`);
          return;
        }
        const r = await procesarCaptura(causa, movs, enRevision ? 'revision' : 'pagina');
        responder(Object.assign(r, { app: await appAbierta(), silencio: enRevision }));
        if (enRevision) pjnSiguiente(rev, r.nuevos, true);
        return;
      }
      case 'descargar': {                  // IusTrack: expedientes elegidos para descargar
        await enCola(async () => {
          const cola = (await sget('itDescCola') || []).filter(x => Date.now() - x.t < 7 * 864e5).slice(-40);
          for (const t of m.trabajos || []) {
            if (cola.some(x => x.trabajo.expId === t.expId && /cola|descargando/.test(x.estado))) continue;   // ya está pedido
            cola.push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), trabajo: t, docs: !!m.docs,
                        estado: 'cola', avance: 0, msg: 'En espera', t: Date.now() });
          }
          await sset('itDescCola', cola);
        });
        await descargaAsegurarPestana();
        return responder({ ok: true });
      }
      case 'desc-actualizar': {            // descarga.html: avance o resultado de una descarga
        await enCola(async () => {
          const cola = await sget('itDescCola') || [], j = cola.find(x => x.id === m.id);
          if (j) { Object.assign(j, m.cambios); await sset('itDescCola', cola); }
        });
        return responder({ ok: true });
      }
      case 'desc-estado':                  // IusTrack: cómo va cada descarga
        return responder(await sget('itDescCola') || []);
      case 'desc-quitar': {                // IusTrack: sacar de la lista (las terminadas o las que esperan)
        await enCola(async () => sset('itDescCola', (await sget('itDescCola') || []).filter(x => !(m.ids || []).includes(x.id) || x.estado === 'descargando')));
        return responder({ ok: true });
      }
      case 'pjn-descarga-abrir': {         // descarga.html: abrir el expediente del PJN
        await descargaAbrirPjn(m.id);
        return responder({ ok: true });
      }
      case 'pjn-otro': {                   // en la pestaña de la descarga se abrió otro expediente
        const d = await sget('itPjnDescarga');
        if (d && d.id === m.id && sender.tab && sender.tab.id === d.tabId) {
          chrome.runtime.sendMessage({ it: 'pjn-fallo', id: m.id, motivo: m.motivo }).catch(() => {});
          await descargaPjnTerminar(d.tabId);
        }
        return responder({});
      }
      case 'pjn-listo': case 'pjn-fallo': { // pjn-capturar.js terminó (el aviso le llega también a descarga.html)
        const d = await sget('itPjnDescarga');
        if (d && d.id === m.id) await descargaPjnTerminar(d.tabId);
        return responder({ ok: true });
      }
      case 'archivo-listo': {              // descarga.html: PDF listo para adjuntar en IusTrack
        await enCola(async () => {
          const lista = (await sget('itArchivos') || []).filter(x => x.id !== m.archivo.id);
          lista.push(Object.assign({ t: Date.now() }, m.archivo));
          await sset('itArchivos', lista.slice(-10));
        });
        return responder({ ok: true });
      }
      case 'archivos': return responder(await sget('itArchivos') || []);
      case 'archivos-confirmar': {
        await enCola(async () => sset('itArchivos', (await sget('itArchivos') || []).filter(x => !m.ids.includes(x.id))));
        return responder({ ok: true });
      }
      case 'pjn-no-encontrado': {          // contenido.js no lo encontró en Favoritos
        const desc = await sget('itPjnDescarga');
        if (desc && sender.tab && sender.tab.id === desc.tabId) {
          chrome.runtime.sendMessage({ it: 'pjn-fallo', id: desc.id, motivo: 'El expediente no está en tus Favoritos del PJN o el número cargado en IusTrack no coincide. Agregalo con la estrella ⭐ y volvé a pedirlo.' }).catch(() => {});
          await descargaPjnTerminar(desc.tabId);
          return responder({});
        }
        const rev = await sget('itRevPjn');
        if (rev && sender.tab && sender.tab.id === rev.tabId)
          pjnSiguiente(rev, 0, false, 'No está en tus Favoritos del PJN o el número cargado en IusTrack no coincide.');
        return responder({});
      }
      case 'bandeja': {                    // puente.js: lo que IusTrack tiene que cargar
        await sset('itAppVista', Date.now());
        return responder(await sget('itBandeja') || []);
      }
      case 'confirmar': {                  // IusTrack ya lo procesó
        await enCola(async () => sset('itBandeja', (await sget('itBandeja') || []).filter(x => !m.ids.includes(x.id))));
        return responder({ ok: true });
      }
      case 'seguimiento': {                // la lista de expedientes a revisar, desde IusTrack
        await sset('itSeguimiento', { t: Date.now(), lista: m.lista || [] });
        await sset('itAppVista', Date.now());
        return responder({ ok: true });
      }
      case 'estado': {
        const [estado, cfg, seg, bandeja, rev, corrida, informes] = await Promise.all(
          ['itEstado', 'itConfig', 'itSeguimiento', 'itBandeja', 'itRevPjn', 'itCorrida', 'itInformes'].map(sget));
        return responder({ estado: estado || {}, cfg: cfg || { auto: true, cadaMin: IT.CADA_MIN }, seg: seg || null,
          pendientes: (bandeja || []).reduce((n, x) => n + x.movs.length, 0), revisando: revisando || !!rev,
          corrida: corrida || null, informes: m.informes ? (informes || []) : undefined,
          ultimoInforme: informes && informes[0] ? informes[0].id : '' });
      }
      case 'config': {
        await sset('itConfig', m.cfg); await programar();
        return responder({ ok: true });
      }
      case 'revisar': {
        revisar(true);
        return responder({ ok: true });
      }
    }
  })().catch(e => { console.warn('IusTrack', e); try { responder({ error: String(e) }); } catch (_) {} });
  return true;
});
