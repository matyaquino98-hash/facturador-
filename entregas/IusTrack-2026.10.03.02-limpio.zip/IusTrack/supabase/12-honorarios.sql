-- ════════════════════════════════════════════════════════════════════════
-- IusTrack — 12: Honorarios
-- Se puede correr más de una vez sin problema.
--
-- · Tabla honorarios: lo pactado con cada cliente o regulado en cada expediente,
--   en una o varias cuotas, con los pagos que se van registrando.
--     monto           total pactado / regulado
--     cuotas          cantidad de cuotas (1 = pago único)
--     vencimiento     vencimiento de la primera cuota (las demás, mes a mes)
--     pagos           [{ "fecha": "2026-10-02", "monto": 150000, "nota": "transferencia" }, …]
--   El estado (por cobrar / vencido / cobrado) se calcula en IusTrack con los pagos.
-- · Permisos: todo el estudio ve los honorarios; admin y abogados cargan, editan y
--   borran (con la licencia vigente). Cada estudio sólo ve lo suyo.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.honorarios (
  id              text primary key default gen_random_uuid()::text,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  expediente_id   text references public.expedientes(id) on delete set null,
  cliente         text not null default '',               -- quién paga
  concepto        text not null default '',               -- pacto de cuota litis, regulación, consulta…
  tipo            text not null default 'pactado' check (tipo in ('pactado','regulado','consulta','otro')),
  moneda          text not null default 'ARS' check (moneda in ('ARS','USD','JUS')),
  monto           numeric(16,2) not null default 0 check (monto >= 0),
  cuotas          integer not null default 1 check (cuotas between 1 and 120),
  fecha_pacto     date,
  vencimiento     date,
  responsable     text not null default '',
  factura         text not null default '',
  notas           text not null default '',
  pagos           jsonb not null default '[]'::jsonb,
  creado_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  creado_en       timestamptz not null default now(),
  actualizado_por uuid default auth.uid() references public.perfiles(id) on delete set null,
  actualizado_en  timestamptz not null default now()
);
create index if not exists ix_honorarios_estudio on public.honorarios(estudio_id);
create index if not exists ix_honorarios_expediente on public.honorarios(expediente_id);

-- Un honorario no se puede pasar a otro estudio; el expediente tiene que ser del mismo estudio
create or replace function public.tg_honorario_actualizado() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' and new.estudio_id <> old.estudio_id then
    raise exception 'No se puede mover un honorario a otro estudio';
  end if;
  if new.expediente_id is not null and not exists (
       select 1 from expedientes e where e.id = new.expediente_id and e.estudio_id = new.estudio_id) then
    raise exception 'El expediente no es de este estudio';
  end if;
  if jsonb_typeof(new.pagos) <> 'array' then new.pagos := '[]'::jsonb; end if;
  new.actualizado_en := now();
  new.actualizado_por := coalesce(auth.uid(), new.actualizado_por);
  return new;
end $$;
drop trigger if exists tg_honorario_upd on public.honorarios;
create trigger tg_honorario_upd before insert or update on public.honorarios
  for each row execute function public.tg_honorario_actualizado();

alter table public.honorarios enable row level security;
do $$ declare r record; begin
  for r in select policyname from pg_policies where schemaname = 'public' and tablename = 'honorarios' loop
    execute format('drop policy %I on public.honorarios', r.policyname);
  end loop;
end $$;
create policy hon_ver    on public.honorarios for select using (public.es_miembro(estudio_id));
create policy hon_crear  on public.honorarios for insert with check (public.puede_cargar(estudio_id));
create policy hon_mod    on public.honorarios for update using (public.puede_cargar(estudio_id)) with check (public.puede_cargar(estudio_id));
create policy hon_borrar on public.honorarios for delete using (public.puede_cargar(estudio_id));

revoke all on public.honorarios from anon;

notify pgrst, 'reload schema';
