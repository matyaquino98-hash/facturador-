/* IusTrack — lectura de la MEV y utilidades de texto, compartidas por la procuración
   (seguimiento.js, en el proceso de fondo) y las descargas (descarga.js). */

const MEV = 'https://mev.scba.gov.ar/';
const dormir = ms => new Promise(r => setTimeout(r, ms));

// ── Utilidades de texto ──────────────────────────────────────────────────
const ENT = { nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", ordm: 'º', ordf: 'ª', deg: '°',
  aacute: 'á', eacute: 'é', iacute: 'í', oacute: 'ó', uacute: 'ú', Aacute: 'Á', Eacute: 'É', Iacute: 'Í',
  Oacute: 'Ó', Uacute: 'Ú', ntilde: 'ñ', Ntilde: 'Ñ', uuml: 'ü', Uuml: 'Ü', laquo: '«', raquo: '»' };
function entidades(s) {
  return String(s || '').replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') { const n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10); return n ? String.fromCodePoint(n) : m; }
    return ENT[e] !== undefined ? ENT[e] : m;
  });
}
function htmlATexto(html) {
  return entidades(String(html || '')
    .replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<br\s*\/?>|<\/(p|div|tr|li|h\d|table)>/gi, '\n')
    .replace(/<[^>]+>/g, ' '))
    .split('\n').map(l => l.replace(/[ \t ]+/g, ' ').trim()).filter(Boolean).join('\n');
}
const plano = s => String(s || '').replace(/\s+/g, ' ').trim();
function isoDe(dmy) {
  const m = String(dmy || '').match(/(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
  if (!m) return '';
  const a = m[3].length === 2 ? '20' + m[3] : m[3];
  return `${a}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
}
function hoyMenos(dias) { return new Date(Date.now() - dias * 864e5).toISOString().slice(0, 10); }
function huella(s) {   // FNV-1a: la misma actuación da siempre la misma clave
  let h = 0x811c9dc5;
  for (const c of String(s)) { h ^= c.codePointAt(0); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(36);
}

// La MEV sirve las páginas en Latin-1 y a veces no lo declara
async function traerTexto(url) {
  const r = await fetch(url, { credentials: 'include', cache: 'no-store' });
  const bytes = new Uint8Array(await r.arrayBuffer());
  let cs = ((r.headers.get('content-type') || '').match(/charset\s*=\s*["']?([\w-]+)/i) || [])[1];
  if (!cs) cs = (new TextDecoder('iso-8859-1').decode(bytes.subarray(0, 4096)).match(/charset\s*=\s*["']?\s*([\w-]+)/i) || [, 'iso-8859-1'])[1];
  cs = cs.toLowerCase() === 'utf8' ? 'utf-8' : cs.toLowerCase();
  let txt;
  try { txt = new TextDecoder(cs).decode(bytes); } catch (e) { txt = new TextDecoder('iso-8859-1').decode(bytes); }
  if (cs === 'utf-8' && (txt.match(/�/g) || []).length > 2) txt = new TextDecoder('windows-1252').decode(bytes);
  return { html: txt, url: r.url };
}

// ── MEV ──────────────────────────────────────────────────────────────────
// Pantalla de ingreso: la portada siempre tiene el formulario, así que se exige
// que además falten las marcas de una sesión iniciada.
function mevPideIngreso(html, url) {
  if (/logu?in\.asp/i.test(url || '')) return true;
  if (!/type\s*=\s*["']?password/i.test(html)) return false;
  return !/cerrar\s+sesi[oó]n|desconectar|logout|salir\b|mis\s+causas|pasos\s+procesales|proveido\.asp/i.test(html);
}
// Cuando se le pide rápido, la MEV contesta una página chiquita y vacía
const mevCorto = html => html.length < 6000 && !/proveido\.asp/i.test(html) && !/<table/i.test(html);

function mevLeerGrilla(html, url) {
  const u = new URL(url, MEV);
  const param = n => u.searchParams.get(n) || u.searchParams.get(n.toLowerCase()) || '';
  const causa = { fuente: 'MEV', nidCausa: param('nidCausa'), pidJuzgado: param('pidJuzgado'), url: u.href };
  const texto = htmlATexto(html);
  causa.numero = (texto.match(/\b([A-Z]{1,4}\s*-\s*\d{1,7}\s*-\s*\d{4})\b/) || [])[1] || '';
  causa.caratula = (texto.split('\n').find(l => /\b[CS]\s?\/\s?/i.test(l) && l.length > 10 && l.length < 300) || '').replace(/^car[aá]tula\s*:?\s*/i, '').trim();

  const bajo = html.toLowerCase(), movs = [], vistos = new Set();
  const re = /<a\b[^>]*href\s*=\s*["']?([^"'\s>]*proveido\.asp[^"'\s>]*)["']?[^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html))) {
    const href = entidades(m[1]);
    const posi = (href.match(/nPosi=(\d+)/i) || [])[1];
    if (!posi || vistos.has(posi)) continue;
    vistos.add(posi);
    const ini = bajo.lastIndexOf('<tr', m.index), fin = bajo.indexOf('</tr', m.index);
    const fila = htmlATexto(html.slice(ini < 0 ? m.index : ini, fin < 0 ? m.index + m[0].length : fin));
    let tipo = plano(htmlATexto(m[2]));
    if (tipo.length < 3) tipo = fila.split('\n').find(l => l.length > 3 && l.length < 150 && !/^\d{1,2}\//.test(l)) || 'MOVIMIENTO';
    movs.push({ clave: 'MEV:' + posi, fecha: isoDe(fila), tipo, url: new URL(href, MEV).href });
  }
  return { causa, movs };
}

// El texto del despacho va después de "Texto del Proveído" o de la línea
// "Para copiar y pegar el texto seleccione desde aquí".
function mevTextoProveido(html, max = 4000) {   // max = 0: texto completo
  const limpio = String(html || '').replace(/&nbsp;/gi, ' ');
  const m = /(-{2,}\s*Para copiar y pegar el texto[^-]{0,90}-{2,})|(Texto\s+del\s+Prove(?:[ií]|&iacute;|&#237;)do)/i.exec(limpio);
  if (!m) return '';
  let resto = limpio.slice(m.index + m[0].length);
  const corte = /-{2,}\s*Para copiar y pegar el texto[^-]{0,90}-{2,}/i.exec(resto);
  if (corte && corte.index < 600) resto = resto.slice(corte.index + corte[0].length);
  const t = htmlATexto(resto).split('\n').filter(l => !/^-{2,}/.test(l) && !/^(volver|imprimir|cerrar)$/i.test(l)).join('\n');
  return max && t.length > max ? t.slice(0, max) + '…' : t;
}

// Documentos adjuntos de un proveído (contestaciones de oficio, cédulas, escritos).
// Mismo criterio que el Asistente MEV/PJN: la MEV los sirve desde
// docs.scba.gov.ar/documentos?nombre=<uuid>, y a veces solo deja el identificador
// suelto en el HTML (el link lo arma su JavaScript): se reconstruye.
const ADJ_INCLUYE = /(\.pdf(\?|#|$))|(docs\.scba\.gov\.ar\/documentos)|(nombre=[^&"'\s]+&\s*hash=)/i;
const ADJ_EXCLUYE = /(proveido\.asp|procesales\.asp|loguin|logout|javascript:|mailto:|\.(jpe?g|png|gif|svg|ico)(\?|#|$)|logo|icono|boton|banner)/i;
function mevAdjuntos(html) {
  const vistos = new Set(), out = [];
  const add = u => {
    if (!u) return;
    u = entidades(u).replace(/\\/g, '/').trim();
    let abs; try { abs = new URL(u, MEV).href; } catch (e) { return; }
    if (ADJ_EXCLUYE.test(abs) && !/docs\.scba\.gov\.ar/i.test(abs)) return;
    if (!vistos.has(abs)) { vistos.add(abs); out.push(abs); }
  };
  let m;
  const reDocs = /(https?:\/\/docs\.scba\.gov\.ar\/documentos\?[^\s"'<>]+)/gi;
  while ((m = reDocs.exec(html))) add(m[1]);
  const reAttr = /(?:href|src|data|original-url)\s*=\s*["']([^"']+)["']/gi;
  while ((m = reAttr.exec(html))) if (ADJ_INCLUYE.test(m[1])) add(m[1]);
  const reOpen = /window\.open\(\s*["']([^"']+)["']/gi;
  while ((m = reOpen.exec(html))) if (ADJ_INCLUYE.test(m[1])) add(m[1]);
  // Identificador suelto (sólo si ese documento no apareció ya con su link completo)
  const uuids = new Set(), reUuid = /\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/gi;
  while ((m = reUuid.exec(html)) && uuids.size < 12) {
    const id = m[0].toLowerCase();
    if (uuids.has(id)) continue;
    uuids.add(id);
    if (![...vistos].some(v => v.toLowerCase().includes(id))) add('https://docs.scba.gov.ar/documentos?nombre=' + id);
  }
  return out;
}

// Pide un archivo y lo devuelve sólo si es un PDF de verdad (no una página de error)
async function traerPdf(url) {
  try {
    const r = await fetch(url, { credentials: 'include', cache: 'no-store' });
    if (!r.ok) return null;
    const b = new Uint8Array(await r.arrayBuffer());
    return b.length > 400 && b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46 ? b : null;   // %PDF
  } catch (e) { return null; }
}

