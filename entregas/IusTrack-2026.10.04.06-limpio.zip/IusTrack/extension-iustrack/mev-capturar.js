/* IusTrack — al abrir un expediente de la MEV, se leen sus movimientos y los nuevos
   quedan listos para que IusTrack los cargue. */
(() => {
  if (!/procesales\.asp/i.test(location.pathname) || !/proveido\.asp/i.test(document.body.innerHTML)) return;

  function aviso(txt) {
    const d = document.createElement('div');
    d.style.cssText = 'position:fixed;top:14px;right:14px;z-index:2147483647;max-width:380px;padding:12px 16px;border-radius:10px;' +
      'font:14px/1.4 Arial,sans-serif;background:#eaf7ee;color:#1d5e33;border:1px solid #b5dfc3;box-shadow:0 6px 24px rgba(0,0,0,.25);cursor:pointer';
    d.textContent = 'IusTrack: ' + txt;
    d.title = 'Clic para cerrar';
    d.onclick = () => d.remove();
    document.body.appendChild(d);
    setTimeout(() => d.remove(), 9000);
  }

  chrome.runtime.sendMessage({ it: 'mev-pagina', url: location.href, html: document.documentElement.outerHTML }, r => {
    if (chrome.runtime.lastError || !r || !r.nuevos) return;
    const n = r.nuevos === 1 ? 'un movimiento nuevo' : r.nuevos + ' movimientos nuevos';
    aviso((r.primera ? `primera lectura de este expediente: ${n} de los últimos 15 días` : n) +
      (r.app ? '. Ya se están cargando en IusTrack.' : '. Se cargan en cuanto abras IusTrack.'));
  });
})();
