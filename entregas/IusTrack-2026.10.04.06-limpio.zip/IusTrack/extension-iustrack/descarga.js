/* IusTrack — gestor de descargas de expedientes completos (MEV y PJN).
   IusTrack manda los expedientes elegidos; el fondo los pone en una cola (itDescCola) y
   esta pestaña los baja de a uno:
   · MEV: lista de movimientos, texto completo de cada proveído y —si se pidió— los PDF
     adjuntos (contestaciones de oficio, cédulas). La MEV corta si se le pide rápido: se
     espera y se sigue. Lo leído queda guardado: un reintento no vuelve a empezar.
   · PJN: se abre el expediente desde tus Favoritos en otra pestaña; pjn-capturar.js
     recorre todas las páginas y —si se pidió— baja los documentos firmados.
   El PDF (sin marca de agua) lleva portada, todos los movimientos en orden y los
   documentos de cada uno a continuación. Se guarda en Descargas\IusTrack y se le pasa a
   IusTrack para que lo adjunte al expediente. */

const PAUSA = 2500, ESPERAS = [90e3, 150e3, 240e3, 300e3, 300e3];
const LIMITE_NUBE = 45 * 1024 * 1024;     // lo que se adjunta en IusTrack (el máximo de la nube es 50 MB)
const urls = {};                          // PDF ya armados en esta sesión (para "Abrir")
let trabajando = false;

const fechaLarga = iso => iso ? iso.split('-').reverse().join('/') : 's/f';
const esc = s => String(s || '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const actualizar = (id, cambios) => chrome.runtime.sendMessage({ it: 'desc-actualizar', id, cambios }).catch(() => {});

// ── Lista en pantalla ────────────────────────────────────────────────────
async function pintar() {
  const cola = (await chrome.storage.local.get('itDescCola')).itDescCola || [];
  const caja = document.getElementById('lista');
  if (!cola.length) { caja.innerHTML = '<div class="vacio">No hay descargas pedidas. Elegí los expedientes en IusTrack → ⬇ Descargas.</div>'; return; }
  const ET = { cola: 'En espera', descargando: 'Descargando', listo: 'Listo ✓', error: 'No se pudo' };
  caja.innerHTML = cola.slice().reverse().map(j => {
    const t = j.trabajo;
    return `<div class="item${j.estado === 'descargando' ? ' activo' : ''}">
      <div class="cab"><b>${esc(t.nombre || 'Expediente')}</b><span class="chip ${j.estado}">${ET[j.estado] || j.estado}</span></div>
      <div class="meta">${esc(t.f)} · ${esc(t.numero || (t.cam ? `${t.cam} ${t.num}/${t.anio}` : ''))}${j.docs ? ' · con documentos' : ' · sin documentos'}</div>
      ${j.estado === 'descargando' ? `<div class="barra"><div style="width:${Math.max(2, j.avance || 0)}%"></div></div>` : ''}
      <div class="msg${j.estado === 'error' ? ' err' : ''}">${esc(j.msg || '')}</div>
      ${j.estado === 'listo' && urls[j.id] ? `<div class="acc"><a class="boton prim" href="${urls[j.id]}" target="_blank">📄 Abrir el PDF</a></div>` : ''}
      ${j.estado === 'error' ? `<div class="acc"><button data-reintentar="${j.id}">↻ Reintentar</button></div>` : ''}
    </div>`;
  }).join('');
  caja.querySelectorAll('[data-reintentar]').forEach(b => b.onclick = async () => {
    await actualizar(b.dataset.reintentar, { estado: 'cola', avance: 0, msg: 'En espera' });
    procesar();
  });
}
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local' || !c.itDescCola) return;
  pintar();
  procesar();
});

// ── MEV ──────────────────────────────────────────────────────────────────
async function descargarMev(j, paso) {
  const t = j.trabajo;
  const url = /procesales\.asp/i.test(t.url || '') ? t.url
    : `${MEV}procesales.asp?nidCausa=${encodeURIComponent(t.nidCausa)}&pidJuzgado=${encodeURIComponent(t.pidJuzgado || '')}`;
  paso(2, 'Leyendo la lista de movimientos en la MEV…');
  const r = await traerTexto(url);
  if (mevPideIngreso(r.html, r.url)) throw new Error('Se venció la sesión de la MEV: iniciá sesión en la MEV y tocá Reintentar.');
  if (mevCorto(r.html)) throw new Error('La MEV pidió una pausa. Esperá unos minutos y tocá Reintentar.');
  const { causa, movs } = mevLeerGrilla(r.html, url);
  if (!movs.length) throw new Error('La MEV no mostró movimientos para este expediente.');

  const texto = htmlATexto(r.html);
  const dato = re => ((texto.match(re) || [])[1] || '').trim();
  const datos = { caratula: t.nombre || causa.caratula, numero: t.numero || causa.numero,
    juzgado: dato(/(?:Juzgado|Organismo)\s*:?\s*([^\n]{3,120})/i) || t.juzgado || '', estado: dato(/Estado\s*:?\s*([^\n]{2,60})/i),
    fuente: 'MEV — Suprema Corte de Justicia de la Provincia de Buenos Aires' };

  // Texto (y links de adjuntos) de cada proveído, con caché: lo leído no se vuelve a pedir
  const claveCache = 'itProv2:' + causa.nidCausa;
  const cache = (await chrome.storage.local.get(claveCache))[claveCache] || {};
  let nuevos = 0, esperas = 0;
  for (let i = 0; i < movs.length; i++) {
    const mv = movs[i];
    paso(5 + 60 * i / movs.length, `Proveídos: ${i + 1} de ${movs.length} — ${fechaLarga(mv.fecha)} ${mv.tipo}`);
    if (cache[mv.clave]) { mv.texto = cache[mv.clave].texto; mv.adj = cache[mv.clave].adj || []; continue; }
    await dormir(PAUSA);
    let html;
    try { html = (await traerTexto(mv.url)).html; } catch (e) { mv.texto = ''; continue; }
    if (mevCorto(html)) {
      if (esperas >= ESPERAS.length) throw new Error(`La MEV siguió pidiendo pausa (se leyeron ${i} de ${movs.length}). Tocá Reintentar más tarde: sigue desde donde quedó.`);
      const fin = Date.now() + ESPERAS[esperas++];
      while (Date.now() < fin) { paso(5 + 60 * i / movs.length, `La MEV pidió una pausa: se sigue sola en ${Math.ceil((fin - Date.now()) / 1000)} s…`); await dormir(1000); }
      i--; continue;
    }
    mv.texto = mevTextoProveido(html, 0);
    mv.adj = mevAdjuntos(html);
    cache[mv.clave] = { texto: mv.texto, adj: mv.adj };
    if (++nuevos % 5 === 0) await chrome.storage.local.set({ [claveCache]: cache });
  }
  await chrome.storage.local.set({ [claveCache]: cache });

  // Adjuntos (PDF)
  if (j.docs) {
    const conAdj = movs.filter(m => m.adj && m.adj.length);
    let n = 0, total = conAdj.reduce((s, m) => s + m.adj.length, 0);
    for (const m of conAdj) {
      m.pdfs = [];
      for (const u of m.adj) {
        paso(65 + 25 * n / Math.max(1, total), `Documentos adjuntos: ${++n} de ${total}`);
        const b = await traerPdf(u);
        if (b) m.pdfs.push(b);
        await dormir(800);
      }
    }
  }
  return { datos, movs: movs.map(m => ({ fecha: m.fecha, tipo: m.tipo, texto: m.texto || '', pdfs: m.pdfs || [] })) };
}

// ── PJN ──────────────────────────────────────────────────────────────────
function descargarPjn(j, paso) {
  const t = j.trabajo;
  paso(3, 'Abriendo el expediente en el PJN desde tus Favoritos (en otra pestaña; se cierra sola)…');
  return new Promise((ok, mal) => {
    const docs = {};
    let limite;
    const reloj = () => { clearTimeout(limite); limite = setTimeout(() => { fin(); mal(new Error('El PJN dejó de responder. Revisá que tengas la sesión iniciada y que el expediente esté en tus Favoritos, y tocá Reintentar.')); }, 4 * 60 * 1000); };
    const fin = () => { clearTimeout(limite); chrome.runtime.onMessage.removeListener(oir); };
    function oir(m, sender, responder) {
      if (!m || m.id !== j.id) return;
      reloj();
      if (m.it === 'pjn-progreso') {
        if (m.fase === 'actuaciones') paso(Math.min(40, 8 + m.pagina * 3), `Actuaciones: página ${m.pagina} (${m.leidas} leídas)`);
        else paso(40 + 50 * m.actual / m.total, `Documentos firmados: ${m.actual} de ${m.total}`);
      }
      if (m.it === 'pjn-doc') {
        const bin = atob(m.b64), b = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
        (docs[m.i] = docs[m.i] || []).push(b);
        responder({ ok: true });
      }
      if (m.it === 'pjn-fallo') { fin(); mal(new Error(m.motivo)); }
      if (m.it === 'pjn-listo') {
        fin();
        const d = m.datos || {};
        ok({ datos: { caratula: d.caratula || t.nombre, numero: `${t.cam} ${t.num}/${t.anio}`, juzgado: d.dependencia || t.juzgado || '',
                      estado: d.situacion || '', fuente: 'PJN — Poder Judicial de la Nación' + (d.jurisdiccion ? ' · ' + d.jurisdiccion : '') },
             movs: m.movs.map((x, i) => ({ fecha: x.fecha, tipo: x.tipo, texto: x.detalle, oficina: x.oficina, fojas: x.fojas, pdfs: docs[i] || [] })) });
      }
    }
    chrome.runtime.onMessage.addListener(oir);
    reloj();
    chrome.runtime.sendMessage({ it: 'pjn-descarga-abrir', id: j.id });
  });
}

// ── PDF ──────────────────────────────────────────────────────────────────
// La fuente estándar del PDF sólo tiene el alfabeto latino: se reemplazan comillas
// tipográficas, guiones largos y otros signos que saldrían como basura.
const latin = s => String(s || '').replace(/[“”«»]/g, '"').replace(/[‘’´`]/g, "'").replace(/[–—−]/g, '-').replace(/…/g, '...')
  .replace(/[•·]/g, '-').replace(/ /g, ' ').replace(/[^\x09\x0a\x0d\x20-\x7e\xa1-\xff]/g, '');

// Devuelve el PDF de índice y textos (jsPDF) y dónde van los documentos de cada movimiento
function armarIndice(r) {
  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF({ unit: 'pt', format: 'a4' });
  const W = pdf.internal.pageSize.getWidth(), H = pdf.internal.pageSize.getHeight(), M = 48, ANCHO = W - 2 * M;
  let y = M;
  const salto = alto => { if (y + alto > H - 50) { pdf.addPage(); y = M; } };
  const parrafo = (txt, tam, estilo, color, interlinea) => {
    pdf.setFont('helvetica', estilo || 'normal'); pdf.setFontSize(tam); pdf.setTextColor(...(color || [42, 29, 20]));
    const lh = tam * (interlinea || 1.35);
    for (const linea of pdf.splitTextToSize(latin(txt), ANCHO)) { salto(lh); pdf.text(linea, M, y + tam); y += lh; }
  };
  const lista = r.movs.slice().sort((a, b) => (a.fecha || '').localeCompare(b.fecha || ''));
  const totalDocs = lista.reduce((s, m) => s + (m.pdfs ? m.pdfs.length : 0), 0);

  // Portada
  parrafo('EXPEDIENTE COMPLETO', 10, 'bold', [191, 78, 28]);
  y += 6;
  parrafo(r.datos.caratula || '(sin carátula)', 17, 'bold');
  y += 10;
  const fila = (k, v) => { if (!v) return; pdf.setFont('helvetica', 'bold'); pdf.setFontSize(10); pdf.setTextColor(139, 116, 96); salto(16);
    pdf.text(latin(k), M, y + 10); const ls = pdf.splitTextToSize(latin(v), ANCHO - 110); pdf.setFont('helvetica', 'normal'); pdf.setTextColor(42, 29, 20);
    ls.forEach((l, i) => { if (i) { y += 14; salto(14); } pdf.text(l, M + 110, y + 10); }); y += 18; };
  fila('Expediente', r.datos.numero);
  fila('Juzgado', r.datos.juzgado);
  fila('Situación', r.datos.estado);
  fila('Fuente', r.datos.fuente);
  fila('Movimientos', String(lista.length));
  if (totalDocs) fila('Documentos', `${totalDocs} (a continuación de cada movimiento)`);
  fila('Descargado', new Date().toLocaleString('es-AR', { dateStyle: 'short', timeStyle: 'short' }) + ' con IusTrack');
  y += 14; pdf.setDrawColor(236, 220, 201); pdf.line(M, y, W - M, y); y += 16;

  // Movimientos, del más antiguo al más reciente
  const inserciones = [];
  lista.forEach((m, i) => {
    salto(46);
    pdf.setFont('helvetica', 'bold'); pdf.setFontSize(10.5); pdf.setTextColor(191, 78, 28);
    pdf.text(latin(`${i + 1}. ${fechaLarga(m.fecha)}`), M, y + 11);
    pdf.setTextColor(42, 29, 20);
    pdf.splitTextToSize(latin(m.tipo || 'Actuación'), ANCHO - 95).forEach((l, k) => { if (k) { y += 14; salto(14); } pdf.text(l, M + 95, y + 11); });
    y += 17;
    const meta = [m.oficina && 'Oficina: ' + m.oficina, m.fojas && 'Fs.: ' + m.fojas].filter(Boolean).join(' - ');
    if (meta) parrafo(meta, 8.5, 'normal', [139, 116, 96]);
    if (m.texto && m.texto !== m.tipo) parrafo(m.texto, 9.5, 'normal', [55, 45, 38], 1.4);
    if (m.pdfs && m.pdfs.length) {
      parrafo(`[${m.pdfs.length === 1 ? 'Documento adjunto' : m.pdfs.length + ' documentos adjuntos'}: en el PDF completo, a continuación]`, 9, 'italic', [31, 107, 58]);
      inserciones.push({ despuesDe: pdf.getNumberOfPages(), pdfs: m.pdfs });
      if (i < lista.length - 1) { pdf.addPage(); y = M; }   // el movimiento siguiente arranca después de los documentos
    } else y += 10;
  });
  // Pie (sin número de página: se numera al final, cuando ya están los documentos)
  const n = pdf.getNumberOfPages();
  for (let p = 1; p <= n; p++) {
    pdf.setPage(p); pdf.setFont('helvetica', 'normal'); pdf.setFontSize(8); pdf.setTextColor(150, 135, 120);
    pdf.text(latin(`${r.datos.numero || ''}  -  ${r.datos.caratula || ''}`).slice(0, 100), M, H - 24);
  }
  return { pdf, inserciones };
}

// Une el índice con los documentos (pdf-lib) y numera todas las páginas
async function armarCompleto(indiceBytes, inserciones) {
  const { PDFDocument, StandardFonts, rgb } = PDFLib;
  const base = await PDFDocument.load(indiceBytes);
  const out = await PDFDocument.create();
  const porPagina = {};
  inserciones.forEach(x => (porPagina[x.despuesDe] = porPagina[x.despuesDe] || []).push(...x.pdfs));
  const paginas = await out.copyPages(base, base.getPageIndices());
  for (let p = 0; p < paginas.length; p++) {
    out.addPage(paginas[p]);
    for (const bytes of porPagina[p + 1] || []) {
      try {
        const doc = await PDFDocument.load(bytes, { ignoreEncryption: true });
        (await out.copyPages(doc, doc.getPageIndices())).forEach(pg => out.addPage(pg));
      } catch (e) { /* un documento dañado no frena el resto */ }
    }
  }
  const fuente = await out.embedFont(StandardFonts.Helvetica);
  const total = out.getPageCount();
  out.getPages().forEach((pg, i) => {
    const { width } = pg.getSize(), t = `Página ${i + 1} de ${total}`;
    pg.drawText(t, { x: width - 48 - fuente.widthOfTextAtSize(t, 7.5), y: 14, size: 7.5, font: fuente, color: rgb(0.55, 0.5, 0.45) });
  });
  return out.save();
}

function aDataUrl(blob) {
  return new Promise(ok => { const fr = new FileReader(); fr.onload = () => ok(fr.result); fr.readAsDataURL(blob); });
}

// ── Cola ─────────────────────────────────────────────────────────────────
async function correr(j) {
  const paso = (avance, msg) => actualizar(j.id, { avance: Math.round(avance), msg });
  await actualizar(j.id, { estado: 'descargando', avance: 1, msg: 'Empezando…' });
  try {
    const r = j.trabajo.f === 'MEV' ? await descargarMev(j, paso) : await descargarPjn(j, paso);
    paso(92, 'Armando el PDF…');
    const { pdf, inserciones } = armarIndice(r);
    const indice = new Uint8Array(pdf.output('arraybuffer'));
    paso(95, inserciones.length ? 'Uniendo los documentos…' : 'Guardando…');
    const completo = await armarCompleto(indice, inserciones);
    const blob = new Blob([completo], { type: 'application/pdf' });
    const nombre = latin(`Expediente ${r.datos.numero || ''} - ${(r.datos.caratula || '').slice(0, 60)}`).replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, ' ').trim() + '.pdf';
    urls[j.id] = URL.createObjectURL(blob);
    // A la carpeta Descargas\IusTrack
    try { await chrome.downloads.download({ url: urls[j.id], filename: 'IusTrack/' + nombre, conflictAction: 'uniquify', saveAs: false }); } catch (e) {}
    // A IusTrack: el completo si entra en la nube; si no, el índice con los textos
    const docs = r.movs.reduce((s, m) => s + (m.pdfs ? m.pdfs.length : 0), 0);
    const nube = blob.size <= LIMITE_NUBE ? blob : new Blob([indice], { type: 'application/pdf' });
    await chrome.runtime.sendMessage({ it: 'archivo-listo', archivo: { id: j.id, expId: j.trabajo.expId, nombre, fuente: j.trabajo.f,
      movimientos: r.movs.length, documentos: nube === blob ? docs : 0, docsEnPc: nube === blob ? 0 : docs,
      ultimo: r.movs.map(m => m.fecha).sort().pop() || '', tamanio: nube.size, data: await aDataUrl(nube) } });
    await actualizar(j.id, { estado: 'listo', avance: 100, fin: Date.now(), msg:
      `${r.movs.length} movimientos${docs ? ` y ${docs} documentos` : ''} · ${(blob.size / 1048576).toFixed(1)} MB · guardado en Descargas\\IusTrack` +
      (nube === blob ? ' y adjuntado en IusTrack.' : '. En IusTrack se adjuntó el índice con los textos (el completo pesa demasiado para la nube).') });
  } catch (e) {
    await actualizar(j.id, { estado: 'error', avance: 0, msg: String(e && e.message || e) });
  }
}
async function procesar() {
  if (trabajando) return;
  trabajando = true;
  try {
    for (;;) {
      const cola = (await chrome.storage.local.get('itDescCola')).itDescCola || [];
      // Una que quedó "descargando" de una sesión anterior (se cerró la pestaña) vuelve a la cola
      const j = cola.find(x => x.estado === 'cola') || cola.find(x => x.estado === 'descargando' && !x.enEsta);
      if (!j) break;
      await correr(j);
    }
  } finally { trabajando = false; }
}

chrome.tabs.getCurrent(t => { if (t) chrome.storage.local.set({ itDescTab: t.id }); });
pintar();
procesar();
