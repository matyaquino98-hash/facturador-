/* IusTrack — genera los íconos de la app instalable, el favicon y las pantallas de arranque
   a partir del logo del estudio (marca/icono-dibujo.png: el logo IUS TRACK con la balanza
   que forma la T, sin fondo — el mismo de la app, recortado). Deja todo en marca/app/:
   armar-actualizacion.js lo copia a la carpeta "publicar" y a iustrack-app.zip.
   Uso (sólo si cambia el logo):  npm i -g playwright  y luego
           node herramientas/generar-marca.js */
const fs = require('fs'), path = require('path');
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { console.error('Falta Playwright: npm i -g playwright (y npx playwright install chromium)'); process.exit(1); }
const RAIZ = path.resolve(__dirname, '..'), M = path.join(RAIZ, 'marca'), SAL = path.join(M, 'app');
fs.mkdirSync(SAL, { recursive: true });
const dibujo = 'data:image/png;base64,' + fs.readFileSync(path.join(M, 'icono-dibujo.png')).toString('base64');
const fuentes = fs.existsSync(path.join(M, 'fuentes', 'fuentes.css'))
  ? `<style>${fs.readFileSync(path.join(M, 'fuentes', 'fuentes.css'), 'utf8').replace(/url\(([^)]+\.woff2)\)/g, (m, f) => `url(data:font/woff2;base64,${fs.readFileSync(path.join(M, 'fuentes', f)).toString('base64')})`)}</style>`
  : `<link href="https://fonts.googleapis.com/css2?family=Geist:wght@400..600&display=swap" rel="stylesheet">`;
// El ícono: recuadro blanco redondeado con el dibujo, como el logo original
const icono = (lado, sangre, sombra) => `<div style="width:${lado}px;height:${lado}px;${sangre ? '' : `border-radius:${lado * 0.23}px;border:${Math.max(1, lado / 256)}px solid #EADBCB;`}
  background:#FFFFFF;display:flex;align-items:center;justify-content:center;box-sizing:border-box;
  ${sombra ? `box-shadow:0 ${lado * 0.08}px ${lado * 0.16}px rgba(120,60,20,.22),0 ${lado * 0.01}px ${lado * 0.03}px rgba(120,60,20,.12);` : ''}">
  <img src="${dibujo}" style="width:${sangre ? 70 : 80}%;margin-top:${sangre ? 0 : -lado * 0.02}px;display:block"></div>`;
const ARRANQUES = [[1125, 2436], [1170, 2532], [1179, 2556], [1284, 2778], [1290, 2796], [750, 1334]];
(async () => {
  const b = await chromium.launch();
  async function png(html, w, h, archivo, transparente) {
    const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
    await p.setContent(`<!doctype html><html><head>${fuentes}<style>html,body{margin:0;width:${w}px;height:${h}px;overflow:hidden;background:${transparente ? 'transparent' : '#FDF7F0'}}</style></head><body>${html}</body></html>`);
    await p.evaluate(() => Promise.all([document.fonts.ready, ...[...document.images].map(i => i.decode())]));
    await p.waitForTimeout(100);
    await p.screenshot({ path: path.join(SAL, archivo), omitBackground: !!transparente });
    await p.close();
    console.log('  ' + archivo);
  }
  const centro = (html, l) => `<div style="width:${l}px;height:${l}px;display:flex;align-items:center;justify-content:center">${html}</div>`;
  for (const l of [192, 512]) await png(centro(icono(Math.round(l * 0.94)), l), l, l, `icono-${l}.png`, true);
  await png(icono(512, true), 512, 512, 'icono-maskable-512.png');
  for (const l of [120, 152, 167, 180]) await png(icono(l, true), l, l, `apple-icono-${l}.png`);
  for (const l of [64, 32]) await png(centro(icono(l), l), l, l, `favicon-${l}.png`, true);
  await png(centro(icono(96), 96), 96, 96, 'icono-96.png', true);   // lo usa el bloque (favicon y menú achicado)
  for (const f of ['favicon.svg']) { try { fs.unlinkSync(path.join(SAL, f)); } catch (e) {} }   // el logo es una imagen: no hay versión SVG
  for (const [w, h] of ARRANQUES) {
    const k = w / 1170;
    await png(`<div style="width:${w}px;height:${h}px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:${60 * k}px;
        background:radial-gradient(${900 * k}px ${700 * k}px at 85% 0%,rgba(255,140,40,.28),transparent 65%),radial-gradient(${800 * k}px ${600 * k}px at 0% 100%,rgba(226,69,12,.14),transparent 60%),#FDF7F0">
        ${icono(Math.round(640 * k), false, true)}
        <div style="font-family:'Geist',sans-serif;font-size:${46 * k}px;color:#8B7460">Gestión judicial</div></div>`, w, h, `arranque-${w}x${h}.png`);
  }
  await b.close();
  console.log('Listo: marca/app');
})().catch(e => { console.error(e); process.exit(1); });
