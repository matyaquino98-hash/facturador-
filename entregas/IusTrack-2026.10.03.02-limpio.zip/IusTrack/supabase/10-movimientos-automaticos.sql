-- ════════════════════════════════════════════════════════════════════════
-- IusTrack — 10. Movimientos cargados automáticamente desde la MEV y el PJN
-- La extensión de Chrome lee los movimientos del expediente (al abrirlo o en la
-- revisión periódica) y IusTrack los carga como movimientos comunes.
--   origen         'manual' (cargado a mano) · 'mev' · 'pjn'
--   clave_externa  identificador del movimiento en el portal (MEV: nPosi; PJN:
--                  fecha + huella del texto). Evita cargar dos veces el mismo,
--                  aunque lo traigan dos usuarios distintos a la vez.
-- Se puede correr más de una vez sin problema.
-- ════════════════════════════════════════════════════════════════════════

alter table public.movimientos add column if not exists origen        text not null default 'manual';
alter table public.movimientos add column if not exists clave_externa text;

-- Un mismo movimiento del portal entra una sola vez por expediente. Los cargados
-- a mano (clave_externa vacía) no se ven afectados: en Postgres los nulos no chocan.
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'movimientos_clave_externa_uk') then
    alter table public.movimientos
      add constraint movimientos_clave_externa_uk unique (expediente_id, clave_externa);
  end if;
end $$;

-- Para avisar a la app que lea las columnas nuevas
notify pgrst, 'reload schema';
