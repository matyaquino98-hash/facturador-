-- ════════════════════════════════════════════════════════════════════════
-- IusTrack — 13: fotos de perfil y chat del equipo
-- Pegar completo en Supabase → SQL Editor → Run. Se puede correr más de una vez.
-- Requiere los scripts 01 (base), 04 (modelos) y 07 (mensajes).
--
-- · perfiles.foto            la foto de cada usuario (JPG 320×320 en texto, hasta ~300 KB).
--                            La ven sus compañeros de estudio (regla per_ver del script 01)
--                            en todas las computadoras y en el chat.
-- · perfiles.foto_en         cuándo cambió (cada IusTrack baja sólo las fotos nuevas).
-- · perfiles.ultima_conexion "visto por última vez" en el chat.
-- · Cada usuario sólo puede cambiar SU foto y su última conexión (no el permiso de dueño).
-- · Chat: usa la tabla "mensajes" del script 07 (no se toca lo ya conversado). Acá sólo se
--   asegura que esté en Supabase Realtime (avisos al instante y "visto"). Quién está
--   conectado y "escribiendo…" van por Realtime (presencia), sin tablas.
-- ════════════════════════════════════════════════════════════════════════

alter table public.perfiles add column if not exists foto            text;
alter table public.perfiles add column if not exists foto_en         timestamptz;
alter table public.perfiles add column if not exists ultima_conexion timestamptz;

-- Sólo imágenes JPG/PNG/WebP en base64 (sin comillas ni código) y de tamaño razonable
alter table public.perfiles drop constraint if exists perfiles_foto_valida;
alter table public.perfiles add constraint perfiles_foto_valida
  check (foto is null or (foto ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' and char_length(foto) <= 400000));

-- Permisos de columna: el propio usuario edita nombre, datos profesionales, foto y conexión.
-- (la regla per_mod del script 01 ya limita la edición a la fila propia)
alter table public.perfiles add column if not exists datos_prof jsonb not null default '{}'::jsonb;   -- (script 04)
revoke update on public.perfiles from authenticated, anon;
grant  update (nombre, datos_prof, foto, foto_en, ultima_conexion) on public.perfiles to authenticated;

-- La fecha de la foto la pone el servidor (no se puede falsear)
create or replace function public.tg_perfil_foto() returns trigger
language plpgsql set search_path = public as $$
begin
  if new.foto is distinct from old.foto then new.foto_en := now(); end if;
  if new.ultima_conexion is not null and new.ultima_conexion > now() + interval '5 minutes' then
    new.ultima_conexion := now();
  end if;
  return new;
end $$;
drop trigger if exists tg_perfil_foto on public.perfiles;
create trigger tg_perfil_foto before update on public.perfiles
  for each row execute function public.tg_perfil_foto();

-- Mensajes en Realtime (por si el script 07 se corrió antes de activar Realtime)
do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and exists (select 1 from information_schema.tables where table_schema = 'public' and table_name = 'mensajes')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'mensajes') then
    alter publication supabase_realtime add table public.mensajes;
  end if;
end $$;

-- Búsqueda rápida de la conversación entre dos personas
create index if not exists ix_mensajes_conversacion on public.mensajes(estudio_id, de_usuario, para_usuario, creado_en);

notify pgrst, 'reload schema';

-- Para revisar: quién ya subió su foto
-- select nombre, email, foto_en, ultima_conexion, char_length(foto) as tamanio from public.perfiles order by nombre;
