-- ════════════════════════════════════════════════════════════════════════
-- IusTrack — 13: fotos de perfil y chat del equipo
-- Pegar completo en Supabase → SQL Editor → Run. Se puede correr más de una vez.
-- Requiere los scripts 01 (base), 04 (modelos) y 07 (mensajes).
--
-- · perfiles.foto            la foto de cada usuario (JPG 320×320 en texto, hasta ~300 KB).
--                            La ven sus compañeros de estudio (regla per_ver del script 01)
--                            en todas las computadoras y en el chat.
-- · perfiles.foto_en         cuándo cambió (cada IusTrack baja sólo las fotos nuevas).
-- · perfiles.ultima_conexion "visto por última vez" en el chat.
-- · Cada usuario sólo puede cambiar SU foto y su última conexión (no el permiso de dueño).
-- · poner_foto(): el administrador del estudio le pone la foto a quien lo necesite.
-- · Chat: usa la tabla "mensajes" del script 07 (no se toca lo ya conversado). Se agrega
--   mensajes.responde_a (responder citando) y se asegura que esté en Supabase Realtime
--   (avisos al instante y "visto"). Quién está conectado y "escribiendo…" van por
--   Realtime (presencia), sin tablas.
-- ════════════════════════════════════════════════════════════════════════

alter table public.perfiles add column if not exists foto            text;
alter table public.perfiles add column if not exists foto_en         timestamptz;
alter table public.perfiles add column if not exists ultima_conexion timestamptz;

-- Sólo imágenes JPG/PNG/WebP en base64 (sin comillas ni código) y de tamaño razonable
alter table public.perfiles drop constraint if exists perfiles_foto_valida;
alter table public.perfiles add constraint perfiles_foto_valida
  check (foto is null or (foto ~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' and char_length(foto) <= 400000));

-- Permisos de columna: el propio usuario edita nombre, datos profesionales, foto y conexión.
-- (la regla per_mod del script 01 ya limita la edición a la fila propia)
alter table public.perfiles add column if not exists datos_prof jsonb not null default '{}'::jsonb;   -- (script 04)
revoke update on public.perfiles from authenticated, anon;
grant  update (nombre, datos_prof, foto, foto_en, ultima_conexion) on public.perfiles to authenticated;

-- La fecha de la foto la pone el servidor (no se puede falsear)
create or replace function public.tg_perfil_foto() returns trigger
language plpgsql set search_path = public as $$
begin
  if new.foto is distinct from old.foto then new.foto_en := now(); end if;
  if new.ultima_conexion is not null and new.ultima_conexion > now() + interval '5 minutes' then
    new.ultima_conexion := now();
  end if;
  return new;
end $$;
drop trigger if exists tg_perfil_foto on public.perfiles;
create trigger tg_perfil_foto before update on public.perfiles
  for each row execute function public.tg_perfil_foto();

-- El administrador del estudio puede ponerle (o quitarle) la foto a otra persona del estudio,
-- para quien no se arregla solo. Cada uno sigue pudiendo cambiar la suya.
create or replace function public.poner_foto(p_usuario uuid, p_foto text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_foto is not null and (p_foto !~ '^data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$' or char_length(p_foto) > 400000) then
    raise exception 'La foto no es válida';
  end if;
  if p_usuario is distinct from auth.uid() and not public.es_superadmin() and not exists (
       select 1 from miembros yo join miembros el on el.estudio_id = yo.estudio_id
       where yo.usuario_id = auth.uid() and yo.rol = 'admin' and yo.activo and el.usuario_id = p_usuario) then
    raise exception 'Sólo un administrador del estudio puede cambiar la foto de otra persona';
  end if;
  update perfiles set foto = p_foto where id = p_usuario;      -- foto_en la pone el disparador
end $$;
revoke all on function public.poner_foto(uuid, text) from public, anon;
grant execute on function public.poner_foto(uuid, text) to authenticated;

-- Mensajes en Realtime (por si el script 07 se corrió antes de activar Realtime)
do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and exists (select 1 from information_schema.tables where table_schema = 'public' and table_name = 'mensajes')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'mensajes') then
    alter publication supabase_realtime add table public.mensajes;
  end if;
end $$;

-- ── Chat: responder citando un mensaje ───────────────────────────────────
alter table public.mensajes add column if not exists responde_a uuid references public.mensajes(id) on delete set null;

-- Misma regla del script 07, más la cita: sólo se puede citar un mensaje de la misma
-- conversación, y la cita no se cambia después.
create or replace function public.tg_mensaje() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.de_usuario := coalesce(auth.uid(), new.de_usuario);
    new.creado_en := now();
    new.leido_en := null;
    if new.para_usuario = new.de_usuario then raise exception 'No podés mandarte un mensaje a vos mismo'; end if;
    if not exists (select 1 from miembros where estudio_id = new.estudio_id and usuario_id = new.para_usuario and activo) then
      raise exception 'El destinatario no pertenece al estudio';
    end if;
    if new.adjunto_ruta is not null and (split_part(new.adjunto_ruta, '/', 1) <> new.estudio_id::text
                                         or split_part(new.adjunto_ruta, '/', 2) <> new.de_usuario::text) then
      raise exception 'El archivo adjunto no es válido';
    end if;
    if new.responde_a is not null and not exists (
         select 1 from mensajes m where m.id = new.responde_a and m.estudio_id = new.estudio_id
           and ((m.de_usuario = new.de_usuario and m.para_usuario = new.para_usuario)
             or (m.de_usuario = new.para_usuario and m.para_usuario = new.de_usuario))) then
      new.responde_a := null;
    end if;
  else
    new.id := old.id; new.estudio_id := old.estudio_id; new.de_usuario := old.de_usuario;
    new.para_usuario := old.para_usuario; new.texto := old.texto; new.creado_en := old.creado_en;
    new.adjunto_ruta := old.adjunto_ruta; new.adjunto_nombre := old.adjunto_nombre;
    new.adjunto_tipo := old.adjunto_tipo; new.adjunto_tamanio := old.adjunto_tamanio;
    new.responde_a := old.responde_a;
  end if;
  return new;
end $$;
drop trigger if exists tg_mensaje on public.mensajes;
create trigger tg_mensaje before insert or update on public.mensajes
  for each row execute function public.tg_mensaje();
-- (Las notas de voz son adjuntos de audio: usan la misma carpeta "mensajes" del script 07.)

-- Búsqueda rápida de la conversación entre dos personas
create index if not exists ix_mensajes_conversacion on public.mensajes(estudio_id, de_usuario, para_usuario, creado_en);

notify pgrst, 'reload schema';

-- Para revisar: quién ya subió su foto
-- select nombre, email, foto_en, ultima_conexion, char_length(foto) as tamanio from public.perfiles order by nombre;
