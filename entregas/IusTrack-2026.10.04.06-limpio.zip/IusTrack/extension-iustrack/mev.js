/* LexTrack — aviso en la pantalla de ingreso de la MEV cuando hay un expediente esperando */
(() => {
  if (!/\/(loguin|login)\.asp$/i.test(location.pathname) && location.pathname !== '/') return;
  chrome.runtime.sendMessage({ q: 'mevPendiente' }, r => {
    if (chrome.runtime.lastError || !r || !r.pendiente) return;
    const d = document.createElement('div');
    d.style.cssText = 'position:fixed;top:14px;right:14px;z-index:2147483647;max-width:360px;padding:12px 16px;border-radius:10px;' +
      'font:14px/1.4 Arial,sans-serif;background:#fff8e6;color:#5c4300;border:1px solid #f0d98c;box-shadow:0 6px 24px rgba(0,0,0,.25);cursor:pointer';
    d.textContent = 'LexTrack: ingresá con tu usuario y te llevo directo al expediente.';
    d.title = 'Clic para cerrar';
    d.onclick = () => d.remove();
    document.body.appendChild(d);
  });
})();
