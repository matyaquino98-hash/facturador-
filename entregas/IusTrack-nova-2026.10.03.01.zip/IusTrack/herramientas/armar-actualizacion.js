/* IusTrack — arma una actualización
   Uso:  node herramientas/armar-actualizacion.js "Qué cambió (se ve en el historial)"

   1. Toma el bloque de mejoras (bloque-movimientos-automaticos.html).
   2. Le pone versión AAAA.MM.DD.NN y guarda actualizaciones/IusTrack-actualizacion-<versión>.iustrack
      (esto es lo que se sube con "🔄 Actualizar" en IusTrack).
   3. Vuelve a armar IusTrack-nube 01-10-26.html y iustrack-app.zip a partir de las bases
      (…antes-movimientos), con el cargador y esta versión adentro, para instalaciones nuevas.
   4. Arma la carpeta publicar\ (Netlify) con el logo y los íconos de marca\app.
   Funciona en Windows (PowerShell) y en Mac/Linux (zip y unzip). */
const fs = require('fs'), path = require('path'), crypto = require('crypto'), os = require('os');
const { execFileSync } = require('child_process');

const RAIZ = path.resolve(__dirname, '..');
const r = p => path.join(RAIZ, p);
const BLOQUE = r('bloque-movimientos-automaticos.html');
const CARGADOR = r('herramientas/cargador.js');
const BASE_HTML = r('IusTrack-nube 01-10-26.antes-movimientos.html'), SALIDA_HTML = r('IusTrack-nube 01-10-26.html');
const BASE_ZIP = r('iustrack-app.antes-movimientos.zip'), SALIDA_ZIP = r('iustrack-app.zip');
const DIR_ACT = r('actualizaciones');

const notas = process.argv.slice(2).join(' ').trim();
if (!notas) { console.error('Falta la descripción: node herramientas/armar-actualizacion.js "Qué cambió"'); process.exit(1); }

// 1) Código del bloque
const html = fs.readFileSync(BLOQUE, 'utf8');
const ini = html.indexOf('<script>'), fin = html.lastIndexOf('</script>');
if (ini < 0 || fin < 0) throw new Error('no encontré <script> en el bloque');
const codigo = html.slice(ini + '<script>'.length, fin).replace(/^\n/, '');
if (/<\/script/i.test(codigo) || /<!--/.test(codigo)) throw new Error('el bloque tiene "</script" o "<!--": no se puede guardar como texto');
new Function(codigo);                                     // que compile
const cargador = fs.readFileSync(CARGADOR, 'utf8');
new Function(cargador);

// 2) Versión: AAAA.MM.DD.NN (NN = número de actualización del día)
fs.mkdirSync(DIR_ACT, { recursive: true });
const hoy = new Date(), dia = `${hoy.getFullYear()}.${String(hoy.getMonth() + 1).padStart(2, '0')}.${String(hoy.getDate()).padStart(2, '0')}`;
const previas = fs.readdirSync(DIR_ACT).map(f => (f.match(/(\d{4}\.\d{2}\.\d{2}\.\d{2})\.iustrack$/) || [])[1]).filter(Boolean).sort();
const delDia = previas.filter(v => v.startsWith(dia)).map(v => +v.slice(-2));
const version = `${dia}.${String((delDia.length ? Math.max(...delDia) : 0) + 1).padStart(2, '0')}`;
if (previas.length && previas[previas.length - 1] >= version) throw new Error('ya hay una versión más nueva: ' + previas[previas.length - 1]);
const huella = crypto.createHash('sha256').update(codigo, 'utf8').digest('hex');
const archivo = path.join(DIR_ACT, `IusTrack-actualizacion-${version}.iustrack`);
fs.writeFileSync(archivo, JSON.stringify({ formato: 'iustrack-actualizacion', version, fecha: hoy.toISOString(), notas, huella, codigo }));

// 3) Archivos completos para instalaciones nuevas
const escAttr = s => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
const config = (() => { try { return JSON.parse(fs.readFileSync(r('herramientas/config.json'), 'utf8')); } catch (e) { return {}; } })();
const insertar = base => {
  // Dirección publicada (para "💻 Instalar app" cuando IusTrack se abre como archivo)
  if (config.url && !base.includes('name="iustrack-url"')) base = base.replace('<head>', `<head>\n<meta name="iustrack-url" content="${escAttr(config.url)}">`);
  const i = base.lastIndexOf('</body>');
  if (i < 0) throw new Error('la base no tiene </body>');
  return base.slice(0, i) +
    `<script id="it-bloque" type="text/plain" data-version="${version}" data-notas="${escAttr(notas)}">\n${codigo}</script>\n` +
    `<script>\n${cargador}</script>\n` + base.slice(i);
};
fs.writeFileSync(SALIDA_HTML, insertar(fs.readFileSync(BASE_HTML, 'utf8')));

// App instalable (index.html del zip): se arma igual y se ajusta para computadoras
const WIN = process.platform === 'win32';
const descomprimir = (zip, dir) => WIN ? execFileSync('powershell', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${zip}' -DestinationPath '${dir}' -Force`])
  : execFileSync('unzip', ['-o', '-q', zip, '-d', dir]);
const comprimir = (dir, zip) => WIN ? execFileSync('powershell', ['-NoProfile', '-Command', `Compress-Archive -Path '${dir}\\*' -DestinationPath '${zip}' -Force`])
  : (fs.rmSync(zip, { force: true }), execFileSync('zip', ['-r', '-q', '-X', zip, '.'], { cwd: dir }));
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'iustrack-'));
descomprimir(BASE_ZIP, tmp);
// Logo e íconos nuevos (marca/app, se generan con herramientas/generar-marca.js)
const MARCA = r('marca/app');
if (fs.existsSync(MARCA)) for (const f of fs.readdirSync(MARCA)) fs.copyFileSync(path.join(MARCA, f), path.join(tmp, f));
let index = insertar(fs.readFileSync(path.join(tmp, 'index.html'), 'utf8'));
index = index.replace(/<link rel="icon" type="image\/png" sizes="64x64" href="data:[^"]*">/,
  '<link rel="icon" type="image/svg+xml" href="favicon.svg"><link rel="icon" type="image/png" sizes="64x64" href="favicon-64.png">');
// El aviso de instalar decía "en tu celular" también en la computadora
index = index.replace(`'Instalá IusTrack en tu celular'`, `(/Android|iPhone|iPad|Mobi/i.test(navigator.userAgent) ? 'Instalá IusTrack en tu celular' : 'Instalá IusTrack en esta computadora')`);
fs.writeFileSync(path.join(tmp, 'index.html'), index);
const sw = path.join(tmp, 'sw.js');
fs.writeFileSync(sw, fs.readFileSync(sw, 'utf8').replace(/const CACHE = '[^']*'/, `const CACHE = 'iustrack-${version}'`));
// Manifiesto: colores de la app, sin fijar la orientación (en la computadora no corresponde)
const mf = path.join(tmp, 'manifest.webmanifest'), m = JSON.parse(fs.readFileSync(mf, 'utf8'));
Object.assign(m, { orientation: 'any', background_color: '#FDF7F0', theme_color: '#FDF7F0', display_override: ['standalone', 'minimal-ui'],
  launch_handler: { client_mode: 'focus-existing' }, categories: ['business', 'productivity'], lang: 'es-AR', dir: 'ltr' });
fs.writeFileSync(mf, JSON.stringify(m, null, 2));
const zipTmp = path.join(tmp, '..', `iustrack-app-${version}.zip`);
comprimir(tmp, zipTmp);
fs.copyFileSync(zipTmp, SALIDA_ZIP);

// 4) Carpeta "publicar": lo que se sube a Netlify (se arrastra en app.netlify.com/drop o en Deploys)
const PUB = r('publicar');
fs.rmSync(PUB, { recursive: true, force: true });
fs.mkdirSync(PUB);
for (const f of fs.readdirSync(tmp)) fs.copyFileSync(path.join(tmp, f), path.join(PUB, f));
// Que el navegador pida siempre la app, el service worker y el manifiesto (nunca una versión vieja guardada)
fs.writeFileSync(path.join(PUB, '_headers'),
  ['/', '/index.html', '/sw.js', '/manifest.webmanifest'].map(p => `${p}\n  Cache-Control: no-cache`).join('\n') +
  `\n/manifest.webmanifest\n  Content-Type: application/manifest+json\n/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n`);
fs.writeFileSync(path.join(PUB, 'version.txt'), version + '\n');
fs.rmSync(tmp, { recursive: true, force: true }); fs.rmSync(zipTmp, { force: true });

console.log(`Versión ${version}`);
console.log(`  Actualización: ${path.relative(RAIZ, archivo)} (${(fs.statSync(archivo).size / 1024).toFixed(0)} KB)`);
console.log(`  IusTrack:      ${path.relative(RAIZ, SALIDA_HTML)} y ${path.relative(RAIZ, SALIDA_ZIP)}`);
console.log(`  Para publicar: carpeta publicar${path.sep} (arrastrarla a Netlify)${config.url ? ' → ' + config.url : ''}`);
