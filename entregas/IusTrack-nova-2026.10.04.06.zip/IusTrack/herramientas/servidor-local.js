/* IusTrack — sirve la carpeta "publicar" en http://localhost:8787 para probarla antes de subirla
   (localhost cuenta como dirección segura: se puede instalar y registrar el service worker).
   Uso: node herramientas/servidor-local.js */
const http = require('http'), fs = require('fs'), path = require('path');
const RAIZ = path.resolve(__dirname, '..', 'publicar'), PUERTO = +process.env.PORT || 8787;
const TIPOS = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png',
  '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.txt': 'text/plain; charset=utf-8' };
http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p.endsWith('/')) p += 'index.html';
  const f = path.join(RAIZ, path.normalize(p).replace(/^(\.\.[\/\\])+/, ''));
  if (!f.startsWith(RAIZ) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('No encontrado'); }
  res.writeHead(200, { 'Content-Type': TIPOS[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(f).pipe(res);
}).listen(PUERTO, () => console.log(`IusTrack en http://localhost:${PUERTO}`));
