/* IusTrack — ventanita de la extensión: estado de la revisión y configuración */
const $ = id => document.getElementById(id);
const cuando = t => t ? new Date(t).toLocaleString('es-AR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '';

function mostrar() {
  chrome.runtime.sendMessage({ it: 'estado' }, r => {
    if (!r) return;
    const e = r.estado || {}, lista = (r.seg && r.seg.lista) || [];
    $('seg').textContent = lista.length
      ? `${lista.filter(x => x.f === 'MEV').length} de la MEV · ${lista.filter(x => x.f === 'PJN').length} del PJN (lista recibida ${cuando(r.seg.t)})`
      : 'Ninguno: abrí IusTrack para que le pase la lista a la extensión.';
    if (e.mev) $('mev').textContent = e.mev + (e.ultima ? ` (${cuando(e.ultima)})` : '');
    if (e.pjn) $('pjn').textContent = e.pjn + (e.ultimaPjn ? ` (${cuando(e.ultimaPjn)})` : '');
    $('pend').textContent = r.pendientes ? `${r.pendientes} movimiento(s): abrí IusTrack` : 'Nada pendiente';
    $('aviso').hidden = !e.aviso; $('aviso').textContent = e.aviso || '';
    $('auto').checked = r.cfg.auto !== false;
    $('cada').value = String(r.cfg.cadaMin || 180);
    $('ahora').disabled = r.revisando;
    $('ahora').textContent = r.revisando ? 'Revisando…' : 'Revisar ahora';
  });
}
const guardar = () => chrome.runtime.sendMessage({ it: 'config', cfg: { auto: $('auto').checked, cadaMin: +$('cada').value } });
$('auto').onchange = guardar;
$('cada').onchange = guardar;
$('ahora').onclick = () => chrome.runtime.sendMessage({ it: 'revisar' }, () => setTimeout(mostrar, 400));
$('descargas').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('descarga.html') });
mostrar();
setInterval(mostrar, 3000);
