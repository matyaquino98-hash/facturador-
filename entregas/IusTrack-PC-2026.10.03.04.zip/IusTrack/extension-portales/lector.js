/* IusTrack — SRT y EJE: lector del listado de causas.
   Corre en las páginas de la SRT, del EJE de CABA y en el ingreso con Clave Fiscal.
   · Busca en la página las tablas de expedientes (tabla común o grilla), reconoce las
     columnas por su título (N° de expediente, carátula, motivo, damnificado, fecha de
     inicio, organismo, estado) y muestra el botón "Enviar a IusTrack".
   · Si IusTrack pidió "Leer mis causas", las manda solas apenas aparece el listado.
   · En el ingreso con Clave Fiscal sólo completa el CUIT: la clave la escribe el usuario. */
(() => {
  if (window.__itPortales) return; window.__itPortales = true;
  const host = location.hostname;
  const ORIGEN = /(^|\.)srt\.gob\.ar$/.test(host) ? 'SRT' : /^eje\.(juscaba\.gob|jus\.gov)\.ar$/.test(host) ? 'EJE' : /(^|\.)afip\.gob\.ar$/.test(host) ? 'AFIP' : '';
  if (!ORIGEN) return;
  const NOMBRE = { SRT: 'SRT · Comisiones Médicas', EJE: 'EJE · Justicia CABA' };
  const pedir = m => new Promise(r => { try { chrome.runtime.sendMessage(m, x => r(chrome.runtime.lastError ? null : x)); } catch (e) { r(null); } });
  const limpio = t => String(t || '').replace(/\s+/g, ' ').trim();
  const llano = t => limpio(t).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[°º.:#]/g, ' ').replace(/\s+/g, ' ').trim();

  // ── Qué es cada columna, por su título ─────────────────────────────
  function tipoCol(t) {
    const s = llano(t);
    if (!s || s.length > 60) return '';
    if (/caratula|autos/.test(s)) return 'caratula';
    if (/damnificad|trabajador|requirente|solicitante|^actor/.test(s)) return 'damnificado';
    if (/motivo|tramite|objeto|materia|tipo de (expediente|proceso|causa)/.test(s)) return 'motivo';
    if (/comision|juzgado|organismo|dependencia|radicac|tribunal|sede|fuero|secretaria|sala/.test(s)) return 'juzgado';
    if (/estado|situacion|etapa/.test(s)) return 'estado';
    if (/inicio|fecha|ingreso|alta|creacion|presentacion/.test(s)) return 'inicio';
    if (/expediente|expte|numero|^n( |$)|^nro|^num|causa|cuij|identificador/.test(s)) return 'numero';
    return '';
  }
  const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  const texto = el => limpio(el.innerText != null ? el.innerText : el.textContent);
  function tablas() {
    const res = [];
    document.querySelectorAll('table').forEach(t => {
      if (!visible(t)) return;
      const filas = [...t.rows]; if (filas.length < 2) return;
      const cab = t.tHead && t.tHead.rows.length ? t.tHead.rows[t.tHead.rows.length - 1] : (filas.find(r => r.querySelector('th')) || filas[0]);
      res.push({ heads: [...cab.cells].map(texto), filas: filas.filter(r => r !== cab && !(t.tHead && t.tHead.contains(r))).map(r => ({ el: r, celdas: [...r.cells].map(texto) })) });
    });
    // Grillas armadas con roles (Angular Material y similares)
    document.querySelectorAll('[role="table"],[role="grid"],[role="treegrid"]').forEach(g => {
      if (g.tagName === 'TABLE' || !visible(g)) return;
      const rows = [...g.querySelectorAll('[role="row"]')];
      const celdas = r => [...r.querySelectorAll('[role="columnheader"],[role="cell"],[role="gridcell"],[role="rowheader"]')];
      const cab = rows.find(r => r.querySelector('[role="columnheader"]')); if (!cab) return;
      res.push({ heads: celdas(cab).map(texto), filas: rows.filter(r => !r.querySelector('[role="columnheader"]')).map(r => ({ el: r, celdas: celdas(r).map(texto) })) });
    });
    return res;
  }
  function leerCausas() {
    const items = [], vistos = new Set();
    tablas().forEach(t => {
      const tipos = t.heads.map(tipoCol);
      if (tipos.indexOf('numero') < 0 || tipos.filter(Boolean).length < 2) return;
      t.filas.forEach(f => {
        const v = k => { const i = tipos.indexOf(k); return i >= 0 ? (f.celdas[i] || '') : ''; };
        const numero = v('numero');
        if (!numero || !/\d/.test(numero) || numero.length > 60) return;
        const k = numero.toUpperCase().replace(/\s+/g, ''); if (vistos.has(k)) return; vistos.add(k);
        const a = f.el.querySelector('a[href]:not([href^="javascript"]):not([href="#"])');
        items.push({ numero, caratula: v('caratula'), motivo: v('motivo'), damnificado: v('damnificado'), juzgado: v('juzgado'),
          inicio: v('inicio'), estado: v('estado'), link: a && /^https:/.test(a.href) ? a.href : '' });
      });
    });
    return items;
  }
  const pideIngreso = () => [...document.querySelectorAll('input[type="password"]')].some(visible);

  // ── Botón flotante (con el estilo de IusTrack) ─────────────────────
  let host_, raiz, ultimo = 0, enviando = false;
  function boton(n, nota) {
    if (window.top !== window && !n) return;
    if (!host_) {
      host_ = document.createElement('div'); host_.id = 'iustrack-portales';
      host_.style.cssText = 'position:fixed;right:22px;bottom:22px;z-index:2147483646';
      raiz = host_.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host_);
    }
    if (!n && !nota) { host_.style.display = 'none'; return; }
    host_.style.display = '';
    const logo = chrome.runtime.getURL('icono.png');
    raiz.innerHTML = `<style>
      .b{all:initial;display:flex;align-items:center;gap:12px;padding:10px 18px 10px 10px;border-radius:999px;cursor:pointer;
         font:600 15px/1.25 system-ui,-apple-system,"Segoe UI",sans-serif;color:#fff;background:linear-gradient(135deg,#FF9A3C,#E2450C);
         box-shadow:0 14px 34px rgba(160,60,10,.35),0 2px 6px rgba(0,0,0,.18);transition:transform .2s cubic-bezier(.3,1.4,.5,1)}
      .b:hover{transform:translateY(-2px) scale(1.02)}.b[disabled]{opacity:.7;cursor:default}
      img{width:40px;height:40px;border-radius:12px;background:#fff;display:block}
      small{display:block;font-weight:500;font-size:12px;opacity:.92;margin-top:2px}
      .n{all:initial;display:block;max-width:330px;margin-top:8px;padding:10px 14px;border-radius:16px;background:#fff;color:#2A1D14;
         font:13px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;box-shadow:0 10px 26px rgba(0,0,0,.18)}
    </style>
    ${n ? `<button class="b" ${enviando ? 'disabled' : ''}><img src="${logo}" alt=""><span>${enviando ? 'Enviando…' : `Enviar ${n} causa${n === 1 ? '' : 's'} a IusTrack`}<small>${NOMBRE[ORIGEN] || 'IusTrack'}</small></span></button>` : ''}
    ${nota ? `<div class="n">${nota}</div>` : ''}`;
    const b = raiz.querySelector('.b'); if (b) b.onclick = () => enviar(false);
  }
  async function enviar(solo) {
    const items = leerCausas(); if (!items.length || enviando) return;
    enviando = true; boton(items.length);
    const r = await pedir({ it: 'lista', origen: ORIGEN, items, url: location.href });
    enviando = false; ultimo = Date.now();
    boton(items.length, r && r.ok
      ? `<b>Listo:</b> ${items.length} causa${items.length === 1 ? '' : 's'} enviada${items.length === 1 ? '' : 's'} (en total ${r.total}). Volvé a IusTrack → Importar expedientes.<br>Si el listado tiene más páginas, pasá a la siguiente y volvé a tocar el botón.`
      : 'No se pudo enviar: revisá que la extensión esté activa en chrome://extensions.');
  }

  // ── Revisión de la página ─────────────────────────────────────────
  let corriendo = false;
  async function revisar() {
    if (corriendo) return; corriendo = true;
    try {
      if (ORIGEN === 'AFIP') {                 // ingreso con Clave Fiscal para la SRT: sólo el CUIT
        const p = await pedir({ it: 'pendiente', origen: 'SRT' });
        if (!p || !p.cuit) return;
        const u = document.querySelector('input[name$="username" i],input[id$="username" i],input[name*="cuit" i]');
        if (u && visible(u) && !u.value) { u.value = p.cuit; u.dispatchEvent(new Event('input', { bubbles: true })); u.dispatchEvent(new Event('change', { bubbles: true })); }
        boton(0, 'IusTrack: ingresá tu Clave Fiscal y entrá a la SRT. Después abrí tu listado de expedientes: se lee solo.');
        return;
      }
      const items = leerCausas();
      const p = await pedir({ it: 'pendiente', origen: ORIGEN });
      if (items.length) {
        if (p && Date.now() - ultimo > 15000) await enviar(true);
        else boton(items.length);
      } else {
        if (p && pideIngreso()) { await pedir({ it: 'login', origen: ORIGEN }); boton(0, 'IusTrack: entrá con tu usuario. Después abrí tu listado de expedientes: se lee solo.'); }
        else if (p && window.top === window) boton(0, 'IusTrack: abrí tu listado de expedientes (por ejemplo "Mis expedientes") y se lee solo.');
        else boton(0);
      }
    } finally { corriendo = false; }
  }
  let reloj = null;
  const pronto = () => { clearTimeout(reloj); reloj = setTimeout(revisar, 900); };
  new MutationObserver(m => { if (m.some(x => !host_ || !host_.contains(x.target))) pronto(); })
    .observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  revisar();

  // Para las pruebas automáticas (no hace nada en el uso normal)
  window.__itPortalesLeer = leerCausas;
})();
