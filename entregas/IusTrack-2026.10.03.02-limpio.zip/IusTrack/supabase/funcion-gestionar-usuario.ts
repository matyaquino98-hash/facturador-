// LexTrack — función "gestionar-usuario" (Supabase Edge Function)
// Crea usuarios y cambia contraseñas. Corre en el servidor de Supabase, que es
// el único lugar donde existe la clave privada (SUPABASE_SERVICE_ROLE_KEY).
// Sólo la puede usar el dueño del sistema o el administrador del estudio.
import { createClient } from 'npm:@supabase/supabase-js@2';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const resp = (cuerpo: unknown, status = 200) =>
  new Response(JSON.stringify(cuerpo), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    // La clave privada la pone Supabase en el servidor (nombre clásico o nuevo)
    const clavePrivada = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || Deno.env.get('SUPABASE_SECRET_KEY');
    if (!clavePrivada) return resp({ error: 'La función no tiene acceso a la clave del servidor.' }, 500);
    const admin = createClient(url, clavePrivada, { auth: { persistSession: false } });

    // ¿Quién llama?
    const token = (req.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
    const { data: quien, error: errQuien } = await admin.auth.getUser(token);
    if (errQuien || !quien?.user) return resp({ error: 'Sesión inválida. Volvé a ingresar.' }, 401);
    const yo = quien.user.id;

    const body = await req.json();
    const { accion, estudio_id } = body;
    if (!estudio_id) return resp({ error: 'Falta el estudio.' }, 400);

    // Permiso: dueño del sistema, o administrador activo de ese estudio (con el estudio activo)
    const { data: perfil } = await admin.from('perfiles').select('es_superadmin').eq('id', yo).maybeSingle();
    const { data: miembro } = await admin.from('miembros').select('rol, activo').eq('estudio_id', estudio_id).eq('usuario_id', yo).maybeSingle();
    const { data: estudio } = await admin.from('estudios').select('activo').eq('id', estudio_id).maybeSingle();
    if (!estudio) return resp({ error: 'El estudio no existe.' }, 404);
    const esDueno = !!perfil?.es_superadmin;
    const esAdmin = miembro?.rol === 'admin' && miembro?.activo && estudio.activo;
    if (!esDueno && !esAdmin) return resp({ error: 'No tenés permiso para administrar usuarios de este estudio.' }, 403);

    if (accion === 'crear') {
      const email = String(body.email || '').trim().toLowerCase();
      const password = String(body.password || '');
      const nombre = String(body.nombre || '').trim();
      const rol = ['admin', 'abogado', 'lectura'].includes(body.rol) ? body.rol : 'abogado';
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return resp({ error: 'El email no es válido.' }, 400);
      if (password.length < 8) return resp({ error: 'La contraseña debe tener al menos 8 caracteres.' }, 400);

      // Si el email ya tiene cuenta (por ejemplo, trabaja en dos estudios) se lo suma al estudio
      let usuarioId: string | null = null;
      const { data: existente } = await admin.from('perfiles').select('id').ilike('email', email).maybeSingle();
      if (existente) {
        usuarioId = existente.id;
      } else {
        const { data: creado, error } = await admin.auth.admin.createUser({
          email, password, email_confirm: true, user_metadata: { nombre },
        });
        if (error) return resp({ error: 'No se pudo crear el usuario: ' + error.message }, 400);
        usuarioId = creado.user.id;
        await admin.from('perfiles').upsert({ id: usuarioId, email, nombre });
      }
      const { error: errM } = await admin.from('miembros')
        .upsert({ estudio_id, usuario_id: usuarioId, rol, activo: true });
      if (errM) return resp({ error: 'No se pudo agregar al estudio: ' + errM.message }, 400);
      return resp({ ok: true, usuario_id: usuarioId, ya_existia: !!existente });
    }

    if (accion === 'cambiar_clave') {
      const usuarioId = String(body.usuario_id || '');
      const password = String(body.password || '');
      if (password.length < 8) return resp({ error: 'La contraseña debe tener al menos 8 caracteres.' }, 400);
      // Sólo usuarios de ese estudio (un admin no puede tocar cuentas de otros estudios)
      const { data: es } = await admin.from('miembros').select('usuario_id').eq('estudio_id', estudio_id).eq('usuario_id', usuarioId).maybeSingle();
      if (!es) return resp({ error: 'Ese usuario no pertenece al estudio.' }, 403);
      // El dueño del sistema sólo cambia su propia clave desde la cuenta de Supabase
      const { data: otro } = await admin.from('perfiles').select('es_superadmin').eq('id', usuarioId).maybeSingle();
      if (otro?.es_superadmin && usuarioId !== yo) return resp({ error: 'No se puede cambiar la contraseña del dueño del sistema.' }, 403);
      const { error } = await admin.auth.admin.updateUserById(usuarioId, { password });
      if (error) return resp({ error: 'No se pudo cambiar la contraseña: ' + error.message }, 400);
      return resp({ ok: true });
    }

    return resp({ error: 'Acción desconocida.' }, 400);
  } catch (e) {
    return resp({ error: 'Error inesperado: ' + (e instanceof Error ? e.message : String(e)) }, 500);
  }
});
