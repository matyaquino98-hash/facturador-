-- ════════════════════════════════════════════════════════════════════════
-- IusTrack (LexTrack) — 09: Fichero de clientes
-- Se puede correr más de una vez sin problema.
--
-- · Tabla clientes: una ficha por cliente (datos personales, laborales,
--   consulta y notas) con los expedientes del estudio vinculados.
-- · Tabla clientes_documentos: DNI, poder, recibos, telegramas, etc.
--   Los archivos van a la carpeta privada "adjuntos", en la ruta
--   <estudio>/clientes/<cliente>/<archivo>.
-- · Permisos: todo el estudio ve las fichas; admin y abogados cargan,
--   editan y borran (con la licencia vigente). Cada estudio sólo ve lo suyo.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.clientes (
  id              text primary key default gen_random_uuid()::text,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  nombre          text not null,                       -- apellido y nombre o razón social
  documento       text not null default '',            -- DNI
  cuit            text not null default '',            -- CUIT / CUIL
  estado          text not null default 'activo' check (estado in ('activo','consulta','ex')),
  datos           jsonb not null default '{}'::jsonb,  -- el resto de la ficha
  expedientes     text[] not null default '{}',        -- expedientes vinculados
  creado_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  creado_en       timestamptz not null default now(),
  actualizado_por uuid default auth.uid() references public.perfiles(id) on delete set null,
  actualizado_en  timestamptz not null default now()
);
create index if not exists ix_clientes_estudio on public.clientes(estudio_id);

create table if not exists public.clientes_documentos (
  id              text primary key default gen_random_uuid()::text,
  cliente_id      text not null references public.clientes(id) on delete cascade,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  categoria       text not null default 'Otros',
  nombre          text not null,
  tamanio         bigint not null default 0,
  tipo_mime       text not null default '',
  ruta            text not null,   -- ruta en Storage: estudio/clientes/cliente/archivo
  subido_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  subido_en       timestamptz not null default now()
);
create index if not exists ix_clientes_docs_cliente on public.clientes_documentos(cliente_id);

-- Un cliente no se puede pasar a otro estudio; se registra quién lo tocó
create or replace function public.tg_cliente_actualizado() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'UPDATE' and new.estudio_id <> old.estudio_id then
    raise exception 'No se puede mover un cliente a otro estudio';
  end if;
  new.actualizado_en := now();
  new.actualizado_por := coalesce(auth.uid(), new.actualizado_por);
  return new;
end $$;
drop trigger if exists tg_cliente_upd on public.clientes;
create trigger tg_cliente_upd before insert or update on public.clientes
  for each row execute function public.tg_cliente_actualizado();

-- El estudio de cada documento se toma siempre del cliente
create or replace function public.tg_estudio_desde_cliente() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select estudio_id into new.estudio_id from clientes where id = new.cliente_id;
  if new.estudio_id is null then raise exception 'Cliente inexistente'; end if;
  new.subido_por := coalesce(auth.uid(), new.subido_por);
  return new;
end $$;
drop trigger if exists tg_cli_doc_estudio on public.clientes_documentos;
create trigger tg_cli_doc_estudio before insert or update on public.clientes_documentos
  for each row execute function public.tg_estudio_desde_cliente();

alter table public.clientes            enable row level security;
alter table public.clientes_documentos enable row level security;
do $$ declare r record; begin
  for r in select policyname, tablename from pg_policies where schemaname = 'public'
           and tablename in ('clientes','clientes_documentos') loop
    execute format('drop policy %I on public.%I', r.policyname, r.tablename);
  end loop;
end $$;

create policy cli_ver    on public.clientes for select using (public.es_miembro(estudio_id));
create policy cli_crear  on public.clientes for insert with check (public.puede_cargar(estudio_id));
create policy cli_mod    on public.clientes for update using (public.puede_cargar(estudio_id)) with check (public.puede_cargar(estudio_id));
create policy cli_borrar on public.clientes for delete using (public.puede_cargar(estudio_id));

create policy cld_ver    on public.clientes_documentos for select using (public.es_miembro(estudio_id));
create policy cld_crear  on public.clientes_documentos for insert with check (public.puede_cargar(estudio_id));
create policy cld_borrar on public.clientes_documentos for delete using (public.puede_cargar(estudio_id));
-- (sin política de modificación: un documento se sube o se borra, no se edita)

-- Archivos en Storage: <estudio>/clientes/<cliente>/<archivo>
create or replace function public.ruta_cliente_valida(p_ruta text, p_editar boolean) returns boolean
language sql stable security definer set search_path = public as $$
  select split_part(p_ruta, '/', 2) = 'clientes' and exists (
    select 1 from clientes c
    where c.id = split_part(p_ruta, '/', 3)
      and c.estudio_id::text = split_part(p_ruta, '/', 1)
      and case when p_editar then public.puede_cargar(c.estudio_id)
               else public.es_miembro(c.estudio_id) end
  );
$$;

drop policy if exists adjuntos_clientes_ver    on storage.objects;
drop policy if exists adjuntos_clientes_subir  on storage.objects;
drop policy if exists adjuntos_clientes_borrar on storage.objects;
create policy adjuntos_clientes_ver    on storage.objects for select to authenticated
  using (bucket_id = 'adjuntos' and public.ruta_cliente_valida(name, false));
create policy adjuntos_clientes_subir  on storage.objects for insert to authenticated
  with check (bucket_id = 'adjuntos' and public.ruta_cliente_valida(name, true));
create policy adjuntos_clientes_borrar on storage.objects for delete to authenticated
  using (bucket_id = 'adjuntos' and public.ruta_cliente_valida(name, true));

revoke all on public.clientes, public.clientes_documentos from anon;
