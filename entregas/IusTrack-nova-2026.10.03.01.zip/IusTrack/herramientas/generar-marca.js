/* IusTrack — genera los íconos de la app instalable y las pantallas de arranque
   a partir del logo (marca/isotipo.svg). Deja todo en marca/app/: armar-actualizacion.js
   lo copia a la carpeta "publicar" y a iustrack-app.zip.
   Uso (una vez, sólo si cambia el logo):  npm i -g playwright  y luego
           node herramientas/generar-marca.js */
const fs = require('fs'), path = require('path');
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { console.error('Falta Playwright: npm i -g playwright (y npx playwright install chromium)'); process.exit(1); }
const RAIZ = path.resolve(__dirname, '..'), M = path.join(RAIZ, 'marca'), SAL = path.join(M, 'app');
fs.mkdirSync(SAL, { recursive: true });
const iso = fs.readFileSync(path.join(M, 'isotipo.svg'), 'utf8');
// Versión "a sangre" (sin esquinas redondeadas): para iOS y Android, que recortan solos
const sangre = escala => iso.replace(/rx="19"/g, 'rx="0"').replace(/<rect x="3\.5"[^>]*\/>/, '')
  .replace(/(<g fill="none")/, `<g transform="translate(32 33) scale(${escala}) translate(-32 -33)">$1`).replace(/(<circle cx="32"[^>]*\/>)/, '$1</g>');
// Tipografías: locales (marca/fuentes) si están; si no, Google Fonts
const fuentes = fs.existsSync(path.join(M, 'fuentes', 'fuentes.css'))
  ? `<style>${fs.readFileSync(path.join(M, 'fuentes', 'fuentes.css'), 'utf8').replace(/url\(([^)]+\.woff2)\)/g, (m, f) => `url(data:font/woff2;base64,${fs.readFileSync(path.join(M, 'fuentes', f)).toString('base64')})`)}</style>`
  : `<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500..800&family=Geist:wght@400..600&display=swap" rel="stylesheet">`;
const ARRANQUES = [[1125, 2436], [1170, 2532], [1179, 2556], [1284, 2778], [1290, 2796], [750, 1334]];
(async () => {
  const b = await chromium.launch();
  async function png(html, w, h, archivo, transparente) {
    const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
    await p.setContent(`<!doctype html><html><head>${fuentes}<style>html,body{margin:0;width:${w}px;height:${h}px;overflow:hidden;background:${transparente ? 'transparent' : '#FDF7F0'}}svg{display:block}</style></head><body>${html}</body></html>`);
    await p.evaluate(() => document.fonts.ready);
    await p.waitForTimeout(150);
    await p.screenshot({ path: path.join(SAL, archivo), omitBackground: !!transparente });
    await p.close();
    console.log('  ' + archivo);
  }
  const svgEn = (s, lado) => s.replace('<svg ', `<svg width="${lado}" height="${lado}" `);
  for (const l of [192, 512]) await png(`<div style="padding:${l * 0.04}px">${svgEn(iso, l * 0.92)}</div>`, l, l, `icono-${l}.png`, true);
  await png(svgEn(sangre(0.78), 512), 512, 512, 'icono-maskable-512.png');
  for (const l of [120, 152, 167, 180]) await png(svgEn(sangre(0.9), l), l, l, `apple-icono-${l}.png`);
  await png(svgEn(iso, 64), 64, 64, 'favicon-64.png', true);
  fs.copyFileSync(path.join(M, 'isotipo.svg'), path.join(SAL, 'favicon.svg'));
  for (const [w, h] of ARRANQUES) {
    const k = w / 1170;
    await png(`<div style="width:${w}px;height:${h}px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:${44 * k}px;
        background:radial-gradient(${900 * k}px ${700 * k}px at 85% 0%,rgba(255,140,40,.32),transparent 65%),radial-gradient(${800 * k}px ${600 * k}px at 0% 100%,rgba(226,69,12,.16),transparent 60%),#FDF7F0">
        <div style="filter:drop-shadow(0 ${40 * k}px ${60 * k}px rgba(226,69,12,.35))">${svgEn(iso, 380 * k)}</div>
        <div style="font-family:'Bricolage Grotesque',sans-serif;font-weight:800;font-size:${150 * k}px;letter-spacing:${-4 * k}px;color:#22150C;line-height:1">Ius<span style="background:linear-gradient(90deg,#FFA23A,#FF6A13 55%,#E2450C);-webkit-background-clip:text;color:transparent">Track</span></div>
        <div style="font-family:'Geist',sans-serif;font-size:${46 * k}px;color:#8B7460;margin-top:${-20 * k}px">Gestión judicial</div></div>`, w, h, `arranque-${w}x${h}.png`);
  }
  await b.close();
  console.log('Listo: marca/app');
})().catch(e => { console.error(e); process.exit(1); });
