/* IusTrack — SRT y EJE: lector del listado de causas.
   Corre en las páginas de la SRT, del EJE de CABA y en el ingreso con Clave Fiscal.
   · Busca en la página las tablas de expedientes (tabla común o grilla), reconoce las
     columnas por su título (N° de expediente, carátula, motivo, damnificado, fecha de
     inicio, organismo, estado) y muestra el botón "Enviar a IusTrack".
   · Si IusTrack pidió "Leer mis causas", las manda solas apenas aparece el listado.
   · Si IusTrack pidió leer y el usuario guardó su CUIT y clave en IusTrack (sólo en su
     computadora), entra solo: completa usuario y clave y toca "Ingresar" (también en el
     ingreso con Clave Fiscal, que tiene dos pasos). La clave se prueba una sola vez: si no
     anda, para y avisa, para no bloquear la cuenta. */
(() => {
  if (window.__itPortales) return; window.__itPortales = true;
  const host = location.hostname;
  const ORIGEN = /(^|\.)srt\.gob\.ar$/.test(host) ? 'SRT' : /(^|\.)(juscaba\.gob\.ar|jusbaires\.gob\.ar)$|^eje\.jus\.gov\.ar$/.test(host) ? 'EJE' : /(^|\.)afip\.gob\.ar$/.test(host) ? 'AFIP' : '';
  if (!ORIGEN) return;
  const NOMBRE = { SRT: 'SRT · Comisiones Médicas', EJE: 'EJE · Justicia CABA' };
  const pedir = m => new Promise(r => { try { chrome.runtime.sendMessage(m, x => r(chrome.runtime.lastError ? null : x)); } catch (e) { r(null); } });
  const limpio = t => String(t || '').replace(/\s+/g, ' ').trim();
  const llano = t => limpio(t).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[°º.:#]/g, ' ').replace(/\s+/g, ' ').trim();

  // ── Qué es cada columna, por su título ─────────────────────────────
  function tipoCol(t) {
    const s = llano(t);
    if (!s || s.length > 60) return '';
    if (/caratula|autos/.test(s)) return 'caratula';
    if (/damnificad|trabajador|requirente|solicitante|^actor/.test(s)) return 'damnificado';
    if (/motivo|tramite|objeto|materia|tipo de (expediente|proceso|causa)/.test(s)) return 'motivo';
    if (/comision|juzgado|organismo|dependencia|radicac|tribunal|sede|fuero|secretaria|sala/.test(s)) return 'juzgado';
    if (/estado|situacion|etapa/.test(s)) return 'estado';
    if (/inicio|fecha|ingreso|alta|creacion|presentacion/.test(s)) return 'inicio';
    if (/expediente|expte|numero|^n( |$)|^nro|^num|causa|cuij|identificador/.test(s)) return 'numero';
    return '';
  }
  const visible = el => !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length));
  const texto = el => limpio(el.innerText != null ? el.innerText : el.textContent);
  function tablas() {
    const res = [];
    document.querySelectorAll('table').forEach(t => {
      if (!visible(t)) return;
      const filas = [...t.rows]; if (filas.length < 2) return;
      const cab = t.tHead && t.tHead.rows.length ? t.tHead.rows[t.tHead.rows.length - 1] : (filas.find(r => r.querySelector('th')) || filas[0]);
      res.push({ heads: [...cab.cells].map(texto), filas: filas.filter(r => r !== cab && !(t.tHead && t.tHead.contains(r))).map(r => ({ el: r, celdas: [...r.cells].map(texto) })) });
    });
    // Grillas armadas con roles (Angular Material y similares)
    document.querySelectorAll('[role="table"],[role="grid"],[role="treegrid"]').forEach(g => {
      if (g.tagName === 'TABLE' || !visible(g)) return;
      const rows = [...g.querySelectorAll('[role="row"]')];
      const celdas = r => [...r.querySelectorAll('[role="columnheader"],[role="cell"],[role="gridcell"],[role="rowheader"]')];
      const cab = rows.find(r => r.querySelector('[role="columnheader"]')); if (!cab) return;
      res.push({ heads: celdas(cab).map(texto), filas: rows.filter(r => !r.querySelector('[role="columnheader"]')).map(r => ({ el: r, celdas: celdas(r).map(texto) })) });
    });
    return res;
  }
  // Respaldo cuando el portal no muestra una tabla (tarjetas, renglones, grillas armadas con
  // divs): se buscan los números de expediente en el texto y cada causa es el texto que va
  // desde su número hasta el número siguiente.
  function causasPorTexto(texto, origen) {
    const t = String(texto || '').replace(/\r/g, '').replace(/[  ]+/g, ' ');
    const RE_NUM = origen === 'SRT'
      ? /(?:^|[^\d\/])(\d{4,7}\/(?:\d{4}|\d{2}))(?![\d\/])/g
      : /(?:^|[^\w\/-])((?:EXP(?:TE)?\.?\s*)?(?:[A-Z]{1,3}-\d{2}-\d{8}-\d\/\d{4}-\d|\d{1,7}\/\d{4}(?:-\d{1,2})?))(?![\d\/])/gi;
    const marcas = []; let m;
    while ((m = RE_NUM.exec(t))) marcas.push({ num: m[1].trim(), desde: m.index + m[0].indexOf(m[1]) });
    const items = [], vistos = new Set(), lineas = s => s.split(/\n|\t| {3,}/).map(x => x.trim()).filter(Boolean);
    marcas.forEach((x, i) => {
      const k = x.num.toUpperCase().replace(/\s+/g, ''); if (vistos.has(k)) return;
      const trozo = t.slice(x.desde + x.num.length, i + 1 < marcas.length ? marcas[i + 1].desde : x.desde + 700).slice(0, 700);
      const ls = lineas(trozo);
      const it = { numero: x.num, caratula: '', motivo: '', damnificado: '', juzgado: '', inicio: '', estado: '', link: '' };
      const f = trozo.match(/\b\d{1,2}\/\d{1,2}\/\d{4}\b/); if (f) it.inicio = f[0];
      if (origen === 'SRT') {
        const d = trozo.match(/\b(\d{2}-?\d{8}-?\d)\s*[-–]\s*([A-ZÁÉÍÓÚÜÑ][A-ZÁÉÍÓÚÜÑ' .]{3,80}?)(?=\s*(?:\n|\t| {2,}|$|\d))/);
        if (d) it.damnificado = d[1] + ' - ' + d[2].trim();
        it.motivo = (ls.find(l => /[A-ZÁÉÍÓÚÑ]{4,}/.test(l) && !/\d{8}/.test(l) && !/^\d/.test(l) && l.length > 6) || '').slice(0, 200);
        if (!it.damnificado && !/INCAPACIDAD|DIVERGENCIA|RECHAZO|CONTINGENCIA|ALTA M[ÉE]DICA|PRESTACI|REINGRESO|HOMOLOG|ACUERDO|SILENCIO|ABANDONO|CESE|ENFERMEDAD|ACCIDENTE|REVISI[ÓO]N|RECALIFICA/i.test(it.motivo)) return;
      } else {
        it.caratula = (ls.find(l => /\b[CS]\s?\/\s?\S/i.test(l) && l.length > 8) || '').slice(0, 400);
        it.juzgado = (ls.find(l => /juzgado|tribunal|c[áa]mara|sala\b|secretar/i.test(l)) || '').slice(0, 200);
        it.estado = (ls.find(l => /tr[áa]mite|despacho|archiv|paralizad|sentencia/i.test(l) && l.length < 60) || '');
        if (!it.caratula) return;
      }
      vistos.add(k); items.push(it);
    });
    return items;
  }
  function leerCausas() {
    const items = [], vistos = new Set();
    tablas().forEach(t => {
      const tipos = t.heads.map(tipoCol);
      if (tipos.indexOf('numero') < 0 || tipos.filter(Boolean).length < 2) return;
      t.filas.forEach(f => {
        const v = k => { const i = tipos.indexOf(k); return i >= 0 ? (f.celdas[i] || '') : ''; };
        const numero = v('numero');
        if (!numero || !/\d/.test(numero) || numero.length > 60) return;
        const k = numero.toUpperCase().replace(/\s+/g, ''); if (vistos.has(k)) return; vistos.add(k);
        const a = f.el.querySelector('a[href]:not([href^="javascript"]):not([href="#"])');
        items.push({ numero, caratula: v('caratula'), motivo: v('motivo'), damnificado: v('damnificado'), juzgado: v('juzgado'),
          inicio: v('inicio'), estado: v('estado'), link: a && /^https:/.test(a.href) ? a.href : '' });
      });
    });
    if (items.length || ORIGEN === 'AFIP' || !document.body) return items;
    // Sin tabla (tarjetas o renglones): por los números de expediente del texto
    const porTexto = causasPorTexto(document.body.innerText, ORIGEN);
    const enlaces = [...document.querySelectorAll('a[href^="https:"]')];
    porTexto.forEach(it => { const a = enlaces.find(x => (x.innerText || '').includes(it.numero.replace(/^EXP(TE)?\.?\s*/i, ''))); if (a) it.link = a.href; });
    return porTexto;
  }
  const pideIngreso = () => [...document.querySelectorAll('input[type="password"]')].some(visible) || !!campoUsuario();

  // ── Ingreso automático con el usuario guardado en IusTrack ─────────
  const etiqueta = i => [i.name, i.id, i.placeholder, i.getAttribute('aria-label'), i.getAttribute('autocomplete')].join(' ');
  function campoUsuario() {
    return [...document.querySelectorAll('input:not([type]),input[type="text"],input[type="email"],input[type="tel"],input[type="number"]')]
      .find(i => visible(i) && !i.disabled && !i.readOnly && /user|usuario|cuit|cuil|login|email|documento|dni/i.test(etiqueta(i)));
  }
  function escribir(i, v) {
    const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    i.focus(); set.call(i, v);
    ['input', 'change', 'keyup'].forEach(t => i.dispatchEvent(new Event(t, { bubbles: true })));
  }
  function botonIngresar(form) {
    const raiz = form || document;
    const lista = [...raiz.querySelectorAll('button,input[type="submit"],input[type="button"],a[role="button"]')].filter(visible);
    return lista.find(b => b.type === 'submit') || lista.find(b => /ingres|siguiente|iniciar|entrar|acceder|login|continuar/i.test((b.innerText || b.value || '') + ' ' + (b.id || '')));
  }
  // Intentos por paso (usuario / clave), guardados en la pestaña
  function intentar(paso) {
    const k = 'iustrack-intentos-' + paso; let v = { n: 0, t: 0 };
    try { v = JSON.parse(sessionStorage.getItem(k) || '{"n":0,"t":0}'); } catch (e) {}
    if (Date.now() - v.t > 3 * 60 * 1000) v = { n: 0, t: Date.now() };
    if (v.n >= (paso === 'clave' ? 1 : 2)) return false;      // la clave, una sola vez: repetir una clave mala puede bloquear la cuenta
    v.n++; try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
    return true;
  }
  function ingresar(p) {
    const clave = [...document.querySelectorAll('input[type="password"]')].find(i => visible(i) && !i.disabled);
    const usuario = campoUsuario();
    if (!clave && !usuario) return 'no';
    if (clave && !p.clave) return 'sinclave';
    if (!intentar(clave ? 'clave' : 'usuario')) return 'agotado';
    if (usuario && p.usuario && usuario.value !== p.usuario) escribir(usuario, p.usuario);
    if (clave) escribir(clave, p.clave);
    const form = (clave || usuario).form, b = botonIngresar(form);
    setTimeout(() => { if (b) b.click(); else if (form) { if (form.requestSubmit) form.requestSubmit(); else form.submit(); } }, 350);
    return 'ok';
  }

  // ── Botón flotante (con el estilo de IusTrack) ─────────────────────
  let host_, raiz, ultimo = 0, enviando = false;
  function boton(n, nota) {
    if (window.top !== window && !n) return;
    if (!host_) {
      host_ = document.createElement('div'); host_.id = 'iustrack-portales';
      host_.style.cssText = 'position:fixed;right:22px;bottom:22px;z-index:2147483646';
      raiz = host_.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host_);
    }
    if (!n && !nota) { host_.style.display = 'none'; return; }
    host_.style.display = '';
    const logo = chrome.runtime.getURL('icono.png');
    raiz.innerHTML = `<style>
      .b{all:initial;display:flex;align-items:center;gap:12px;padding:10px 18px 10px 10px;border-radius:999px;cursor:pointer;
         font:600 15px/1.25 system-ui,-apple-system,"Segoe UI",sans-serif;color:#fff;background:linear-gradient(135deg,#FF9A3C,#E2450C);
         box-shadow:0 14px 34px rgba(160,60,10,.35),0 2px 6px rgba(0,0,0,.18);transition:transform .2s cubic-bezier(.3,1.4,.5,1)}
      .b:hover{transform:translateY(-2px) scale(1.02)}.b[disabled]{opacity:.7;cursor:default}
      img{width:40px;height:40px;border-radius:12px;background:#fff;display:block}
      small{display:block;font-weight:500;font-size:12px;opacity:.92;margin-top:2px}
      .n{all:initial;display:block;max-width:330px;margin-top:8px;padding:10px 14px;border-radius:16px;background:#fff;color:#2A1D14;
         font:13px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;box-shadow:0 10px 26px rgba(0,0,0,.18)}
    </style>
    ${n ? `<button class="b" ${enviando ? 'disabled' : ''}><img src="${logo}" alt=""><span>${enviando ? 'Enviando…' : `Enviar ${n} causa${n === 1 ? '' : 's'} a IusTrack`}<small>${NOMBRE[ORIGEN] || 'IusTrack'}</small></span></button>` : ''}
    ${nota ? `<div class="n">${nota}</div>` : ''}`;
    const b = raiz.querySelector('.b'); if (b) b.onclick = () => enviar(false);
  }
  async function enviar(solo) {
    const items = leerCausas(); if (!items.length || enviando) return;
    enviando = true; boton(items.length);
    const r = await pedir({ it: 'lista', origen: ORIGEN, items, url: location.href });
    enviando = false; ultimo = Date.now();
    boton(items.length, r && r.ok
      ? `<b>Listo:</b> ${items.length} causa${items.length === 1 ? '' : 's'} enviada${items.length === 1 ? '' : 's'} (en total ${r.total}). Volvé a IusTrack → Importar expedientes.<br>Si el listado tiene más páginas, pasá a la siguiente y volvé a tocar el botón.`
      : 'No se pudo enviar: revisá que la extensión esté activa en chrome://extensions.');
  }

  // ── Revisión de la página ─────────────────────────────────────────
  let corriendo = false;
  async function revisar() {
    if (corriendo) return; corriendo = true;
    try {
      if (ORIGEN === 'AFIP') {                 // ingreso con Clave Fiscal para la SRT (dos pasos: CUIT y clave)
        const p = await pedir({ it: 'pendiente', origen: 'SRT' });
        if (!p) return;
        const r = p.esta && p.usuario ? ingresar(p) : 'sinclave';
        if (r === 'ok') { boton(0, 'IusTrack: entrando con tu CUIT…'); return; }
        if (r === 'agotado') { await pedir({ it: 'login', origen: 'SRT' }); boton(0, 'IusTrack: no se pudo entrar con la clave guardada. Revisala en IusTrack → Integraciones, o entrá vos.'); return; }
        const u = campoUsuario();
        if (u && p.cuit && !u.value) escribir(u, p.cuit);
        boton(0, 'IusTrack: ingresá tu Clave Fiscal y entrá a la SRT. Después abrí tu listado de expedientes: se lee solo.');
        return;
      }
      const items = leerCausas();
      const p = await pedir({ it: 'pendiente', origen: ORIGEN });
      if (items.length) {
        if (p && Date.now() - ultimo > 15000) await enviar(true);
        else boton(items.length);
      } else {
        if (p && pideIngreso()) {
          const r = p.esta && p.usuario ? ingresar(p) : 'sinclave';
          if (r === 'ok') { boton(0, 'IusTrack: entrando con tu usuario…'); return; }
          await pedir({ it: 'login', origen: ORIGEN });
          boton(0, r === 'agotado' ? 'IusTrack: no se pudo entrar con la clave guardada. Revisala en IusTrack → Integraciones, o entrá vos.'
            : 'IusTrack: entrá con tu usuario. Después abrí tu listado de expedientes: se lee solo.');
        }
        else if (p && window.top === window) boton(0, 'IusTrack: abrí tu listado de expedientes (por ejemplo "Mis expedientes") y se lee solo.');
        else boton(0);
      }
    } finally { corriendo = false; }
  }
  let reloj = null;
  const pronto = () => { clearTimeout(reloj); reloj = setTimeout(revisar, 900); };
  new MutationObserver(m => { if (m.some(x => !host_ || !host_.contains(x.target))) pronto(); })
    .observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  revisar();

  // Para las pruebas automáticas (no hace nada en el uso normal)
  window.__itPortalesLeer = leerCausas;
})();
