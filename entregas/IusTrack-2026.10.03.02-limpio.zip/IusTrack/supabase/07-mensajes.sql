-- ════════════════════════════════════════════════════════════════════════
-- LexTrack — 07: mensajes directos entre usuarios del mismo estudio
-- Se puede correr más de una vez sin problema.
--
-- · Cada usuario ve sólo los mensajes que mandó o recibió (ni el administrador
--   ni el dueño del sistema leen conversaciones ajenas).
-- · Se manda sólo a compañeros activos del mismo estudio.
-- · El destinatario sólo puede marcarlo como leído; el texto no se edita.
-- · Quien lo mandó puede borrarlo.
-- · Archivos adjuntos (PDF, fotos, Word, Excel…, hasta 25 MB) en la carpeta
--   privada "mensajes": sólo los abren quien lo mandó y quien lo recibió.
-- · Avisos al instante (Supabase Realtime).
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.mensajes (
  id              uuid primary key default gen_random_uuid(),
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  de_usuario      uuid not null default auth.uid() references public.perfiles(id) on delete cascade,
  para_usuario    uuid not null references public.perfiles(id) on delete cascade,
  texto           text not null default '',
  adjunto_ruta    text,            -- <estudio>/<remitente>/<archivo> en la carpeta "mensajes"
  adjunto_nombre  text,
  adjunto_tipo    text,
  adjunto_tamanio bigint,
  creado_en       timestamptz not null default now(),
  leido_en        timestamptz
);
-- Por si la tabla ya existía sin adjuntos
alter table public.mensajes add column if not exists adjunto_ruta text;
alter table public.mensajes add column if not exists adjunto_nombre text;
alter table public.mensajes add column if not exists adjunto_tipo text;
alter table public.mensajes add column if not exists adjunto_tamanio bigint;
alter table public.mensajes alter column texto set default '';
alter table public.mensajes drop constraint if exists mensajes_texto_check;
alter table public.mensajes drop constraint if exists mensajes_contenido;
alter table public.mensajes add constraint mensajes_contenido
  check (char_length(texto) <= 4000 and (char_length(texto) >= 1 or adjunto_ruta is not null));
create index if not exists ix_mensajes_para    on public.mensajes(para_usuario, leido_en);
create index if not exists ix_mensajes_estudio on public.mensajes(estudio_id, creado_en);

-- Al crear: el remitente es siempre quien está conectado, el destinatario tiene que ser del estudio
-- y el adjunto tiene que estar en la carpeta del remitente dentro del estudio.
-- Al modificar: sólo cambia "leído".
create or replace function public.tg_mensaje() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.de_usuario := coalesce(auth.uid(), new.de_usuario);
    new.creado_en := now();
    new.leido_en := null;
    if new.para_usuario = new.de_usuario then raise exception 'No podés mandarte un mensaje a vos mismo'; end if;
    if not exists (select 1 from miembros where estudio_id = new.estudio_id and usuario_id = new.para_usuario and activo) then
      raise exception 'El destinatario no pertenece al estudio';
    end if;
    if new.adjunto_ruta is not null and (split_part(new.adjunto_ruta, '/', 1) <> new.estudio_id::text
                                         or split_part(new.adjunto_ruta, '/', 2) <> new.de_usuario::text) then
      raise exception 'El archivo adjunto no es válido';
    end if;
  else
    new.id := old.id; new.estudio_id := old.estudio_id; new.de_usuario := old.de_usuario;
    new.para_usuario := old.para_usuario; new.texto := old.texto; new.creado_en := old.creado_en;
    new.adjunto_ruta := old.adjunto_ruta; new.adjunto_nombre := old.adjunto_nombre;
    new.adjunto_tipo := old.adjunto_tipo; new.adjunto_tamanio := old.adjunto_tamanio;
  end if;
  return new;
end $$;
drop trigger if exists tg_mensaje on public.mensajes;
create trigger tg_mensaje before insert or update on public.mensajes
  for each row execute function public.tg_mensaje();

alter table public.mensajes enable row level security;
drop policy if exists msj_ver    on public.mensajes;
drop policy if exists msj_mandar on public.mensajes;
drop policy if exists msj_leer   on public.mensajes;
drop policy if exists msj_borrar on public.mensajes;
create policy msj_ver    on public.mensajes for select
  using (public.es_miembro(estudio_id) and (de_usuario = auth.uid() or para_usuario = auth.uid()));
create policy msj_mandar on public.mensajes for insert
  with check (public.es_miembro(estudio_id) and de_usuario = auth.uid());
create policy msj_leer   on public.mensajes for update
  using (para_usuario = auth.uid()) with check (para_usuario = auth.uid());
create policy msj_borrar on public.mensajes for delete
  using (de_usuario = auth.uid());

revoke all on public.mensajes from anon;

-- ── Archivos adjuntos: carpeta privada "mensajes" ────────────────────────
insert into storage.buckets (id, name, public, file_size_limit)
values ('mensajes', 'mensajes', false, 26214400)
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit;

-- Subir: sólo a la propia carpeta (<estudio>/<yo>/…) de un estudio del que soy miembro activo
create or replace function public.msj_puede_subir(p_ruta text) returns boolean
language sql stable security definer set search_path = public as $$
  select split_part(p_ruta, '/', 2) = auth.uid()::text
     and exists (select 1 from miembros m join estudios e on e.id = m.estudio_id
                 where m.estudio_id::text = split_part(p_ruta, '/', 1) and m.usuario_id = auth.uid() and m.activo and e.activo);
$$;
-- Ver: sólo si el archivo está en un mensaje que mandé o recibí
create or replace function public.msj_adjunto_visible(p_ruta text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from mensajes m where m.adjunto_ruta = p_ruta
                 and (m.de_usuario = auth.uid() or m.para_usuario = auth.uid()) and public.es_miembro(m.estudio_id));
$$;
drop policy if exists msj_adj_ver    on storage.objects;
drop policy if exists msj_adj_subir  on storage.objects;
drop policy if exists msj_adj_borrar on storage.objects;
create policy msj_adj_ver    on storage.objects for select to authenticated
  using (bucket_id = 'mensajes' and public.msj_adjunto_visible(name));
create policy msj_adj_subir  on storage.objects for insert to authenticated
  with check (bucket_id = 'mensajes' and public.msj_puede_subir(name));
create policy msj_adj_borrar on storage.objects for delete to authenticated
  using (bucket_id = 'mensajes' and split_part(name, '/', 2) = auth.uid()::text);

-- Avisos al instante
do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'mensajes') then
    alter publication supabase_realtime add table public.mensajes;
  end if;
end $$;
