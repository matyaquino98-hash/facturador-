/* ════════════════════════════════════════════════════════════════════════
   IusTrack — CARGADOR DE ACTUALIZACIONES
   Las mejoras de IusTrack (procuración, descargas, etc.) viven en un bloque que se
   puede reemplazar sin tocar este archivo: viene uno dentro del archivo (abajo,
   <script id="it-bloque" type="text/plain">) y puede haber uno más nuevo en la nube
   (tabla actualizaciones, script 11-actualizaciones.sql). Se corre el más nuevo.
   · El dueño del sistema sube el archivo .iustrack con "🔄 Actualizar" y les llega a
     todos los usuarios de todos los estudios al abrir IusTrack.
   · Si una versión de la nube falla al arrancar, se vuelve sola a la del archivo.
   Este cargador no se actualiza desde la nube: es la red de seguridad.
   ════════════════════════════════════════════════════════════════════════ */
(function () {
  const CLAVE = 'iustrack-actualizacion', FALLO = 'iustrack-actualizacion-fallo';
  const emb = document.getElementById('it-bloque');
  const archivo = { version: emb.dataset.version, notas: emb.dataset.notas || '', codigo: emb.textContent, origen: 'archivo' };
  const leer = k => { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } };
  const escribir = (k, v) => { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

  // ── Qué versión se corre ──────────────────────────────────────────────
  let usar = archivo;
  const nube = leer(CLAVE);
  if (nube && nube.codigo && nube.version > archivo.version && leer(FALLO) !== nube.version) {
    try { new Function(nube.codigo); usar = Object.assign({}, nube, { origen: nube.origen || 'nube' }); }
    catch (e) { console.warn('IusTrack: la actualización guardada está dañada; se usa la del archivo.', e); escribir(CLAVE, null); }
  }
  window.IUSTRACK = { version: usar.version, origen: usar.origen, archivo: archivo.version };
  window.__itBloqueOk = false;
  const s = document.createElement('script');
  s.textContent = usar.codigo + '\n;window.__itBloqueOk = true;';
  document.currentScript.after(s);                       // corre en el acto, en el ámbito global
  if (!window.__itBloqueOk && usar !== archivo) {
    // Falló al arrancar: se marca y se recarga con la versión del archivo
    escribir(FALLO, usar.version);
    location.reload();
    return;
  }

  // ── Buscar e instalar actualizaciones de la nube ──────────────────────
  const listo = () => typeof sb !== 'undefined' && typeof NUBE !== 'undefined' && NUBE.user;
  async function huella(txt) {
    if (!(window.crypto && crypto.subtle)) return '';
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(txt));
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
  }
  async function versiones() {
    const { data, error } = await sb.from('actualizaciones').select('version, notas, subido_en, huella').order('version', { ascending: false }).limit(15);
    if (error) throw error;
    return data || [];
  }
  // Baja el código de una versión, lo verifica y lo deja listo para la próxima vez que se abra
  async function instalar(version) {
    const { data, error } = await sb.from('actualizaciones').select('version, notas, codigo, huella').eq('version', version).single();
    if (error) throw error;
    const h = await huella(data.codigo);
    if (h && h !== data.huella) throw new Error('el código bajado no coincide con su huella');
    new Function(data.codigo);                                 // que compile
    escribir(CLAVE, { version: data.version, notas: data.notas, codigo: data.codigo });
    escribir(FALLO, null);
    return data;
  }
  let pendiente = null;   // versión nueva ya bajada, que se aplica al recargar
  function barra(v) {
    if (document.getElementById('it-act-barra')) return;
    const d = document.createElement('div');
    d.id = 'it-act-barra';
    d.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:16px;z-index:9000;background:#2A1D14;color:#fff;border-radius:12px;' +
      'padding:10px 14px;font:13px/1.4 inherit;display:flex;gap:12px;align-items:center;box-shadow:0 10px 30px rgba(0,0,0,.25)';
    d.innerHTML = `<span>🔄 Hay una versión nueva de IusTrack (${v}).</span>
      <button style="border:none;border-radius:8px;padding:6px 12px;font-weight:700;cursor:pointer;background:#F0912E;color:#fff" onclick="location.reload()">Actualizar ahora</button>
      <button style="border:none;background:none;color:#ccc;cursor:pointer;font-size:16px" title="Más tarde" onclick="this.parentElement.remove()">✕</button>`;
    document.body.appendChild(d);
    const b = document.getElementById('it-act-cnt'); if (b) b.style.display = '';
  }
  async function revisar(avisar) {
    if (!listo()) return null;
    const vs = await versiones();
    const ult = vs[0];
    if (ult && ult.version > window.IUSTRACK.version && ult.version !== leer(FALLO)) {
      if (pendiente !== ult.version) { await instalar(ult.version); pendiente = ult.version; }
      barra(ult.version);
    } else if (avisar) showToast('IusTrack está actualizado (versión ' + window.IUSTRACK.version + ')');
    return vs;
  }
  // Al entrar y cada 30 minutos
  (function esperar(n) {
    if (listo()) { revisar(false).catch(e => console.warn('IusTrack: no se pudieron revisar las actualizaciones', e)); setInterval(() => revisar(false).catch(() => {}), 30 * 60 * 1000); return; }
    if (n < 600) setTimeout(() => esperar(n + 1), 3000);
  })(0);

  // ── Botón "🔄 Actualizar" y su ventana ────────────────────────────────
  const fecha = v => { const m = String(v || '').match(/^(\d{4})\.(\d{2})\.(\d{2})\.(\d{2})$/); return m ? `${m[3]}/${m[2]}/${m[1]}${m[4] !== '01' ? ' (' + (+m[4]) + ')' : ''}` : v; };
  const e = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function boton() {
    if (document.getElementById('it-act-boton')) return;
    const ref = document.getElementById('sync-chip');
    const nav = document.querySelector('.sidebar-nav');
    if (!nav) return;
    const b = document.createElement('button');
    b.id = 'it-act-boton'; b.className = 'nav-btn'; b.title = 'Versión de IusTrack y actualizaciones';
    b.innerHTML = '<span class="nav-icon">🔄</span> Actualizar<span class="nav-count" id="it-act-cnt" style="display:none;background:#F0912E;color:#fff">nueva</span>';
    b.onclick = () => window.itActualizaciones();
    if (ref) ref.before(b); else nav.appendChild(b);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boton); else boton();

  // Lee y verifica un archivo .iustrack elegido con el explorador
  async function leerArchivo(f) {
    const a = JSON.parse(await f.text());
    if (a.formato !== 'iustrack-actualizacion' || !/^\d{4}\.\d{2}\.\d{2}\.\d{2}$/.test(a.version) || !a.codigo) throw new Error('no es un archivo de actualización de IusTrack');
    const h = await huella(a.codigo);
    if (h && a.huella && h !== a.huella) throw new Error('el archivo está dañado (la huella no coincide)');
    try { new Function(a.codigo); } catch (err) { throw new Error('el código tiene un error: ' + err.message); }
    a.huella = a.huella || h;
    return a;
  }

  window.itActualizaciones = async function () {
    const dueno = typeof NUBE !== 'undefined' && NUBE.perfil && NUBE.perfil.es_superadmin;
    let vs = null, aviso = null;
    const pintar = () => {
      const ult = vs && vs[0];
      const masNueva = ult && ult.version > window.IUSTRACK.version;
      modModal(`
      <h2 style="font-family:'Bricolage Grotesque',sans-serif;font-size:19px;color:#2A1D14;margin-bottom:8px">🔄 Actualizaciones de IusTrack</h2>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12.5px">
        <div style="background:#FDF7F0;border:1px solid #ECDCC9;border-radius:9px;padding:9px 11px"><div style="color:#8B7460;font-size:11px;text-transform:uppercase;letter-spacing:.04em">En uso</div>
          <b style="font-size:15px">${e(window.IUSTRACK.version)}</b><div style="color:#8B7460">${fecha(window.IUSTRACK.version)} · ${window.IUSTRACK.origen === 'nube' ? 'bajada de la nube' : window.IUSTRACK.origen === 'archivo-local' ? 'instalada desde un archivo' : 'la que trae la app'}</div></div>
        <div style="background:#FDF7F0;border:1px solid #ECDCC9;border-radius:9px;padding:9px 11px"><div style="color:#8B7460;font-size:11px;text-transform:uppercase;letter-spacing:.04em">Última en la nube</div>
          <b style="font-size:15px;color:${masNueva ? '#BF4E1C' : '#2A1D14'}">${ult ? e(ult.version) : '—'}</b><div style="color:#8B7460">${ult ? fecha(ult.version) : (vs ? 'todavía no se subió ninguna' : 'sin consultar')}</div></div>
      </div>
      ${pendiente ? `<div style="margin-top:10px;font-size:13px"><b style="color:#BF4E1C">La versión ${e(pendiente)} ya está lista: se aplica al recargar.</b></div>` : ''}
      ${aviso ? `<div style="margin-top:10px;padding:8px 10px;border-radius:8px;font-size:12.5px;background:${aviso[1] ? '#FBE8E4' : '#E6F3EA'};color:${aviso[1] ? '#C8412F' : '#1F8A4C'}">${e(aviso[0])}</div>` : ''}
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        <button class="btn-secondary" onclick="itActBuscar()">Buscar en la nube</button>
        ${pendiente ? '<button class="btn-primary" onclick="location.reload()">Recargar y aplicar</button>' : ''}
      </div>
      <div style="margin-top:16px;padding:12px;border:1px dashed #EBC6A4;border-radius:10px;background:#FEF8F1">
        <b style="font-size:13px">Instalar desde un archivo</b>
        <p style="font-size:12px;color:#6E5B4B;margin:4px 0 8px">Buscá en la PC el archivo <code>IusTrack-actualizacion-….iustrack</code> (carpeta <code>actualizaciones</code>).
          ${dueno ? 'Como dueño del sistema, además se sube a la nube y les llega a todos los usuarios al abrir IusTrack.' : 'Se instala en esta computadora.'}</p>
        <label class="btn-primary" style="cursor:pointer;display:inline-block">📂 Buscar el archivo .iustrack<input type="file" accept=".iustrack,application/json" style="display:none" onchange="itActArchivo(this.files[0]);this.value=''"></label></div>
      ${vs && vs.length ? `<div style="margin-top:16px"><b style="font-size:13px">Historial en la nube</b>
        ${vs.map(v => `<div style="padding:7px 0;border-bottom:1px solid #F1E4D4;font-size:12.5px"><b>${e(v.version)}</b> <span style="color:#8B7460">· ${fecha(v.version)}</span>
          ${v.version === window.IUSTRACK.version ? ' <span style="color:#1F8A4C;font-weight:700">· en uso</span>' : ''}
          <div style="color:#4A3A2D;white-space:pre-line">${e(v.notas)}</div></div>`).join('')}</div>` : ''}
      <div style="display:flex;justify-content:flex-end;margin-top:12px"><button class="btn-secondary" onclick="modCerrarModal()">Cerrar</button></div>`, 640);
    };
    const consultar = async () => {
      try { vs = listo() ? await versiones() : null; if (!listo()) aviso = ['Ingresá con tu usuario para consultar la nube.', true]; }
      catch (err) { aviso = [/actualizaciones|schema cache|does not exist|relation/i.test(err.message) ? 'Falta correr el script 11-actualizaciones.sql en Supabase.' : 'No se pudo consultar la nube: ' + err.message, true]; }
    };
    await consultar();
    pintar();
    window.itActBuscar = async () => {
      aviso = null;
      try {
        await revisar(false); await consultar();
        const ult = vs && vs[0];
        if (!aviso) aviso = pendiente ? ['Se bajó la versión ' + pendiente + ': tocá "Recargar y aplicar".', false]
          : ult ? ['Esta es la última versión subida a la nube (' + ult.version + '). Si tenés un archivo más nuevo, instalalo con "Buscar el archivo".', false]
          : ['Todavía no hay versiones en la nube. Instalala con "Buscar el archivo".', false];
      } catch (err) { aviso = ['No se pudo buscar: ' + err.message, true]; }
      pintar();
    };
    // Instalar (y, si es el dueño, subir a la nube) un archivo elegido con el explorador
    window.itActArchivo = async (f) => {
      if (!f) return;
      aviso = null;
      try {
        const a = await leerArchivo(f);
        if (a.version < window.IUSTRACK.version && !confirm(`El archivo es la versión ${a.version}, más vieja que la que está en uso (${window.IUSTRACK.version}). ¿Instalarla igual?`)) return;
        let subida = false;
        if (dueno && listo()) {
          const ult = (vs && vs[0]) || (await versiones())[0];
          if (!ult || ult.version < a.version) {
            const { error } = await sb.from('actualizaciones').insert({ version: a.version, notas: a.notas || '', codigo: a.codigo, huella: a.huella });
            if (error) throw error;
            subida = true;
          }
        }
        escribir(CLAVE, { version: a.version, notas: a.notas || '', codigo: a.codigo, origen: 'archivo-local' });
        escribir(FALLO, null);
        pendiente = a.version;
        await consultar();
        aviso = [`Versión ${a.version} instalada${subida ? ' y subida a la nube (les llega a todos al abrir IusTrack)' : dueno ? ' (en la nube ya estaba esa versión o una más nueva)' : ' en esta computadora'}. Tocá "Recargar y aplicar".`, false];
      } catch (err) { aviso = ['No se pudo instalar: ' + (err.message || err), true]; }
      pintar();
    };
  };
})();
