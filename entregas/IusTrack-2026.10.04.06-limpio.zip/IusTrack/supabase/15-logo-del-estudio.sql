-- ════════════════════════════════════════════════════════════════════════
-- IusTrack — 15: logo propio del estudio
-- El administrador puede cambiar el logo que se ve en el menú, en el ingreso, en
-- los informes, en la pestaña del navegador y en los avisos. Si no hay logo
-- propio, se usa el de IusTrack.
-- Se puede correr más de una vez sin problema.
--
-- · Todos los miembros del estudio lo ven.
-- · Lo cambia o lo quita sólo el administrador del estudio.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.estudio_marca (
  estudio_id      uuid primary key references public.estudios(id) on delete cascade,
  logo_oscuro     text,           -- imagen (data URL) para fondos oscuros: el menú
  logo_claro      text,           -- para fondos claros: ingreso, informes
  icono           text,           -- cuadrado: pestaña del navegador y avisos
  actualizado_por uuid default auth.uid() references public.perfiles(id) on delete set null,
  actualizado_en  timestamptz not null default now(),
  check (coalesce(length(logo_oscuro), 0) + coalesce(length(logo_claro), 0) + coalesce(length(icono), 0) < 3000000)
);

create or replace function public.tg_estudio_marca() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.actualizado_por := coalesce(auth.uid(), new.actualizado_por);
  new.actualizado_en := now();
  return new;
end $$;
drop trigger if exists tg_estudio_marca on public.estudio_marca;
create trigger tg_estudio_marca before insert or update on public.estudio_marca
  for each row execute function public.tg_estudio_marca();

alter table public.estudio_marca enable row level security;
drop policy if exists emarca_ver       on public.estudio_marca;
drop policy if exists emarca_crear     on public.estudio_marca;
drop policy if exists emarca_modificar on public.estudio_marca;
drop policy if exists emarca_borrar    on public.estudio_marca;
create policy emarca_ver       on public.estudio_marca for select using (public.es_miembro(estudio_id));
create policy emarca_crear     on public.estudio_marca for insert with check (public.rol_en(estudio_id) = 'admin');
create policy emarca_modificar on public.estudio_marca for update using (public.rol_en(estudio_id) = 'admin') with check (public.rol_en(estudio_id) = 'admin');
create policy emarca_borrar    on public.estudio_marca for delete using (public.rol_en(estudio_id) = 'admin');

revoke all on public.estudio_marca from anon;
grant select, insert, update, delete on public.estudio_marca to authenticated;
