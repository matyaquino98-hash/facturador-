// IusTrack — service worker
// Guarda una copia de la app para que abra rápido y aun sin señal.
// Los datos del estudio (Supabase: base, ingreso y archivos) NUNCA se guardan en la copia.

const CACHE = 'iustrack-2026.10.04.06';   // cambiar el número en cada versión nueva
const BASICOS = ['./', './index.html', './manifest.webmanifest',
                 './icono-192.png', './icono-512.png',
                 './apple-icono-180.png', './apple-icono-152.png'];

self.addEventListener('install', ev => {
  ev.waitUntil(
    caches.open(CACHE).then(c => c.addAll(BASICOS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', ev => {
  ev.waitUntil(
    caches.keys()
      .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', ev => {
  const req = ev.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Supabase (datos, sesión, adjuntos): siempre a internet, sin copia
  if (url.hostname.endsWith('supabase.co') || url.hostname.endsWith('supabase.in')) return;
  // Sistemas judiciales: tampoco
  if (url.hostname.endsWith('scba.gov.ar') || url.hostname.endsWith('pjn.gov.ar')) return;

  // Librerías y tipografías (jsdelivr, cdnjs, Google Fonts): la copia si ya está
  if (url.origin !== self.location.origin) {
    ev.respondWith(
      caches.match(req).then(hit => hit || fetch(req).then(res => {
        if (res.ok || res.type === 'opaque') { const copia = res.clone(); caches.open(CACHE).then(c => c.put(req, copia)).catch(() => {}); }
        return res;
      }).catch(() => hit))
    );
    return;
  }

  // La app: primero internet (siempre la última versión); sin señal, la copia guardada
  ev.respondWith(
    fetch(req).then(res => {
      const copia = res.clone();
      caches.open(CACHE).then(c => c.put(req, copia)).catch(() => {});
      return res;
    }).catch(() => caches.match(req).then(hit => hit || caches.match('./index.html')))
  );
});

// Permite actualizar sin esperar, cuando la app lo pide
self.addEventListener('message', ev => {
  if (ev.data === 'actualizar') self.skipWaiting();
});
