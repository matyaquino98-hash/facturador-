/* IusTrack — SRT y EJE: puente entre esta extensión y IusTrack abierto en Chrome.
   Sólo intercambia mensajes con la página de IusTrack (las listas de causas leídas y
   los pedidos de "leer mis causas"). No lee ni toca la sesión ni los datos de IusTrack. */
(() => {
  if (!/IusTrack|LexTrack/i.test(document.title)) return;
  const EXT = 'iustrack-portales-ext', APP = 'iustrack-portales-app';
  const aPagina = (tipo, datos) => window.postMessage(Object.assign({ fuente: EXT, tipo }, datos || {}), '*');
  const pedir = (m, cb) => { try { chrome.runtime.sendMessage(m, r => { if (!chrome.runtime.lastError && cb) cb(r); }); } catch (e) {} };
  const listas = () => pedir({ it: 'listas' }, r => aPagina('listas', { listas: r || {} }));

  window.addEventListener('message', ev => {
    const d = ev.data;
    if (ev.source !== window || !d || d.fuente !== APP) return;
    if (d.tipo === 'consultar') { listas(); pedir({ it: 'estado' }, r => aPagina('estado', { estado: r || {} })); }
    if (d.tipo === 'leer' && /^(SRT|EJE)$/.test(d.origen || ''))
      pedir({ it: 'leer', origen: d.origen, url: String(d.url || ''), abrir: !!d.abrir, cuit: String(d.cuit || '').replace(/\D/g, '').slice(0, 11) });
  });
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    if (c.portalListas) aPagina('listas', { listas: c.portalListas.newValue || {} });
    if (c.portalEstado) aPagina('estado', { estado: c.portalEstado.newValue || {} });
  });
  const hola = () => aPagina('hola', { version: chrome.runtime.getManifest().version });
  hola(); setTimeout(hola, 3000);
})();
