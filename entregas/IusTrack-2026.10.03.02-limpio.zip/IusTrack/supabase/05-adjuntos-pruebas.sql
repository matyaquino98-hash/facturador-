-- ════════════════════════════════════════════════════════════════════════
-- LexTrack — 05: archivos adjuntos en el Control de Pruebas
-- (PDF de respuesta de un oficio, cédula diligenciada, etc.)
-- Se puede correr más de una vez sin problema.
--
-- · Tabla pruebas_adjuntos: un registro por archivo, colgado de una prueba.
-- · Los archivos van a la misma carpeta privada "adjuntos", en la ruta
--   <estudio>/pruebas/<prueba>/<archivo>.
-- · Permisos: los mismos que la prueba (ver si se ve el juicio; subir y borrar
--   si se puede editar el juicio). Cada estudio sólo ve lo suyo.
-- ════════════════════════════════════════════════════════════════════════

create table if not exists public.pruebas_adjuntos (
  id              text primary key default gen_random_uuid()::text,
  prueba_id       text not null references public.pruebas(id) on delete cascade,
  estudio_id      uuid not null references public.estudios(id) on delete cascade,
  nombre          text not null,
  tamanio         bigint not null default 0,
  tipo_mime       text not null default '',
  ruta            text not null,   -- ruta en Storage: estudio/pruebas/prueba/archivo
  subido_por      uuid default auth.uid() references public.perfiles(id) on delete set null,
  subido_en       timestamptz not null default now()
);
create index if not exists ix_pruebas_adj_prueba on public.pruebas_adjuntos(prueba_id);

-- El estudio se toma siempre de la prueba (no se puede colgar de una prueba ajena)
create or replace function public.tg_estudio_desde_prueba() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  select estudio_id into new.estudio_id from pruebas where id = new.prueba_id;
  if new.estudio_id is null then raise exception 'Prueba inexistente'; end if;
  new.subido_por := coalesce(auth.uid(), new.subido_por);
  return new;
end $$;
drop trigger if exists tg_pru_adj_estudio on public.pruebas_adjuntos;
create trigger tg_pru_adj_estudio before insert or update on public.pruebas_adjuntos
  for each row execute function public.tg_estudio_desde_prueba();

-- Permisos a partir de la prueba
create or replace function public.puede_ver_prueba(p_prueba text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from pruebas p where p.id = p_prueba and public.puede_ver_juicio(p.juicio_id));
$$;
create or replace function public.puede_editar_prueba(p_prueba text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from pruebas p where p.id = p_prueba and public.puede_editar_juicio(p.juicio_id));
$$;

alter table public.pruebas_adjuntos enable row level security;
drop policy if exists pad_ver    on public.pruebas_adjuntos;
drop policy if exists pad_crear  on public.pruebas_adjuntos;
drop policy if exists pad_borrar on public.pruebas_adjuntos;
create policy pad_ver    on public.pruebas_adjuntos for select using (public.puede_ver_prueba(prueba_id));
create policy pad_crear  on public.pruebas_adjuntos for insert with check (public.puede_editar_prueba(prueba_id));
create policy pad_borrar on public.pruebas_adjuntos for delete using (public.puede_editar_prueba(prueba_id));
-- (sin política de modificación: un adjunto se sube o se borra, no se edita)

-- Archivos en Storage: <estudio>/pruebas/<prueba>/<archivo>
create or replace function public.ruta_prueba_valida(p_ruta text, p_editar boolean) returns boolean
language sql stable security definer set search_path = public as $$
  select split_part(p_ruta, '/', 2) = 'pruebas' and exists (
    select 1 from pruebas p
    where p.id = split_part(p_ruta, '/', 3)
      and p.estudio_id::text = split_part(p_ruta, '/', 1)
      and case when p_editar then public.puede_editar_juicio(p.juicio_id)
               else public.puede_ver_juicio(p.juicio_id) end
  );
$$;

drop policy if exists adjuntos_pruebas_ver    on storage.objects;
drop policy if exists adjuntos_pruebas_subir  on storage.objects;
drop policy if exists adjuntos_pruebas_borrar on storage.objects;
create policy adjuntos_pruebas_ver    on storage.objects for select to authenticated
  using (bucket_id = 'adjuntos' and public.ruta_prueba_valida(name, false));
create policy adjuntos_pruebas_subir  on storage.objects for insert to authenticated
  with check (bucket_id = 'adjuntos' and public.ruta_prueba_valida(name, true));
create policy adjuntos_pruebas_borrar on storage.objects for delete to authenticated
  using (bucket_id = 'adjuntos' and public.ruta_prueba_valida(name, true));

revoke all on public.pruebas_adjuntos from anon;
