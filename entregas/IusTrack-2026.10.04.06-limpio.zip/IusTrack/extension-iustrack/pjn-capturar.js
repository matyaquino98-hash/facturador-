/* IusTrack — lectura de un expediente en la Consulta Web del PJN
   · Al abrirlo: se leen las actuaciones de la primera página (las más recientes) y las
     nuevas quedan listas para IusTrack (también lo usa la procuración automática).
   · Si se abrió para descargarlo completo: se recorren todas las páginas de actuaciones
     y, si se pidieron, los documentos firmados de cada una (link "Descargar" de la fila,
     viewer.seam: se piden directo, sin abrir pestañas), y se le manda todo a descarga.html. */
(() => {
  if (/consultaListaFavoritos/i.test(location.pathname)) return;   // la lista no es un expediente

  const CAMARAS = 'CSJ|CIV|CAF|CCF|CNE|CSS|CPE|CNT|CFP|CCC|COM|CPF|CPN|FBB|FCR|FCB|FCT|FGR|FLP|FMP|FMZ|FPO|FPA|FRE|FSA|FRO|FSM|FTU';
  const CABEZAS = ['fecha', 'tipo', 'detalle', 'descripc', 'oficina', 'actuaci', 'foja', 'fs.'];
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const txt = el => norm(el && el.textContent);
  const dormir = ms => new Promise(r => setTimeout(r, ms));

  // La grilla de actuaciones: la tabla cuyo encabezado nombra fecha y tipo/detalle
  // (la Lista de Favoritos tiene "Últ. Act.", no "Fecha": no se confunde)
  function encabezado(t) {
    for (const tr of Array.from(t.rows).slice(0, 4)) {
      const c = Array.from(tr.cells).map(x => txt(x).toLowerCase());
      const hits = c.filter(x => CABEZAS.some(h => x.includes(h)));
      if (hits.length >= 2 && c.some(x => x.includes('fecha'))) return { tr, c };
    }
    return null;
  }
  function grilla() {
    let mejor = null;
    document.querySelectorAll('table').forEach(t => {
      const h = encabezado(t);
      if (!h) return;
      const n = (t.textContent.match(/\b\d{1,2}\/\d{2}\/\d{4}\b/g) || []).length;
      if (!mejor || n > mejor.n) mejor = { t, h, n };
    });
    return mejor && mejor.n ? mejor : null;
  }
  // El PJN repite el rótulo dentro de cada celda ("Tipo actuacion: …", "Detalle: …"): se saca.
  // "k" conserva el texto tal cual viene, para que la clave del movimiento no cambie.
  const sinRotulo = s => String(s || '').replace(/^(tipo\s+actuaci[oó]n|detalle|descripci[oó]n|oficina|fecha)\s*:\s*/i, '');
  function leer(g) {
    const col = k => g.h.c.findIndex(x => k.some(y => x.includes(y)));
    const iF = col(['fecha']), iT = col(['tipo']), iD = col(['detalle', 'descripc']), iO = col(['oficina']), iX = col(['fs']);
    const movs = [];
    for (const tr of g.t.rows) {
      if (tr === g.h.tr || !tr.cells.length || (tr.parentElement && tr.parentElement.tagName === 'TFOOT')) continue;
      const v = Array.from(tr.cells).map(txt);
      const f = (v[iF] || v.join(' ')).match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
      if (!f) continue;
      const tipo = (iT >= 0 && v[iT]) || 'ACTUACIÓN', detalle = (iD >= 0 && v[iD]) || '';
      // Documento firmado: el link "Descargar" (o, si no está, "Ver") de la fila
      const links = Array.from(tr.querySelectorAll('a[href]')).filter(a => /viewer\.seam/i.test(a.getAttribute('href') || ''));
      const doc = (links.find(a => /descarg/i.test(txt(a))) || links[0] || {}).href || '';
      movs.push({ fecha: `${f[3]}-${f[2].padStart(2, '0')}-${f[1].padStart(2, '0')}`,
        tipo: sinRotulo(tipo) || 'ACTUACIÓN', detalle: sinRotulo(detalle), k: tipo + '|' + detalle,
        oficina: iO >= 0 ? sinRotulo(v[iO]) : '', fojas: iX >= 0 ? v[iX] || '' : '', doc });
    }
    return movs;
  }
  function causa() {
    const m = document.body.textContent.match(new RegExp('\\b(' + CAMARAS + ')\\s+0*(\\d{1,7})\\s*/\\s*(\\d{4})', 'i'));
    if (!m) return null;
    const d = datosGenerales();
    return { cam: m[1].toUpperCase(), num: String(parseInt(m[2], 10)), anio: m[3], caratula: (d.caratula || '').slice(0, 250) };
  }
  // "Datos Generales" de la ficha: rótulo en un elemento y valor en el siguiente
  function datosGenerales() {
    const d = {};
    Array.from(document.querySelectorAll('div, td, span, label, dt, b, strong')).forEach(el => {
      if (el.children.length > 2) return;
      const m = txt(el).match(/^(Jurisdicci[oó]n|Dependencia|Sit\.?\s*Actual|Car[aá]tula)\s*:?\s*$/i);
      if (!m || !el.nextElementSibling) return;
      const k = /jurisd/i.test(m[1]) ? 'jurisdiccion' : /depend/i.test(m[1]) ? 'dependencia' : /sit/i.test(m[1]) ? 'situacion' : 'caratula';
      if (!d[k]) d[k] = txt(el.nextElementSibling).slice(0, 300);
    });
    return d;
  }

  function aviso(t, error) {
    let d = document.getElementById('iustrack-aviso-pjn');
    if (!d) {
      d = document.createElement('div'); d.id = 'iustrack-aviso-pjn';
      d.title = 'Clic para cerrar'; d.onclick = () => d.remove();
      document.body.appendChild(d);
    }
    d.style.cssText = 'position:fixed;top:14px;right:14px;z-index:2147483647;max-width:380px;padding:12px 16px;border-radius:10px;' +
      'font:14px/1.4 Arial,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);cursor:pointer;' +
      (error ? 'background:#fdecec;color:#8a1c1c;border:1px solid #e8b4b4' : 'background:#eaf7ee;color:#1d5e33;border:1px solid #b5dfc3');
    d.textContent = 'IusTrack: ' + t;
    clearTimeout(d._t); d._t = setTimeout(() => d.remove(), error ? 20000 : 9000);
  }

  // ── Descarga completa ────────────────────────────────────────────────
  // Paginador: <ul class="pagination">, página actual en <li class="active">, números
  // siguientes como links y, al final de cada tanda de diez, una flecha a la siguiente.
  // Cada página se carga por AJAX: se espera a que cambie la grilla.
  const firma = () => { const g = grilla(); return g ? Array.from(g.t.rows).slice(1, 3).map(txt).join('#') : ''; };
  function siguiente() {
    const ul = document.querySelector('ul.pagination'); if (!ul) return null;
    const lis = Array.from(ul.children), i = lis.findIndex(l => l.classList.contains('active'));
    const n = lis.slice(i + 1).find(l => /^\d+$/.test(txt(l)) && l.querySelector('a'));
    if (n) return n.querySelector('a');
    const flecha = ul.querySelector('.fa-arrow-circle-o-right, .fa-angle-right, .fa-chevron-right');
    return flecha ? flecha.closest('a') : null;
  }
  function aBase64(bytes) {
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }
  const avisar = m => chrome.runtime.sendMessage(m).catch(() => {});

  async function descargaCompleta(pedido, c) {
    const todos = [], vistas = new Set();
    let pagina = 1;
    for (let vueltas = 0; vueltas < 400; vueltas++) {
      const g = grilla(); if (!g) break;
      const f = firma(); if (vistas.has(f)) break; vistas.add(f);
      todos.push(...leer(g));
      avisar({ it: 'pjn-progreso', id: pedido.id, fase: 'actuaciones', pagina, leidas: todos.length });
      aviso(`leyendo las actuaciones: página ${pagina} (${todos.length})…`);
      const a = siguiente(); if (!a) break;
      a.click(); pagina++;
      let k = 0; while (firma() === f && k++ < 120) await dormir(250);   // hasta 30 s por página
      if (firma() === f) break;
      await dormir(400);
    }
    // Documentos firmados: se piden por su link (mismo sitio, con la sesión abierta)
    let docs = 0;
    if (pedido.docs) {
      const conDoc = todos.map((m, i) => ({ m, i })).filter(x => x.m.doc);
      for (let n = 0; n < conDoc.length; n++) {
        const { m, i } = conDoc[n];
        avisar({ it: 'pjn-progreso', id: pedido.id, fase: 'documentos', actual: n + 1, total: conDoc.length });
        aviso(`bajando los documentos: ${n + 1} de ${conDoc.length}…`);
        try {
          const r = await fetch(m.doc, { credentials: 'include' });
          const b = new Uint8Array(await r.arrayBuffer());
          if (b.length > 400 && b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46) {   // %PDF
            await chrome.runtime.sendMessage({ it: 'pjn-doc', id: pedido.id, i, b64: aBase64(b) });
            docs++;
          }
        } catch (e) {}
        await dormir(300);
      }
    }
    const datos = Object.assign({ caratula: c.caratula }, datosGenerales());
    avisar({ it: 'pjn-listo', id: pedido.id, causa: c, datos, movs: todos.map(({ doc, k, ...x }) => x), docs });
    aviso(`listo: ${todos.length} actuaciones${pedido.docs ? ` y ${docs} documentos` : ''}. Esta pestaña se cierra sola.`);
  }

  // La grilla del PJN se arma después de cargar la página: se la espera hasta 25 segundos
  let intentos = 0;
  (async function buscar() {
    const g = grilla(), c = g && causa();
    if (!g || !c) { if (++intentos < 50) setTimeout(buscar, 500); return; }
    // ¿Se abrió para descargarlo completo?
    const pedido = (await chrome.storage.local.get('itPjnDescarga')).itPjnDescarga;
    const vigente = pedido && Date.now() - pedido.t < 15 * 60 * 1000;
    if (vigente && pedido.cam === c.cam && pedido.num === c.num && pedido.anio === c.anio) {
      aviso('leyendo todo el expediente para descargarlo…');
      descargaCompleta(pedido, c);
    } else if (vigente) {
      // El fondo confirma que es la pestaña de la descarga (y no otro expediente abierto a mano)
      avisar({ it: 'pjn-otro', id: pedido.id, motivo: `Se abrió otro expediente (${c.cam} ${c.num}/${c.anio}) en lugar del pedido. Revisá que esté en tus Favoritos del PJN con el mismo número y volvé a pedirlo.` });
    }
    const movs = leer(g).map(({ doc, ...x }) => x);   // aunque venga vacía se avisa: la revisión automática sigue con el próximo
    chrome.runtime.sendMessage({ it: 'pjn-pagina', causa: c, movs }, r => {
      if (chrome.runtime.lastError || !r || r.silencio) return;
      if (r.otro) {
        aviso(`ATENCIÓN: se pidió ${r.otro} pero se abrió ${r.abierto}. No se cargó nada en IusTrack. Revisá que ${r.otro} esté en tus Favoritos del PJN con ese número.`, true);
        return;
      }
      if (!r.nuevos) return;
      const n = r.nuevos === 1 ? 'una actuación nueva' : r.nuevos + ' actuaciones nuevas';
      aviso((r.primera ? `primera lectura de este expediente: ${n} de los últimos 15 días` : n) +
        (r.app ? '. Ya se están cargando en IusTrack.' : '. Se cargan en cuanto abras IusTrack.'));
    });
  })();
})();
