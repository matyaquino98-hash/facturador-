/* IusTrack — puente entre la extensión y la app abierta como archivo (file:///…).
   Le pasa a IusTrack los movimientos capturados y recibe la lista de expedientes a
   revisar. No lee ni toca la sesión ni los datos de IusTrack: sólo intercambia
   mensajes con la página. */
(() => {
  if (!/IusTrack|LexTrack/i.test(document.title)) return;
  const EXT = 'iustrack-ext', APP = 'iustrack-app';
  const aPagina = (tipo, datos) => window.postMessage(Object.assign({ fuente: EXT, tipo }, datos || {}), '*');
  const pedir = (m, cb) => { try { chrome.runtime.sendMessage(m, r => { if (!chrome.runtime.lastError && cb) cb(r); }); } catch (e) {} };
  const entregar = () => pedir({ it: 'bandeja' }, items => { if (items && items.length) aPagina('capturas', { items }); });

  window.addEventListener('message', ev => {
    const d = ev.data;
    if (ev.source !== window || !d || d.fuente !== APP) return;
    if (d.tipo === 'pedir') entregar();
    if (d.tipo === 'confirmar' && Array.isArray(d.ids)) pedir({ it: 'confirmar', ids: d.ids });
    if (d.tipo === 'seguimiento' && Array.isArray(d.lista)) pedir({ it: 'seguimiento', lista: d.lista });
    // Botón ⚖ Procuración de IusTrack: estado, informes y "revisar ahora"
    if (d.tipo === 'proc-estado') pedir({ it: 'estado', informes: !!d.informes }, r => aPagina('proc-estado', { r, pedido: d.pedido }));
    if (d.tipo === 'proc-revisar') pedir({ it: 'revisar' }, () => aPagina('proc-iniciada'));
    // ⬇ Descargas: pedir expedientes, ver cómo van, sacar de la lista y recibir los PDF listos
    if (d.tipo === 'descargar' && Array.isArray(d.trabajos)) pedir({ it: 'descargar', trabajos: d.trabajos, docs: !!d.docs }, () => aPagina('desc-pedida'));
    if (d.tipo === 'desc-estado') pedir({ it: 'desc-estado' }, cola => aPagina('desc-estado', { cola: cola || [] }));
    if (d.tipo === 'desc-quitar' && Array.isArray(d.ids)) pedir({ it: 'desc-quitar', ids: d.ids });
    if (d.tipo === 'pedir-archivos') pedir({ it: 'archivos' }, items => { if (items && items.length) aPagina('archivos', { items }); });
    if (d.tipo === 'archivos-confirmar' && Array.isArray(d.ids)) pedir({ it: 'archivos-confirmar', ids: d.ids });
  });
  // Apenas llega algo nuevo, se le pasa a la app
  chrome.storage.onChanged.addListener((c, area) => {
    if (area !== 'local') return;
    if (c.itBandeja) entregar();
    if (c.itDescCola) aPagina('desc-estado', { cola: c.itDescCola.newValue || [] });
    if (c.itArchivos && (c.itArchivos.newValue || []).length) aPagina('archivos', { items: c.itArchivos.newValue });
  });

  aPagina('hola', { version: chrome.runtime.getManifest().version });
  setTimeout(() => aPagina('hola', { version: chrome.runtime.getManifest().version }), 3000);
})();
