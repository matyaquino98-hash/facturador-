/* IusTrack — abrir expedientes del PJN
   IusTrack abre la Lista de Expedientes Favoritos con "#lextrack=CIV-86010-2023" al final.
   Esta extensión guarda ese pedido (sobrevive al inicio de sesión), llega a la lista, busca
   la fila del expediente —pasando de página si hace falta— y toca su ojo.

   Lo que hace el PJN y hay que tener en cuenta (visto en la Consulta Web real):
   · Entrar a la dirección de la lista NO siempre muestra la lista: si hay un expediente
     abierto en la sesión, el PJN muestra ese expediente (por eso "abría siempre el mismo").
   · "Volver a Mi Lista" muestra la lista pero la dirección sigue diciendo expediente.seam:
     la lista se reconoce por su contenido, no por la dirección.
   · La lista recuerda en qué página quedó: se arranca siempre desde la página 1.
   · Paginador: <ul class="pagination">, página actual en <li class="active">, flechas
     para la tanda siguiente/anterior de diez páginas. */
(() => {
  const CLAVE = 'lextrackPendiente';
  const VIGENCIA = 10 * 60 * 1000;   // el pedido vale 10 minutos (tiempo para iniciar sesión)
  const PAUSA = 700;

  function leerHash() {
    const m = location.hash.match(/lextrack=([A-Z]{2,4})-(\d{1,7})-(\d{4})/i);
    if (!m) return null;
    return { cam: m[1].toUpperCase(), num: String(parseInt(m[2], 10)), anio: m[3], t: Date.now(), volver: 0, menu: 0, desdeUno: false };
  }
  const guardar = p => chrome.storage.local.set({ [CLAVE]: p });
  const borrar = () => chrome.storage.local.remove(CLAVE);
  async function pendiente() {
    const h = leerHash();
    if (h) {
      await guardar(h);
      history.replaceState(null, '', location.pathname + location.search);
      return h;
    }
    const p = (await chrome.storage.local.get(CLAVE))[CLAVE];
    if (p && Date.now() - p.t < VIGENCIA) return p;
    if (p) await borrar();
    return null;
  }

  function aviso(txt, tipo) {
    let d = document.getElementById('lextrack-aviso');
    if (!d) {
      d = document.createElement('div');
      d.id = 'lextrack-aviso';
      d.style.cssText = 'position:fixed;top:14px;right:14px;z-index:2147483647;max-width:380px;padding:12px 16px;border-radius:10px;' +
        'font:14px/1.4 Arial,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);cursor:pointer';
      d.title = 'Clic para cerrar';
      d.onclick = () => d.remove();
      document.body.appendChild(d);
    }
    const c = { error: ['#fdecec', '#8a1c1c', '#e8b4b4'], ok: ['#eaf7ee', '#1d5e33', '#b5dfc3'] }[tipo] || ['#fff8e6', '#5c4300', '#f0d98c'];
    d.style.background = c[0]; d.style.color = c[1]; d.style.border = '1px solid ' + c[2];
    d.textContent = 'IusTrack: ' + txt;
  }

  // Si es la revisión automática o una descarga, que el fondo siga sin esperar
  const noEncontrado = () => { try { chrome.runtime.sendMessage({ it: 'pjn-no-encontrado' }); } catch (e) {} };

  const textoDe = el => (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  // Números de expediente distintos que menciona un bloque. La carátula suele repetir el
  // propio número y la columna "Últ. Act." tiene una fecha (5/08/2026): ninguna de las dos
  // cosas es otro expediente.
  const numeros = t => new Set([...t.matchAll(/(?<![\d\/])(\d{1,7})\s*\/\s*(\d{4})\b(?!\s*\/)/g)].map(m => +m[1] + '/' + m[2])).size;
  function botonOjo(fila) {
    const icono = fila.querySelector('[class*="eye"], [class*="ojo"], img[src*="eye"], img[src*="ver"], [title*="Ver" i]');
    const b = icono && icono.closest('a, button, input');
    if (b) return b;
    return [...fila.querySelectorAll('a, button, input[type=submit], input[type=image]')]
      .find(x => !/trash|papelera|borrar|elimin|delete|quitar|descartar/i.test(x.outerHTML));
  }
  // La lista: una tabla con encabezados Expediente y Carátula y un ojo por fila
  function tablaLista() {
    return [...document.querySelectorAll('table')].find(t => {
      const cab = textoDe(t.rows[0] || t).toLowerCase();
      return /expediente/.test(cab) && /car[aá]tula/.test(cab) && t.querySelector('[class*="eye"]');
    }) || null;
  }
  const botonPorTexto = re => [...document.querySelectorAll('a, button, input[type=submit], input[type=button]')]
    .find(e => re.test(textoDe(e) || e.value || ''));

  async function empezar() {
    const p = await pendiente();
    if (!p) return;
    const nombre = `${p.cam} ${p.num}/${p.anio}`;
    if (location.hostname.startsWith('sso.')) { aviso(`iniciá sesión y después se abre ${nombre}.`); return; }
    aviso(`buscando ${nombre} en tus favoritos…`);
    const re = new RegExp('\\b' + p.cam + '\\s*0*' + p.num + '\\s*/\\s*' + p.anio + '\\b');
    let intentos = 0;
    const firmas = new Set();   // páginas de la lista ya revisadas

    // La fila propia del expediente: se parte del texto con el número y se sube hasta el
    // primer bloque con botón que no mencione otro expediente.
    function buscarFila(t) {
      const w = document.createTreeWalker(t, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        if (!re.test(n.textContent.toUpperCase())) continue;
        for (let el = n.parentElement; el && el !== t; el = el.parentElement) {
          if (numeros(textoDe(el)) > 1) break;
          const ojo = botonOjo(el);
          if (ojo) return { fila: el, ojo };
        }
      }
      // Cámara y número en celdas distintas: la fila más chica que los tiene
      const filas = [...t.querySelectorAll('tr')].filter(f => re.test(textoDe(f).toUpperCase()) && numeros(textoDe(f)) <= 1);
      const f = filas.find(f => !filas.some(o => o !== f && f.contains(o)));
      const ojo = f && botonOjo(f);
      return ojo ? { fila: f, ojo } : null;
    }

    const tick = async () => {
      intentos++;
      const t = tablaLista();
      if (!t) {
        // No es la lista. Si el PJN mostró un expediente (el último que se vio), se vuelve a la lista.
        const volver = botonPorTexto(/volver a mi lista/i);
        if (volver && p.volver < 3) { p.volver++; await guardar(p); aviso(`volviendo a tu lista para buscar ${nombre}…`); volver.click(); return; }
        // Si no, por el menú "Mis Expedientes → Favoritos"
        const menu = botonPorTexto(/^favoritos$/i);
        if (menu && intentos >= 4 && p.menu < 2) { p.menu++; await guardar(p); menu.click(); return; }
        if (intentos > 40) { aviso(`no pude llegar a tu Lista de Expedientes Favoritos. Abrila desde "Mis Expedientes → Favoritos" y se busca ${nombre} solo.`, 'error'); noEncontrado(); return; }
        return setTimeout(tick, PAUSA);
      }
      if (intentos < 2) return setTimeout(tick, PAUSA);   // se da tiempo a que termine de cargar la tabla

      const ul = document.querySelector('ul.pagination');
      const activa = ul && ul.querySelector('li.active');
      // La lista recuerda la página en que quedó: primero se va a la 1
      if (!p.desdeUno && activa && textoDe(activa) !== '1') {
        const uno = [...ul.querySelectorAll('li')].find(l => textoDe(l) === '1' && l.querySelector('a'));
        const primera = ul.querySelector('.fa-angle-double-left, .fa-step-backward');
        const a = (uno && uno.querySelector('a')) || (primera && primera.closest('a'));
        p.desdeUno = true; await guardar(p);
        if (a) { a.click(); intentos = 0; return setTimeout(tick, PAUSA * 2); }
      }
      p.desdeUno = true;

      const hallado = buscarFila(t);
      if (hallado) {
        await borrar();
        // Para verificar, en la página del expediente, que se abrió el pedido
        await chrome.storage.local.set({ itPjnPedido: { cam: p.cam, num: p.num, anio: p.anio, t: Date.now() } });
        aviso(`abriendo ${nombre}…`, 'ok');
        hallado.fila.style.outline = '3px solid #c8a951';
        hallado.ojo.click();
        return;
      }
      // No está en esta página: a la siguiente (número siguiente o flecha de la tanda siguiente)
      firmas.add(textoDe(t).slice(0, 400));
      let sig = null;
      if (ul) {
        const lis = [...ul.children], i = lis.findIndex(l => l.classList.contains('active'));
        const n = lis.slice(i + 1).find(l => /^\d+$/.test(textoDe(l)) && l.querySelector('a'));
        const flecha = ul.querySelector('.fa-arrow-circle-o-right, .fa-angle-right, .fa-chevron-right');
        sig = (n && n.querySelector('a')) || (flecha && flecha.closest('a'));
      }
      if (sig) {
        const antes = textoDe(t).slice(0, 400);
        aviso(`buscando ${nombre} en la página siguiente…`);
        sig.click();
        let k = 0;
        while (k++ < 60) { await new Promise(r => setTimeout(r, 250)); const t2 = tablaLista(); if (t2 && textoDe(t2).slice(0, 400) !== antes) break; }
        const t2 = tablaLista();
        if (t2 && !firmas.has(textoDe(t2).slice(0, 400))) { intentos = 1; return tick(); }
      }
      await borrar();
      aviso(`${nombre} no está en tus favoritos. Agregalo con la estrella ⭐ en el PJN o revisá el número cargado en IusTrack.`, 'error');
      noEncontrado();
    };
    tick();
  }
  empezar();
})();
