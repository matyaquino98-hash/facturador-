/* IusTrack — SRT y EJE: segundo plano.
   · "Leer mis causas" (desde IusTrack): abre el portal en la última página de listado que
     se usó (o en el inicio) y espera a que lector.js mande la lista.
   · Si el portal pide ingresar, se deja la pestaña a la vista para que el usuario entre
     (nunca se escribe ni se envía la contraseña sola).
   · Las listas quedan en chrome.storage.local de esta computadora y puente.js se las pasa
     a IusTrack. */
// La SRT se usa con Clave Fiscal: se empieza por el ingreso de AFIP (después, por el último listado usado)
const INICIO = { SRT: 'https://auth.afip.gob.ar/contribuyente_/login.xhtml', EJE: 'https://eje.juscaba.gob.ar/' };
const PERMITIDA = /^https:\/\/(([a-z0-9-]+\.)*srt\.gob\.ar|eje\.juscaba\.gob\.ar|eje\.jus\.gov\.ar)\//i;
const ESPERA_MIN = 4;
const leer = k => new Promise(r => chrome.storage.local.get(k, o => r(o[k])));
const poner = o => new Promise(r => chrome.storage.local.set(o, r));
const claveCausa = x => String(x.numero || '').toUpperCase().replace(/\s+/g, '');
// Usuario y clave de la lectura en curso: sólo en la memoria de la sesión de Chrome (se borran al
// terminar o al cerrar Chrome) y sólo se le dan a la pestaña que abrió la extensión.
const sesion = chrome.storage.session || chrome.storage.local;
const claves = { leer: o => new Promise(r => sesion.get('portalClaves', x => r((x && x.portalClaves || {})[o] || null))),
  poner: (o, v) => new Promise(r => sesion.get('portalClaves', x => { const c = (x && x.portalClaves) || {}; if (v) c[o] = v; else delete c[o]; sesion.set({ portalClaves: c }, r); })) };

async function estado(origen, msg) {
  const e = (await leer('portalEstado')) || {};
  e[origen] = { msg, t: Date.now() };
  await poner({ portalEstado: e });
}
async function guardarLista(origen, cambios) {
  const l = (await leer('portalListas')) || {};
  l[origen] = Object.assign({ items: [] }, l[origen] || {}, cambios, { t: Date.now() });
  await poner({ portalListas: l });
  return l[origen];
}
async function terminar(origen, cerrarTab) {
  const pend = (await leer('portalPend')) || {}, p = pend[origen];
  delete pend[origen];
  await poner({ portalPend: pend });
  chrome.alarms.clear('vence-' + origen);
  await claves.poner(origen, null);
  if (p && cerrarTab && !p.abrir && p.tabId) chrome.tabs.remove(p.tabId).catch(() => {});
  await estado(origen, '');
}

async function manejar(m, snd) {
  const origen = m.origen;
  if (m.it === 'listas') return (await leer('portalListas')) || {};
  if (m.it === 'estado') return (await leer('portalEstado')) || {};
  if (m.it === 'leer') {
    if (!INICIO[origen]) return { error: 'origen' };
    const url = PERMITIDA.test(m.url || '') ? m.url : INICIO[origen];
    const pend = (await leer('portalPend')) || {};
    if (pend[origen] && pend[origen].tabId) chrome.tabs.remove(pend[origen].tabId).catch(() => {});
    const tab = await chrome.tabs.create({ url, active: !!m.abrir });
    pend[origen] = { t: Date.now(), tabId: tab.id, abrir: !!m.abrir, cuit: m.cuit || '' };
    await poner({ portalPend: pend });
    await claves.poner(origen, m.cuit ? { usuario: m.cuit, clave: m.clave || '' } : null);
    chrome.alarms.create('vence-' + origen, { delayInMinutes: ESPERA_MIN });
    await estado(origen, m.abrir ? 'abierto' : 'leyendo');
    return { ok: true };
  }
  if (m.it === 'pendiente') {
    const pend = (await leer('portalPend')) || {}, p = pend[origen];
    if (!p || Date.now() - p.t > 30 * 60 * 1000) return null;
    const esta = !!(snd.tab && snd.tab.id === p.tabId), r = { cuit: p.cuit, abrir: p.abrir, esta };
    if (esta) { const c = await claves.leer(origen); if (c) { r.usuario = c.usuario; r.clave = c.clave; } }
    return r;
  }
  if (m.it === 'lista') {
    if (!INICIO[origen] || !Array.isArray(m.items)) return { error: 'datos' };
    const items = m.items.filter(x => x && x.numero).slice(0, 3000).map(x => ({
      numero: String(x.numero).slice(0, 80), caratula: String(x.caratula || '').slice(0, 400), motivo: String(x.motivo || '').slice(0, 200),
      damnificado: String(x.damnificado || '').slice(0, 200), juzgado: String(x.juzgado || '').slice(0, 200), inicio: String(x.inicio || '').slice(0, 30),
      estado: String(x.estado || '').slice(0, 120), link: /^https:\/\//i.test(x.link || '') ? String(x.link).slice(0, 600) : '' }));
    // Las páginas de un mismo listado se van sumando
    const ant = ((await leer('portalListas')) || {})[origen];
    const mapa = new Map(((ant && ant.items) || []).map(x => [claveCausa(x), x]));
    items.forEach(x => mapa.set(claveCausa(x), Object.assign({}, mapa.get(claveCausa(x)) || {}, x)));
    const r = await guardarLista(origen, { items: [...mapa.values()], url: PERMITIDA.test(m.url || '') ? m.url : (ant && ant.url) || '', error: '', ultimaPagina: items.length });
    const pend = (await leer('portalPend')) || {}, p = pend[origen];
    await terminar(origen, !!(p && snd.tab && snd.tab.id === p.tabId));
    return { ok: true, total: r.items.length };
  }
  if (m.it === 'login') {
    const pend = (await leer('portalPend')) || {}, p = pend[origen];
    if (!p) return null;
    if (!p.abrir) {                       // revisión automática: no se abre nada a la vista
      await guardarLista(origen, { error: 'login' });
      await terminar(origen, true);
      return { ok: true };
    }
    await guardarLista(origen, { error: 'login' });
    await estado(origen, 'login');
    return { ok: true };
  }
  return null;
}
chrome.runtime.onMessage.addListener((m, snd, responder) => { manejar(m || {}, snd || {}).then(responder, e => responder({ error: String(e && e.message || e) })); return true; });

chrome.alarms.onAlarm.addListener(async a => {
  const m = /^vence-(SRT|EJE)$/.exec(a.name); if (!m) return;
  const origen = m[1], pend = (await leer('portalPend')) || {}, p = pend[origen];
  if (!p) return;
  if (p.abrir) {
    await estado(origen, 'esperando');           // la pestaña queda abierta: falta llegar al listado
    return;
  }
  await guardarLista(origen, { error: 'No se encontró tu listado de causas. Abrilo una vez en el portal y tocá "Enviar a IusTrack".' });
  await terminar(origen, true);
});
