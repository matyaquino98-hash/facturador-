// ════════════════════════════════════════════════════════════════════════
// Copias de seguridad en TU Google Drive — LexTrack · Gestoría · SueldosCG
// Se instala una sola vez en la cuenta de Google donde querés las copias.
// Sólo acepta copias de un usuario con sesión iniciada que sea ADMINISTRADOR
// del estudio (lo verifica con el servidor del sistema). La primera vez que se
// usa queda vinculado a ese usuario; otro usuario no puede escribir acá.
// Las copias van a la carpeta "Copias <sistema> / <estudio>" y se conservan
// las últimas 30 de cada estudio. Los documentos adjuntos se copian una sola
// vez en "Documentos / <expediente o cliente>".
// ════════════════════════════════════════════════════════════════════════
const PROYECTOS = {
  'https://mgzzappqcqiwarfekzuk.supabase.co': 'sb_publishable_RFEohmMhp5p1Z44SOzsrTg_JSWI-Iwg',   // LexTrack
  'https://hrmksmesefyhdkjisfqq.supabase.co': 'sb_publishable_jO4YbGUyqlJjOAKRjcO9jA_J4qRAD9O'    // Gestoría y SueldosCG
};
const TABLAS = { 'LexTrack': ['miembros', 'estudio_id'], 'Gestoría': ['miembros', 'estudio_id'], 'SueldosCG': ['sc_miembros', 'empresa_id'] };
const CONSERVAR = 30;

function doGet() {
  return salida({ ok: true, servicio: 'copias-drive', cuenta: Session.getEffectiveUser().getEmail() });
}

function doPost(e) {
  try {
    const p = JSON.parse(e.postData.contents);
    const clave = PROYECTOS[p.proyecto];
    if (!clave) throw new Error('Sistema no autorizado');
    const tabla = TABLAS[p.sistema];
    if (!tabla) throw new Error('Sistema desconocido');
    if (!p.token || !p.estudioId) throw new Error('Faltan datos');

    // 1) La sesión es válida
    const u = pedir(p.proyecto + '/auth/v1/user', clave, p.token);
    // 2) Es administrador activo de ese estudio
    const m = pedir(p.proyecto + '/rest/v1/' + tabla[0] + '?select=rol,activo&' + tabla[1] + '=eq.' +
                    encodeURIComponent(p.estudioId) + '&usuario_id=eq.' + encodeURIComponent(u.id), clave, p.token);
    if (!m.length || m[0].rol !== 'admin' || m[0].activo === false) throw new Error('Sólo el administrador del estudio puede guardar copias');
    // 3) Este Drive queda vinculado al primer administrador que lo usa (uno por sistema)
    const props = PropertiesService.getScriptProperties();
    const vinc = JSON.parse(props.getProperty('vinculados') || '{}');
    if (!vinc[p.proyecto]) { vinc[p.proyecto] = u.id; props.setProperty('vinculados', JSON.stringify(vinc)); }
    else if (vinc[p.proyecto] !== u.id) throw new Error('Este Drive ya está vinculado a otro usuario');
    const cuenta = Session.getEffectiveUser().getEmail();
    if (p.prueba) return salida({ ok: true, cuenta: cuenta });
    const estudio = limpio(p.estudioNombre || p.estudioId);
    const carpeta = subcarpeta(subcarpeta(DriveApp.getRootFolder(), 'Copias ' + p.sistema), estudio);

    // Documentos: se copian una sola vez, en Documentos / <expediente o cliente> / <archivo>
    if (p.accion === 'listarDocs') {
      const docs = subcarpeta(carpeta, 'Documentos'), nombres = [], its = docs.getFolders();
      while (its.hasNext()) {
        const sub = its.next(), fs = sub.getFiles();
        while (fs.hasNext()) nombres.push(sub.getName() + '/' + fs.next().getName());
      }
      return salida({ ok: true, existentes: nombres, carpeta: docs.getUrl() });
    }
    if (p.accion === 'documento') {
      const sub = subcarpeta(subcarpeta(carpeta, 'Documentos'), limpio(p.grupo || 'Varios'));
      const nombre = limpio(p.nombre || 'documento');
      if (sub.getFilesByName(nombre).hasNext()) return salida({ ok: true, ya: true });
      sub.createFile(Utilities.newBlob(Utilities.base64Decode(p.base64), p.mime || 'application/octet-stream', nombre));
      return salida({ ok: true });
    }

    // 4) Guardar la copia de los datos
    if (!p.datos) throw new Error('La copia llegó vacía');
    const nombre = p.sistema + ' - ' + estudio + ' - ' +
                   Utilities.formatDate(new Date(), 'America/Argentina/Buenos_Aires', 'yyyy-MM-dd HH.mm') + '.json';
    const archivo = carpeta.createFile(nombre, p.datos, 'application/json');
    // 5) Se conservan sólo las últimas copias (las viejas van a la papelera)
    const lista = [], it = carpeta.getFiles();
    while (it.hasNext()) lista.push(it.next());
    lista.sort(function (a, b) { return b.getDateCreated() - a.getDateCreated(); })
         .slice(CONSERVAR).forEach(function (x) { x.setTrashed(true); });
    return salida({ ok: true, cuenta: cuenta, archivo: nombre, url: archivo.getUrl(), carpeta: carpeta.getUrl() });
  } catch (err) {
    return salida({ ok: false, error: String((err && err.message) || err) });
  }
}

function pedir(url, clave, token) {
  const r = UrlFetchApp.fetch(url, { headers: { apikey: clave, Authorization: 'Bearer ' + token }, muteHttpExceptions: true });
  if (r.getResponseCode() !== 200) throw new Error('Sesión no válida: volvé a ingresar al sistema (' + r.getResponseCode() + ')');
  return JSON.parse(r.getContentText());
}
function subcarpeta(padre, nombre) {
  const it = padre.getFoldersByName(nombre);
  return it.hasNext() ? it.next() : padre.createFolder(nombre);
}
function limpio(s) { return String(s || '').replace(/[\\\/:*?"<>|]+/g, '-').trim().slice(0, 80) || 'estudio'; }
function salida(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
