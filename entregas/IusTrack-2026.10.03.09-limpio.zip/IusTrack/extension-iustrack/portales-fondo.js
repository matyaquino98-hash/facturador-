/* IusTrack — importar causas de los 4 portales (MEV/SCBA Notificaciones, PJN, SRT y EJE).
   Corre dentro del segundo plano de la extensión (fondo.js lo carga con importScripts).
   · "Importar causas" (desde IusTrack): abre el portal en una pestaña en segundo plano, entra
     con el usuario guardado en IusTrack, llega solo al listado, lo recorre página por página
     y devuelve las causas. Si no puede, IusTrack pide abrirlo una vez a la vista.
   · Usuario y clave: sólo en la memoria de la sesión de Chrome mientras dura la lectura y
     sólo para la pestaña que abrió la extensión. Las listas quedan en esta computadora. */
(() => {
  const INICIO = {
    SCBA: 'https://notificaciones.scba.gov.ar/InterfazBootstrap/Login.aspx',
    PJN: 'https://scw.pjn.gov.ar/scw/consultaListaRelacionados.seam',
    SRT: 'https://auth.afip.gob.ar/contribuyente_/login.xhtml',
    EJE: 'https://eje.juscaba.gob.ar/'
  };
  const PERMITIDA = /^https:\/\/(([a-z0-9-]+\.)*srt\.gob\.ar|eje\.juscaba\.gob\.ar|eje\.jus\.gov\.ar|notificaciones\.scba\.gov\.ar|scw\.pjn\.gov\.ar)\//i;
  const ESPERA_MIN = 5, MAX_PAGINAS = 80;
  const MENSAJES = new Set(['p-listas', 'p-estado', 'p-leer', 'p-pendiente', 'p-lista', 'p-salto', 'p-login']);
  const leer = k => new Promise(r => chrome.storage.local.get(k, o => r(o[k])));
  const poner = o => new Promise(r => chrome.storage.local.set(o, r));
  const claveCausa = x => String(x.numero || '').toUpperCase().replace(/\s+/g, '');
  const sesion = chrome.storage.session || chrome.storage.local;
  const claves = {
    leer: o => new Promise(r => sesion.get('portalClaves', x => r((x && x.portalClaves || {})[o] || null))),
    poner: (o, v) => new Promise(r => sesion.get('portalClaves', x => { const c = (x && x.portalClaves) || {}; if (v) c[o] = v; else delete c[o]; sesion.set({ portalClaves: c }, r); }))
  };
  const tabsDe = p => p.tabs || [p.tabId];

  async function estado(origen, msg, extra) {
    const e = (await leer('portalEstado')) || {};
    e[origen] = Object.assign({ msg, t: Date.now() }, extra || {});
    await poner({ portalEstado: e });
  }
  async function guardarLista(origen, cambios) {
    const l = (await leer('portalListas')) || {};
    l[origen] = Object.assign({ items: [] }, l[origen] || {}, cambios, { t: Date.now() });
    await poner({ portalListas: l });
    return l[origen];
  }
  async function terminar(origen, cerrarTab) {
    const pend = (await leer('portalPend')) || {}, p = pend[origen];
    delete pend[origen];
    await poner({ portalPend: pend });
    chrome.alarms.clear('vence-' + origen);
    await claves.poner(origen, null);
    if (p && cerrarTab && !p.abrir) tabsDe(p).forEach(id => id && chrome.tabs.remove(id).catch(() => {}));
    await estado(origen, '');
  }

  async function manejar(m, snd) {
    const origen = m.origen;
    if (m.it === 'p-listas') return (await leer('portalListas')) || {};
    if (m.it === 'p-estado') return (await leer('portalEstado')) || {};
    if (m.it === 'p-leer') {
      if (!INICIO[origen]) return { error: 'origen' };
      const url = PERMITIDA.test(m.url || '') ? m.url : INICIO[origen];
      const pend = (await leer('portalPend')) || {};
      if (pend[origen]) tabsDe(pend[origen]).forEach(id => id && chrome.tabs.remove(id).catch(() => {}));
      const tab = await chrome.tabs.create({ url, active: !!m.abrir });
      pend[origen] = { t: Date.now(), tabId: tab.id, tabs: [tab.id], saltos: 0, paginas: 0, nueva: true, abrir: !!m.abrir, cuit: m.cuit || '' };
      await poner({ portalPend: pend });
      // Si recién falló el ingreso con esa clave, no se vuelve a probar (se completa sólo el usuario)
      const ant = ((await leer('portalListas')) || {})[origen];
      const clave = ant && ant.error === 'login' && Date.now() - (ant.t || 0) < 3 * 60 * 1000 ? '' : (m.clave || '');
      await claves.poner(origen, m.cuit ? { usuario: m.cuit, clave } : null);
      chrome.alarms.create('vence-' + origen, { delayInMinutes: ESPERA_MIN });
      await estado(origen, m.abrir ? 'abierto' : 'leyendo', { silencioso: !m.abrir });
      return { ok: true };
    }
    if (m.it === 'p-pendiente') {
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      if (!p || Date.now() - p.t > 30 * 60 * 1000) return null;
      const esta = !!(snd.tab && tabsDe(p).includes(snd.tab.id)), r = { cuit: p.cuit, abrir: p.abrir, esta };
      if (esta) { const c = await claves.leer(origen); if (c) { r.usuario = c.usuario; r.clave = c.clave; } }
      return r;
    }
    if (m.it === 'p-lista') {
      if (!INICIO[origen] || !Array.isArray(m.items)) return { error: 'datos' };
      const items = m.items.filter(x => x && x.numero).slice(0, 3000).map(x => ({
        numero: String(x.numero).slice(0, 80), caratula: String(x.caratula || '').slice(0, 400), motivo: String(x.motivo || '').slice(0, 200),
        damnificado: String(x.damnificado || '').slice(0, 200), juzgado: String(x.juzgado || '').slice(0, 200), inicio: String(x.inicio || '').slice(0, 30),
        estado: String(x.estado || '').slice(0, 120), ultAct: String(x.ultAct || '').slice(0, 30),
        link: /^https:\/\//i.test(x.link || '') ? String(x.link).slice(0, 600) : '' }));
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      const ant = ((await leer('portalListas')) || {})[origen];
      // Una lectura nueva reemplaza la lista; sus páginas siguientes se van sumando
      const base = p && p.nueva ? [] : ((ant && ant.items) || []);
      const mapa = new Map(base.map(x => [claveCausa(x), x]));
      items.forEach(x => mapa.set(claveCausa(x), Object.assign({}, mapa.get(claveCausa(x)) || {}, x)));
      const esLectura = !!(p && snd.tab && tabsDe(p).includes(snd.tab.id));
      if (p) { p.nueva = false; p.paginas = (p.paginas || 0) + 1; await poner({ portalPend: pend }); }
      const sigue = !!(m.parcial && p && p.paginas < MAX_PAGINAS);
      if (sigue) { await guardarLista(origen, { items: [...mapa.values()], parcial: true }); return { ok: true, sigue: true, total: mapa.size }; }
      const r = await guardarLista(origen, { items: [...mapa.values()], url: PERMITIDA.test(m.url || '') ? m.url : (ant && ant.url) || '', error: '', parcial: false, silencioso: p ? !p.abrir : false });
      await terminar(origen, esLectura);
      return { ok: true, total: r.items.length };
    }
    // Un paso de la navegación automática hasta el listado (como mucho 8 por lectura)
    if (m.it === 'p-salto') {
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      if (!p || !snd.tab || !tabsDe(p).includes(snd.tab.id)) return { ok: false };
      p.saltos = (p.saltos || 0) + 1; await poner({ portalPend: pend });
      return { ok: p.saltos <= 8 };
    }
    if (m.it === 'p-login') {
      const pend = (await leer('portalPend')) || {}, p = pend[origen];
      if (!p) return null;
      await guardarLista(origen, { error: 'login', silencioso: !p.abrir });
      if (!p.abrir) { await terminar(origen, true); return { ok: true }; }
      await estado(origen, 'login', { silencioso: false });
      return { ok: true };
    }
    return null;
  }
  chrome.runtime.onMessage.addListener((m, snd, responder) => {
    if (!m || !MENSAJES.has(m.it)) return;                // los demás mensajes son de la procuración y las descargas
    manejar(m, snd || {}).then(responder, e => responder({ error: String(e && e.message || e) }));
    return true;
  });
  // Si el portal abre el servicio en otra pestaña (AFIP → SRT), esa pestaña pasa a ser parte de la lectura
  chrome.tabs.onCreated.addListener(async tab => {
    if (!tab.openerTabId) return;
    const pend = (await leer('portalPend')) || {}; let cambio = false;
    Object.values(pend).forEach(p => { if (tabsDe(p).includes(tab.openerTabId)) { p.tabs = tabsDe(p).concat(tab.id); p.tabId = tab.id; cambio = true; } });
    if (cambio) await poner({ portalPend: pend });
  });
  // Si se cierra la pestaña del portal que estaba a la vista, la lectura se da por terminada
  chrome.tabs.onRemoved.addListener(async id => {
    const pend = (await leer('portalPend')) || {};
    for (const [origen, p] of Object.entries(pend)) {
      if (!tabsDe(p).includes(id)) continue;
      p.tabs = tabsDe(p).filter(x => x !== id);
      if (p.tabs.length) { p.tabId = p.tabs[p.tabs.length - 1]; await poner({ portalPend: pend }); continue; }
      await guardarLista(origen, { error: 'Se cerró la pestaña del portal antes de leer el listado. Tocá "Importar causas" de nuevo.', silencioso: !p.abrir });
      await terminar(origen, false);
    }
  });
  chrome.alarms.onAlarm.addListener(async a => {
    const m = /^vence-(SCBA|PJN|SRT|EJE)$/.exec(a.name); if (!m) return;
    const origen = m[1], pend = (await leer('portalPend')) || {}, p = pend[origen];
    if (!p) return;
    if (p.abrir) { await estado(origen, 'esperando', { silencioso: false }); return; }
    await guardarLista(origen, { error: 'No se encontró tu listado de causas en segundo plano.', silencioso: true });
    await terminar(origen, true);
  });
})();
